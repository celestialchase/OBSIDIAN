import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, sendEmailVerification, signOut } from 'firebase/auth';
import {
  INITIAL_COURSES,
  INITIAL_ISL_ENTRIES,
  INITIAL_LESSONS,
  INITIAL_NOTES,
  INITIAL_NOTIFICATIONS,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_QUIZ_QUESTIONS,
} from '../data/curriculum';
import { auth, testFirestoreConnection } from '../lib/firebase';
import { formatReadableFirestoreError } from '../lib/firestoreErrors';
import {
  createISLEntryDoc,
  createNoteDoc,
  createQuizAttemptDoc,
  deleteNoteDoc,
  ensureUserProfileDoc,
  markLessonCompletedDoc,
  saveVideoProgressDoc,
  setNotificationReadDoc,
  subscribeISLEntries,
  subscribeLessonProgress,
  subscribeNotes,
  subscribeNotificationStates,
  subscribeQuizAttempts,
  subscribeVideoProgress,
  updateUserGradeDoc,
} from '../services/firestoreService';
import {
  Course,
  ISLEntry,
  Lesson,
  NavRoute,
  NotificationItem,
  QuizAttempt,
  QuizQuestion,
  SavedNote,
  SubjectName,
  UserProfile,
  UserRole,
  VideoProgressRecord,
} from '../types';
import { clearStoredAccessibilitySettings } from '../utils/accessibility';

const STORAGE_KEY_USER = 'indrasetu_user_v1';
const STORAGE_KEY_NOTES = 'indrasetu_notes_v1';

const DEMO_STUDENT: UserProfile = {
  id: 'demo-student-1',
  name: 'Aarav Verma',
  email: 'aarav.student@indrasetu.edu',
  role: 'student',
  grade: 'Class 8',
  board: 'CBSE',
  isDemo: true,
};

interface PendingSignupMeta {
  name?: string;
  role: UserRole;
  grade: string;
}

interface AppContextValue {
  route: NavRoute;
  navigate: (route: NavRoute) => void;
  user: UserProfile;
  setUser: (user: UserProfile) => void;
  firebaseUid: string | null;
  authReady: boolean;
  offlineMode: boolean;
  setPendingSignupMeta: (meta: PendingSignupMeta | null) => void;
  signOutAccount: () => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  getAuthHeaders: () => Promise<Record<string, string>>;
  authModalOpen: boolean;
  openAuthModal: (initialMode?: 'login' | 'register' | 'teacher' | 'recover') => void;
  closeAuthModal: () => void;
  authModalMode: 'login' | 'register' | 'teacher' | 'recover';
  selectedGrade: string;
  setSelectedGrade: (grade: string) => void;
  selectedSubjectFilter: SubjectName | 'All';
  setSelectedSubjectFilter: (subject: SubjectName | 'All') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  courses: Course[];
  lessons: Lesson[];
  activeLessonId: string;
  openLesson: (lessonId: string) => void;
  markLessonCompleted: (lessonId: string) => Promise<void>;
  islEntries: ISLEntry[];
  addISLEntry: (entry: ISLEntry) => Promise<void>;
  notes: SavedNote[];
  addNote: (note: Omit<SavedNote, 'id' | 'createdAt'>) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  videoProgress: Record<string, VideoProgressRecord>;
  saveVideoProgress: (videoId: string, currentSec: number, durationSec: number) => void;
  quizQuestions: QuizQuestion[];
  setQuizQuestions: (qs: QuizQuestion[]) => void;
  quizAttempts: QuizAttempt[];
  recordQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'completedAt'>) => Promise<void>;
  syncLoading: boolean;
  actionLoading: boolean;
  firestoreError: string | null;
  clearFirestoreError: () => void;
  geminiAvailable: boolean;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
  mobileDrawerOpen: boolean;
  setMobileDrawerOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

const VALID_ROUTES: NavRoute[] = [
  'landing',
  'dashboard',
  'learning',
  'videos',
  'isl',
  'visual',
  'doubt',
  'assessments',
  'progress',
  'accessibility',
  'profile',
];

function getInitialRoute(): NavRoute {
  if (typeof window === 'undefined') return 'landing';
  const params = new URLSearchParams(window.location.search);
  const viewParam = params.get('view') as NavRoute | null;
  if (params.get('autostart') === '1') return 'dashboard';
  if (viewParam && VALID_ROUTES.includes(viewParam)) return viewParam;
  const hash = window.location.hash.replace('#/', '') as NavRoute;
  if (hash && VALID_ROUTES.includes(hash)) return hash;
  return 'landing';
}

function loadDemoLocalNotes(): SavedNote[] {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY_NOTES);
    return saved ? (JSON.parse(saved) as SavedNote[]) : INITIAL_NOTES;
  } catch {
    return INITIAL_NOTES;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [route, setRoute] = useState<NavRoute>(getInitialRoute);
  const [user, setUserState] = useState<UserProfile>(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY_USER);
      if (saved) {
        const parsed = JSON.parse(saved) as UserProfile;
        if (parsed.isDemo) return parsed;
      }
      return DEMO_STUDENT;
    } catch {
      return DEMO_STUDENT;
    }
  });
  const [firebaseUid, setFirebaseUid] = useState<string | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const pendingSignupMetaRef = useRef<PendingSignupMeta | null>(null);

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'teacher' | 'recover'>('login');
  const [selectedGrade, setSelectedGradeState] = useState<string>(user.grade || 'Class 8');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<SubjectName | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [courses, setCourses] = useState<Course[]>(INITIAL_COURSES);
  const [lessons, setLessons] = useState<Lesson[]>(INITIAL_LESSONS);
  const [activeLessonId, setActiveLessonId] = useState<string>(INITIAL_LESSONS[0].id);
  const [islEntries, setIslEntries] = useState<ISLEntry[]>(INITIAL_ISL_ENTRIES);
  const [notes, setNotes] = useState<SavedNote[]>(loadDemoLocalNotes);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [videoProgress, setVideoProgress] = useState<Record<string, VideoProgressRecord>>({});
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(INITIAL_QUIZ_QUESTIONS);
  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>(INITIAL_QUIZ_ATTEMPTS);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [firestoreError, setFirestoreError] = useState<string | null>(null);
  const [geminiAvailable, setGeminiAvailable] = useState<boolean>(false);
  const [offlineMode, setOfflineMode] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState<boolean>(false);

  const setPendingSignupMeta = useCallback((meta: PendingSignupMeta | null) => {
    pendingSignupMetaRef.current = meta;
  }, []);

  useEffect(() => {
    const onOnline = () => setOfflineMode(false);
    const onOffline = () => setOfflineMode(true);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  useEffect(() => {
    void testFirestoreConnection();
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => setGeminiAvailable(Boolean(data?.geminiConfigured)))
      .catch(() => setGeminiAvailable(false));
  }, []);

  // Firebase Auth listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        setFirebaseUid(fbUser.uid);
        const meta = pendingSignupMetaRef.current;
        pendingSignupMetaRef.current = null;
        try {
          const profile = await ensureUserProfileDoc({
            uid: fbUser.uid,
            name:
              meta?.name ||
              fbUser.displayName ||
              fbUser.email?.split('@')[0]?.replace(/[._]/g, ' ') ||
              'IndraSetu Learner',
            email: fbUser.email || '',
            role: meta?.role || 'student',
            grade: meta?.grade || 'Class 8',
          });
          setUserState({ ...profile, emailVerified: fbUser.emailVerified });
          setSelectedGradeState(profile.grade);
        } catch (err) {
          console.error('Failed to sync authenticated profile:', err);
          setFirestoreError(formatReadableFirestoreError(err));
          setUserState({
            id: fbUser.uid,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Student',
            email: fbUser.email || '',
            role: 'student',
            grade: meta?.grade || 'Class 8',
            board: 'CBSE',
            isDemo: false,
            emailVerified: fbUser.emailVerified,
          });
        }
      } else {
        setFirebaseUid(null);
        setUserState((prev) => (prev.isDemo ? prev : DEMO_STUDENT));
      }
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to shared ISL terminology catalog when authenticated
  useEffect(() => {
    if (!authReady) return;
    if (!firebaseUid) {
      setIslEntries(INITIAL_ISL_ENTRIES);
      return;
    }
    const unsub = subscribeISLEntries(
      (remoteEntries) => {
        const seen = new Set(remoteEntries.map((e) => e.id));
        const merged = [
          ...remoteEntries,
          ...INITIAL_ISL_ENTRIES.filter((item) => !seen.has(item.id)),
        ];
        setIslEntries(merged);
      },
      (errMsg) => {
        setFirestoreError(errMsg);
      }
    );
    return () => unsub();
  }, [authReady, firebaseUid]);

  // Subscribe to user-scoped Firestore collections when authenticated
  useEffect(() => {
    if (!authReady || !firebaseUid) {
      setSyncLoading(false);
      setFirestoreError(null);
      setNotes(loadDemoLocalNotes());
      setNotifications(INITIAL_NOTIFICATIONS);
      setVideoProgress({});
      setLessons(INITIAL_LESSONS);
      setCourses(INITIAL_COURSES);
      setQuizAttempts(INITIAL_QUIZ_ATTEMPTS);
      return;
    }

    // Clear demo/mock records immediately so authenticated accounts only reflect Firestore data
    setSyncLoading(true);
    setFirestoreError(null);
    setNotes([]);
    setQuizAttempts([]);
    setVideoProgress({});
    setLessons(
      INITIAL_LESSONS.map((l) => ({
        ...l,
        status: l.status === 'completed' ? 'in-progress' : l.status,
      }))
    );
    setCourses(
      INITIAL_COURSES.map((c) => ({
        ...c,
        lessonsCompleted: 0,
        progressPercent: 0,
      }))
    );

    const ready = { notes: false, progress: false, attempts: false };
    const markSectionReady = (key: keyof typeof ready) => {
      ready[key] = true;
      if (ready.notes && ready.progress && ready.attempts) {
        setSyncLoading(false);
      }
    };

    const unsubNotes = subscribeNotes(
      firebaseUid,
      (remoteNotes) => {
        setNotes(remoteNotes);
        markSectionReady('notes');
      },
      (errMsg) => {
        setFirestoreError(errMsg);
        markSectionReady('notes');
      }
    );

    const unsubProgress = subscribeLessonProgress(
      firebaseUid,
      (completedIds) => {
        const nextLessons = INITIAL_LESSONS.map((l) => ({
          ...l,
          status: completedIds.has(l.id)
            ? ('completed' as const)
            : l.status === 'completed'
            ? ('in-progress' as const)
            : l.status,
        }));
        setLessons(nextLessons);

        const completedByCourse: Record<string, number> = {};
        for (const l of nextLessons) {
          if (l.status === 'completed') {
            completedByCourse[l.courseId] = (completedByCourse[l.courseId] || 0) + 1;
          }
        }
        setCourses(
          INITIAL_COURSES.map((c) => {
            const done = Math.min(c.totalLessons, completedByCourse[c.id] || 0);
            return {
              ...c,
              lessonsCompleted: done,
              progressPercent: Math.round((done / c.totalLessons) * 100),
            };
          })
        );
        markSectionReady('progress');
      },
      (errMsg) => {
        setFirestoreError(errMsg);
        markSectionReady('progress');
      }
    );

    const unsubAttempts = subscribeQuizAttempts(
      firebaseUid,
      (remoteAttempts) => {
        setQuizAttempts(remoteAttempts);
        markSectionReady('attempts');
      },
      (errMsg) => {
        setFirestoreError(errMsg);
        markSectionReady('attempts');
      }
    );

    const unsubNotifications = subscribeNotificationStates(
      firebaseUid,
      (readMap) => {
        setNotifications(
          INITIAL_NOTIFICATIONS.map((n) => ({
            ...n,
            read: n.id in readMap ? readMap[n.id] : n.read,
          }))
        );
      },
      (errMsg) => {
        setFirestoreError(errMsg);
      }
    );

    const unsubVideoProgress = subscribeVideoProgress(
      firebaseUid,
      (progressMap) => {
        setVideoProgress(progressMap);
      },
      (errMsg) => {
        setFirestoreError(errMsg);
      }
    );

    return () => {
      unsubNotes();
      unsubProgress();
      unsubAttempts();
      unsubNotifications();
      unsubVideoProgress();
    };
  }, [authReady, firebaseUid]);

  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.replace('#/', '') as NavRoute;
      if (hash && VALID_ROUTES.includes(hash)) {
        setRoute(hash);
      } else if (!window.location.hash) {
        const params = new URLSearchParams(window.location.search);
        setRoute(params.get('autostart') === '1' ? 'dashboard' : 'landing');
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = useCallback((nextRoute: NavRoute) => {
    setRoute(nextRoute);
    setMobileDrawerOpen(false);
    if (typeof window !== 'undefined') {
      window.location.hash = nextRoute === 'landing' ? '' : `#/${nextRoute}`;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  const setUser = useCallback((nextUser: UserProfile) => {
    setUserState(nextUser);
    setSelectedGradeState(nextUser.grade);
    try {
      if (nextUser.isDemo) {
        window.localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(nextUser));
      } else {
        window.localStorage.removeItem(STORAGE_KEY_USER);
      }
    } catch {
      // ignore storage quota errors
    }
  }, []);

  const setSelectedGrade = useCallback(
    (grade: string) => {
      setSelectedGradeState(grade);
      setUserState((prev) => ({ ...prev, grade }));
      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        updateUserGradeDoc(firebaseUid, grade)
          .catch((err) => {
            setFirestoreError(formatReadableFirestoreError(err));
          })
          .finally(() => {
            setActionLoading(false);
          });
      }
    },
    [firebaseUid]
  );

  const signOutAccount = useCallback(async () => {
    clearStoredAccessibilitySettings();
    if (auth.currentUser) {
      await signOut(auth);
    }
    setUser(DEMO_STUDENT);
  }, [setUser]);

  const resendVerificationEmail = useCallback(async () => {
    if (!auth.currentUser) {
      throw new Error('Please sign in first to verify your email address.');
    }
    await sendEmailVerification(auth.currentUser);
  }, []);

  const getAuthHeaders = useCallback(async (): Promise<Record<string, string>> => {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (auth.currentUser) {
      try {
        const token = await auth.currentUser.getIdToken();
        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }
      } catch {
        // continue without token if unavailable
      }
    }
    return headers;
  }, []);

  const openAuthModal = useCallback((mode: 'login' | 'register' | 'teacher' | 'recover' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setAuthModalOpen(false);
  }, []);

  const openLesson = useCallback(
    (lessonId: string) => {
      setActiveLessonId(lessonId);
      navigate('learning');
    },
    [navigate]
  );

  const markLessonCompleted = useCallback(
    async (lessonId: string) => {
      const target = lessons.find((l) => l.id === lessonId);
      if (!target || target.status === 'completed') return;

      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        try {
          await markLessonCompletedDoc(firebaseUid, {
            lessonId: target.id,
            courseId: target.courseId,
            subject: target.subject,
          });
        } catch (err) {
          const msg = formatReadableFirestoreError(err);
          setFirestoreError(msg);
          throw new Error(msg);
        } finally {
          setActionLoading(false);
        }
        return;
      }

      setLessons((prev) =>
        prev.map((l) => (l.id === lessonId ? { ...l, status: 'completed' } : l))
      );
      setCourses((prevCourses) =>
        prevCourses.map((c) => {
          if (c.id !== target.courseId) return c;
          const nextDone = Math.min(c.totalLessons, c.lessonsCompleted + 1);
          return {
            ...c,
            lessonsCompleted: nextDone,
            progressPercent: Math.round((nextDone / c.totalLessons) * 100),
          };
        })
      );
    },
    [firebaseUid, lessons]
  );

  const addISLEntry = useCallback(
    async (entry: ISLEntry) => {
      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        try {
          await createISLEntryDoc(firebaseUid, entry, user.role === 'teacher');
        } catch (err) {
          const msg = formatReadableFirestoreError(err);
          setFirestoreError(msg);
          throw new Error(msg);
        } finally {
          setActionLoading(false);
        }
        return;
      }
      setIslEntries((prev) => [entry, ...prev]);
    },
    [firebaseUid, user.role]
  );

  const addNote = useCallback(
    async (note: Omit<SavedNote, 'id' | 'createdAt'>) => {
      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        try {
          await createNoteDoc(firebaseUid, note);
        } catch (err) {
          const msg = formatReadableFirestoreError(err);
          setFirestoreError(msg);
          throw new Error(msg);
        } finally {
          setActionLoading(false);
        }
        return;
      }
      setNotes((prev) => {
        const next: SavedNote[] = [
          {
            ...note,
            id: `note-${Date.now()}`,
            createdAt: 'Just now',
          },
          ...prev,
        ];
        try {
          window.localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(next));
        } catch {
          // ignore
        }
        return next;
      });
    },
    [firebaseUid]
  );

  const deleteNote = useCallback(
    async (id: string) => {
      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        try {
          await deleteNoteDoc(firebaseUid, id);
        } catch (err) {
          const msg = formatReadableFirestoreError(err);
          setFirestoreError(msg);
          throw new Error(msg);
        } finally {
          setActionLoading(false);
        }
        return;
      }
      setNotes((prev) => {
        const next = prev.filter((n) => n.id !== id);
        try {
          window.localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(next));
        } catch {
          // ignore
        }
        return next;
      });
    },
    [firebaseUid]
  );

  const markNotificationRead = useCallback(
    (id: string) => {
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
      if (firebaseUid) {
        void setNotificationReadDoc(firebaseUid, id, true).catch((err) => {
          setFirestoreError(formatReadableFirestoreError(err));
        });
      }
    },
    [firebaseUid]
  );

  const markAllNotificationsRead = useCallback(() => {
    const unreadIds = notifications.filter((n) => !n.read).map((n) => n.id);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    if (firebaseUid && unreadIds.length > 0) {
      Promise.all(unreadIds.map((id) => setNotificationReadDoc(firebaseUid, id, true))).catch(
        (err) => {
          setFirestoreError(formatReadableFirestoreError(err));
        }
      );
    }
  }, [firebaseUid, notifications]);

  const saveVideoProgress = useCallback(
    (videoId: string, currentSec: number, durationSec: number) => {
      const clampedSec = Math.max(0, Math.min(durationSec, Math.round(currentSec)));
      const completed = clampedSec >= durationSec - 1;
      setVideoProgress((prev) => ({
        ...prev,
        [videoId]: {
          videoId,
          currentSec: clampedSec,
          durationSec,
          completed,
        },
      }));
      if (firebaseUid) {
        void saveVideoProgressDoc(firebaseUid, {
          videoId,
          currentSec: clampedSec,
          durationSec,
          completed,
        }).catch((err) => {
          setFirestoreError(formatReadableFirestoreError(err));
        });
      }
    },
    [firebaseUid]
  );

  const recordQuizAttempt = useCallback(
    async (attempt: Omit<QuizAttempt, 'id' | 'completedAt'>) => {
      if (firebaseUid) {
        setActionLoading(true);
        setFirestoreError(null);
        try {
          await createQuizAttemptDoc(firebaseUid, attempt);
        } catch (err) {
          const msg = formatReadableFirestoreError(err);
          setFirestoreError(msg);
          throw new Error(msg);
        } finally {
          setActionLoading(false);
        }
        return;
      }
      setQuizAttempts((prev) => [
        {
          ...attempt,
          id: `att-${Date.now()}`,
          completedAt: 'Just now',
        },
        ...prev,
      ]);
    },
    [firebaseUid]
  );

  return (
    <AppContext.Provider
      value={{
        route,
        navigate,
        user,
        setUser,
        firebaseUid,
        authReady,
        offlineMode,
        setPendingSignupMeta,
        signOutAccount,
        resendVerificationEmail,
        getAuthHeaders,
        authModalOpen,
        openAuthModal,
        closeAuthModal,
        authModalMode,
        selectedGrade,
        setSelectedGrade,
        selectedSubjectFilter,
        setSelectedSubjectFilter,
        searchQuery,
        setSearchQuery,
        courses,
        lessons,
        activeLessonId,
        openLesson,
        markLessonCompleted,
        islEntries,
        addISLEntry,
        notes,
        addNote,
        deleteNote,
        notifications,
        markNotificationRead,
        markAllNotificationsRead,
        videoProgress,
        saveVideoProgress,
        quizQuestions,
        setQuizQuestions,
        quizAttempts,
        recordQuizAttempt,
        syncLoading,
        actionLoading,
        firestoreError,
        clearFirestoreError: () => setFirestoreError(null),
        geminiAvailable,
        sidebarCollapsed,
        setSidebarCollapsed,
        mobileDrawerOpen,
        setMobileDrawerOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
