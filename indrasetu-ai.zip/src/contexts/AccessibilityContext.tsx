import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, Unsubscribe } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { formatReadableFirestoreError } from '../lib/firestoreErrors';
import {
  saveAccessibilityPrefsDoc,
  subscribeAccessibilityPrefsDoc,
} from '../services/firestoreService';
import { AccessibilitySettings } from '../types';
import {
  clearStoredAccessibilitySettings,
  ComputedReadingStyle,
  computeReadingStyles,
  DEFAULT_ACCESSIBILITY_SETTINGS,
  loadAccessibilitySettings,
  saveAccessibilitySettings,
} from '../utils/accessibility';

interface AccessibilityContextValue {
  settings: AccessibilitySettings;
  readingStyles: ComputedReadingStyle;
  lastSavedAt: string | null;
  prefsLoading: boolean;
  prefsSaving: boolean;
  prefsError: string | null;
  clearPrefsError: () => void;
  drawerOpen: boolean;
  announcement: string;
  openDrawer: () => void;
  closeDrawer: () => void;
  toggleDrawer: () => void;
  announce: (message: string) => void;
  updateSettings: (patch: Partial<AccessibilitySettings>, autoSave?: boolean) => void;
  toggleDyslexiaMode: () => void;
  toggleScreenReader: () => void;
  toggleBiggerText: () => void;
  toggleSmallText: () => void;
  toggleLineHeight: () => void;
  toggleHighlightLinks: () => void;
  toggleTextSpacing: () => void;
  toggleHideImages: () => void;
  toggleCustomCursor: () => void;
  toggleDarkMode: () => void;
  toggleInvertColors: () => void;
  resetToDefaults: () => void;
  saveChanges: () => Promise<boolean>;
}

const AccessibilityContext = createContext<AccessibilityContextValue | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => loadAccessibilitySettings());
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);
  const [prefsLoading, setPrefsLoading] = useState<boolean>(false);
  const [prefsSaving, setPrefsSaving] = useState<boolean>(false);
  const [prefsError, setPrefsError] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [announcement, setAnnouncement] = useState<string>('');
  const uidRef = useRef<string | null>(null);

  const persistRemote = useCallback(async (next: AccessibilitySettings): Promise<boolean> => {
    const uid = uidRef.current;
    if (!uid) return true;
    setPrefsSaving(true);
    setPrefsError(null);
    try {
      await saveAccessibilityPrefsDoc(uid, next);
      return true;
    } catch (err) {
      setPrefsError(formatReadableFirestoreError(err));
      return false;
    } finally {
      setPrefsSaving(false);
    }
  }, []);

  useEffect(() => {
    let prefsUnsub: Unsubscribe | null = null;

    const authUnsub = onAuthStateChanged(auth, (fbUser) => {
      if (prefsUnsub) {
        prefsUnsub();
        prefsUnsub = null;
      }
      const prevUid = uidRef.current;
      uidRef.current = fbUser ? fbUser.uid : null;
      setPrefsError(null);

      if (!fbUser) {
        setPrefsLoading(false);
        if (prevUid !== null) {
          clearStoredAccessibilitySettings();
          setSettings(DEFAULT_ACCESSIBILITY_SETTINGS);
          setLastSavedAt(null);
        }
        return;
      }

      setPrefsLoading(true);
      prefsUnsub = subscribeAccessibilityPrefsDoc(
        fbUser.uid,
        (remote) => {
          setPrefsLoading(false);
          setPrefsError(null);
          if (remote) {
            setSettings(remote);
            saveAccessibilitySettings(remote);
          } else {
            clearStoredAccessibilitySettings();
            setSettings(DEFAULT_ACCESSIBILITY_SETTINGS);
            setLastSavedAt(null);
          }
        },
        (friendlyError) => {
          setPrefsLoading(false);
          setPrefsError(friendlyError);
        }
      );
    });

    return () => {
      if (prefsUnsub) prefsUnsub();
      authUnsub();
    };
  }, []);

  const readingStyles = useMemo(() => computeReadingStyles(settings), [settings]);

  const announce = useCallback(
    (message: string) => {
      setAnnouncement(message);
      if (
        settings.screenReader &&
        typeof window !== 'undefined' &&
        'speechSynthesis' in window
      ) {
        try {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(message);
          u.rate = settings.ttsRate;
          u.lang = 'en-IN';
          window.speechSynthesis.speak(u);
        } catch {
          // ignore if speech engine blocked
        }
      }
    },
    [settings.screenReader, settings.ttsRate]
  );

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', Boolean(settings.darkMode));
    root.setAttribute('data-dyslexia', String(settings.dyslexiaMode));
    root.setAttribute('data-high-contrast', String(settings.highContrast));
    root.setAttribute('data-screen-reader', String(settings.screenReader));
    root.setAttribute('data-line-height', String(settings.lineHeightEnabled));
    root.setAttribute('data-highlight-links', String(settings.highlightLinks));
    root.setAttribute('data-text-spacing', String(settings.textSpacingEnabled));
    root.setAttribute('data-hide-images', String(settings.hideImages));
    root.setAttribute('data-custom-cursor', String(settings.customCursor));
    root.setAttribute('data-invert-colors', String(settings.invertColors));

    root.style.fontSize = `${readingStyles.rootFontSizePx}px`;
    root.style.setProperty('--is-font-family', readingStyles.fontFamily);
    root.style.setProperty('--is-font-scale', String(settings.fontSizePercent / 100));
    root.style.setProperty('--is-line-height', String(readingStyles.lineHeight));
    root.style.setProperty('--is-letter-spacing', readingStyles.letterSpacingEm);
    root.style.setProperty('--is-word-spacing', readingStyles.wordSpacingEm);
    root.style.setProperty('--is-para-spacing', readingStyles.paragraphSpacingRem);
    root.style.setProperty('--is-reading-bg', readingStyles.backgroundColor);
    root.style.setProperty('--is-reading-fg', readingStyles.textColor);
  }, [settings, readingStyles]);

  // Screen reader keyboard/focus announcement listener when Screen Reader tile is enabled
  useEffect(() => {
    if (!settings.screenReader) return;
    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const label =
        target.getAttribute('aria-label') ||
        target.textContent?.trim().slice(0, 80) ||
        target.getAttribute('placeholder');
      if (label) {
        setAnnouncement(`Focused: ${label}`);
      }
    };
    document.addEventListener('focusin', handleFocusIn);
    return () => document.removeEventListener('focusin', handleFocusIn);
  }, [settings.screenReader]);

  const updateSettings = useCallback(
    (patch: Partial<AccessibilitySettings>, autoSave = true) => {
      setSettings((prev) => {
        const next: AccessibilitySettings = {
          ...prev,
          ...patch,
        };
        if (typeof patch.fontSizePercent === 'number') {
          next.biggerText = patch.fontSizePercent > 105;
          next.smallText = patch.fontSizePercent < 95;
        }
        if (typeof patch.lineSpacing === 'number') {
          next.lineHeightEnabled = patch.lineSpacing >= 1.75;
        }
        if (typeof patch.letterSpacing === 'number') {
          next.textSpacingEnabled = patch.letterSpacing >= 0.03;
        }
        if (autoSave) {
          saveAccessibilitySettings(next);
          persistRemote(next);
        }
        return next;
      });
    },
    [persistRemote]
  );

  const toggleDyslexiaMode = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.dyslexiaMode;
      const next: AccessibilitySettings = enabling
        ? {
            ...prev,
            dyslexiaMode: true,
            fontFamily: 'atkinson',
            fontSizePercent: Math.max(prev.fontSizePercent, 115),
            biggerText: Math.max(prev.fontSizePercent, 115) > 105,
            smallText: false,
            lineSpacing: Math.max(prev.lineSpacing, 1.8),
            lineHeightEnabled: true,
            letterSpacing: Math.max(prev.letterSpacing, 0.04),
            wordSpacing: Math.max(prev.wordSpacing ?? 0, 0.08),
            textSpacingEnabled: true,
            paragraphSpacing: Math.max(prev.paragraphSpacing, 1.4),
          }
        : {
            ...prev,
            dyslexiaMode: false,
            fontFamily: 'jakarta',
            fontSizePercent: 100,
            biggerText: false,
            smallText: false,
            lineSpacing: 1.6,
            lineHeightEnabled: false,
            letterSpacing: 0.01,
            wordSpacing: 0,
            textSpacingEnabled: false,
            paragraphSpacing: 1.2,
          };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Dyslexia Friendly mode enabled.' : 'Dyslexia Friendly mode disabled.');
      return next;
    });
  }, [persistRemote]);

  const toggleScreenReader = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.screenReader;
      const next = { ...prev, screenReader: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(
        enabling
          ? 'Screen reader support enabled. Keyboard focus announcements active.'
          : 'Screen reader support disabled.'
      );
      if (enabling && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(
            'Screen reader support enabled. Use Tab to navigate controls.'
          );
          u.lang = 'en-IN';
          window.speechSynthesis.speak(u);
        } catch {
          // ignore
        }
      }
      return next;
    });
  }, [persistRemote]);

  const toggleBiggerText = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.biggerText;
      const next: AccessibilitySettings = enabling
        ? { ...prev, biggerText: true, smallText: false, fontSizePercent: Math.max(120, prev.fontSizePercent) }
        : { ...prev, biggerText: false, fontSizePercent: 100 };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? `Bigger text enabled at ${next.fontSizePercent}%.` : 'Default text size restored.');
      return next;
    });
  }, [persistRemote]);

  const toggleSmallText = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.smallText;
      const next: AccessibilitySettings = enabling
        ? { ...prev, smallText: true, biggerText: false, fontSizePercent: 88 }
        : { ...prev, smallText: false, fontSizePercent: 100 };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Small text enabled at 88%.' : 'Default text size restored.');
      return next;
    });
  }, [persistRemote]);

  const toggleLineHeight = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.lineHeightEnabled;
      const next: AccessibilitySettings = enabling
        ? { ...prev, lineHeightEnabled: true, lineSpacing: Math.max(1.9, prev.lineSpacing) }
        : { ...prev, lineHeightEnabled: false, lineSpacing: 1.6 };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Expanded line height enabled.' : 'Standard line height restored.');
      return next;
    });
  }, [persistRemote]);

  const toggleHighlightLinks = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.highlightLinks;
      const next = { ...prev, highlightLinks: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Highlight links enabled.' : 'Highlight links disabled.');
      return next;
    });
  }, [persistRemote]);

  const toggleTextSpacing = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.textSpacingEnabled;
      const next: AccessibilitySettings = enabling
        ? {
            ...prev,
            textSpacingEnabled: true,
            letterSpacing: Math.max(0.06, prev.letterSpacing),
            wordSpacing: Math.max(0.12, prev.wordSpacing ?? 0),
          }
        : { ...prev, textSpacingEnabled: false, letterSpacing: 0.01, wordSpacing: 0 };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Expanded text spacing enabled.' : 'Standard text spacing restored.');
      return next;
    });
  }, [persistRemote]);

  const toggleHideImages = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.hideImages;
      const next = { ...prev, hideImages: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Non-essential images hidden.' : 'Images shown.');
      return next;
    });
  }, [persistRemote]);

  const toggleCustomCursor = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.customCursor;
      const next = { ...prev, customCursor: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Large custom cursor enabled.' : 'Default cursor restored.');
      return next;
    });
  }, [persistRemote]);

  const toggleDarkMode = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.darkMode;
      const next = { ...prev, darkMode: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Dark mode enabled.' : 'Light mode enabled.');
      return next;
    });
  }, [persistRemote]);

  const toggleInvertColors = useCallback(() => {
    setSettings((prev) => {
      const enabling = !prev.invertColors;
      const next = { ...prev, invertColors: enabling };
      saveAccessibilitySettings(next);
      persistRemote(next);
      setAnnouncement(enabling ? 'Inverted colours enabled.' : 'Inverted colours disabled.');
      return next;
    });
  }, [persistRemote]);

  const resetToDefaults = useCallback(() => {
    setSettings(DEFAULT_ACCESSIBILITY_SETTINGS);
    saveAccessibilitySettings(DEFAULT_ACCESSIBILITY_SETTINGS);
    persistRemote(DEFAULT_ACCESSIBILITY_SETTINGS);
    setLastSavedAt('Reset to default');
    setAnnouncement('All accessibility settings have been reset.');
  }, [persistRemote]);

  const saveChanges = useCallback(async (): Promise<boolean> => {
    saveAccessibilitySettings(settings);
    const ok = await persistRemote(settings);
    if (ok) {
      const now = new Date();
      setLastSavedAt(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      setAnnouncement('Accessibility changes saved.');
    }
    return ok;
  }, [settings, persistRemote]);

  return (
    <AccessibilityContext.Provider
      value={{
        settings,
        readingStyles,
        lastSavedAt,
        prefsLoading,
        prefsSaving,
        prefsError,
        clearPrefsError: () => setPrefsError(null),
        drawerOpen,
        announcement,
        openDrawer: () => setDrawerOpen(true),
        closeDrawer: () => setDrawerOpen(false),
        toggleDrawer: () => setDrawerOpen((prev) => !prev),
        announce,
        updateSettings,
        toggleDyslexiaMode,
        toggleScreenReader,
        toggleBiggerText,
        toggleSmallText,
        toggleLineHeight,
        toggleHighlightLinks,
        toggleTextSpacing,
        toggleHideImages,
        toggleCustomCursor,
        toggleDarkMode,
        toggleInvertColors,
        resetToDefaults,
        saveChanges,
      }}
    >
      {children}
      {/* Global polite live region for Screen Reader announcements */}
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {announcement}
      </div>
    </AccessibilityContext.Provider>
  );
};

export function useAccessibility(): AccessibilityContextValue {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    throw new Error('useAccessibility must be used inside AccessibilityProvider');
  }
  return ctx;
}
