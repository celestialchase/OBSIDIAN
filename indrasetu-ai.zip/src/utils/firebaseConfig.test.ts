import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveFirebaseClientConfig } from './firebaseConfig';

const FALLBACK = {
  projectId: 'buoyant-technique-4bvhw',
  appId: '1:192187246001:web:6785f12d31612bf9274990',
  apiKey: 'fallback-api-key',
  authDomain: 'buoyant-technique-4bvhw.firebaseapp.com',
  firestoreDatabaseId: 'ai-studio-indrasetuai-496e8986-9959-441a-a4cf-cd65fa75a841',
  storageBucket: 'buoyant-technique-4bvhw.firebasestorage.app',
  messagingSenderId: '192187246001',
};

test('falls back to firebase-applet-config without initializing a storageBucket', () => {
  const resolved = resolveFirebaseClientConfig(
    {
      VITE_FIREBASE_API_KEY: 'YOUR_FIREBASE_WEB_API_KEY',
      VITE_FIREBASE_PROJECT_ID: '',
    },
    FALLBACK
  );

  assert.equal(resolved.source, 'applet-config');
  assert.equal(resolved.options.projectId, 'buoyant-technique-4bvhw');
  assert.equal(
    resolved.firestoreDatabaseId,
    'ai-studio-indrasetuai-496e8986-9959-441a-a4cf-cd65fa75a841'
  );
  assert.equal('storageBucket' in resolved.options, false);
});

test('uses VITE_FIREBASE_* environment variables when configured without storageBucket', () => {
  const resolved = resolveFirebaseClientConfig(
    {
      VITE_FIREBASE_API_KEY: 'env-api-key-123',
      VITE_FIREBASE_AUTH_DOMAIN: 'indrasetu-ai.firebaseapp.com',
      VITE_FIREBASE_PROJECT_ID: 'indrasetu-ai',
      VITE_FIREBASE_MESSAGING_SENDER_ID: '313731204505',
      VITE_FIREBASE_APP_ID: '1:313731204505:web:c4afddf4cab16ada1f7f08',
      VITE_FIREBASE_MEASUREMENT_ID: 'G-TEST1234',
    },
    FALLBACK
  );

  assert.equal(resolved.source, 'env');
  assert.equal(resolved.options.projectId, 'indrasetu-ai');
  assert.equal(resolved.options.apiKey, 'env-api-key-123');
  assert.equal(resolved.options.measurementId, 'G-TEST1234');
  assert.equal(resolved.firestoreDatabaseId, undefined);
  assert.equal('storageBucket' in resolved.options, false);
});

test('preserves named database ID from VITE_FIREBASE_DATABASE_ID when specified', () => {
  const resolved = resolveFirebaseClientConfig(
    {
      VITE_FIREBASE_API_KEY: 'env-api-key-123',
      VITE_FIREBASE_AUTH_DOMAIN: 'indrasetu-ai.firebaseapp.com',
      VITE_FIREBASE_PROJECT_ID: 'indrasetu-ai',
      VITE_FIREBASE_APP_ID: '1:313731204505:web:c4afddf4cab16ada1f7f08',
      VITE_FIREBASE_DATABASE_ID: 'custom-db-id',
    },
    FALLBACK
  );

  assert.equal(resolved.source, 'env');
  assert.equal(resolved.firestoreDatabaseId, 'custom-db-id');
});
