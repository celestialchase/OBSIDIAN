import { SubjectName } from '../types';

export const VALID_CBSE_GRADES = [
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10',
] as const;

export const VALID_CBSE_SUBJECTS: SubjectName[] = [
  'English',
  'Mathematics',
  'Science',
  'Social Science',
  'Hindi',
  'Computer',
];

export function validateProfilePatch(patch: {
  name: string;
  grade: string;
}): { valid: boolean; error?: string; cleanName: string } {
  const cleanName = patch.name.trim();
  if (cleanName.length < 2) {
    return {
      valid: false,
      error: 'Display name must be at least 2 characters.',
      cleanName,
    };
  }
  if (cleanName.length > 120) {
    return {
      valid: false,
      error: 'Display name must be 120 characters or fewer.',
      cleanName,
    };
  }
  if (!(VALID_CBSE_GRADES as readonly string[]).includes(patch.grade)) {
    return {
      valid: false,
      error: 'Please select a valid CBSE class (Class 6 to Class 10).',
      cleanName,
    };
  }
  return { valid: true, cleanName };
}

export function validateNoteInput(input: {
  title: string;
  content: string;
  subject: string;
}): { valid: boolean; error?: string } {
  if (!input.title.trim()) {
    return { valid: false, error: 'Note title is required.' };
  }
  if (input.title.trim().length > 200) {
    return { valid: false, error: 'Note title must be 200 characters or fewer.' };
  }
  if (!input.content.trim()) {
    return { valid: false, error: 'Note content cannot be empty.' };
  }
  if (input.content.trim().length > 4000) {
    return { valid: false, error: 'Note content must be 4000 characters or fewer.' };
  }
  if (!VALID_CBSE_SUBJECTS.includes(input.subject as SubjectName)) {
    return { valid: false, error: 'Invalid CBSE subject for note.' };
  }
  return { valid: true };
}

export function validateQuizAttemptInput(input: {
  topic: string;
  score: number;
  total: number;
}): { valid: boolean; error?: string } {
  if (!input.topic.trim()) {
    return { valid: false, error: 'Assessment topic is required.' };
  }
  if (!Number.isFinite(input.total) || input.total < 1 || input.total > 100) {
    return { valid: false, error: 'Assessment question count must be between 1 and 100.' };
  }
  if (!Number.isFinite(input.score) || input.score < 0 || input.score > input.total) {
    return { valid: false, error: 'Assessment score cannot exceed total questions.' };
  }
  return { valid: true };
}

export function validateDoubtPrompt(question: string): { valid: boolean; error?: string } {
  const trimmed = question.trim();
  if (!trimmed) {
    return { valid: false, error: 'Please enter or build a question before submitting.' };
  }
  if (trimmed.length > 4000) {
    return { valid: false, error: 'Question must be 4000 characters or fewer.' };
  }
  return { valid: true };
}
