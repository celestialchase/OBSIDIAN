import { Course, Lesson, QuizAttempt, QuizQuestion } from '../types';

export interface QuestionEvaluation {
  isCorrect: boolean;
  normalizedUserAnswer: string;
  normalizedExpected: string;
}

export function normalizeAnswer(value: string): string {
  return value.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function evaluateQuizAnswer(
  question: QuizQuestion,
  userResponse: string | Record<string, string> | string[]
): QuestionEvaluation {
  if (question.type === 'matching' && question.matchingPairs) {
    const responseMap =
      typeof userResponse === 'object' && !Array.isArray(userResponse) ? userResponse : {};
    const allMatched = question.matchingPairs.every(
      (pair) => normalizeAnswer(responseMap[pair.left] ?? '') === normalizeAnswer(pair.right)
    );
    return {
      isCorrect: allMatched,
      normalizedUserAnswer: JSON.stringify(responseMap),
      normalizedExpected: question.correctAnswer,
    };
  }

  if (question.type === 'sequence' && question.sequenceItems) {
    const userOrder = Array.isArray(userResponse) ? userResponse : [];
    const expectedOrder = question.sequenceItems;
    const isCorrect =
      userOrder.length === expectedOrder.length &&
      userOrder.every((item, idx) => normalizeAnswer(item) === normalizeAnswer(expectedOrder[idx]));
    return {
      isCorrect,
      normalizedUserAnswer: userOrder.join(' -> '),
      normalizedExpected: expectedOrder.join(' -> '),
    };
  }

  const responseText = typeof userResponse === 'string' ? userResponse : '';
  const normalizedUserAnswer = normalizeAnswer(responseText);
  const normalizedExpected = normalizeAnswer(question.correctAnswer);

  return {
    isCorrect: normalizedUserAnswer.length > 0 && normalizedUserAnswer === normalizedExpected,
    normalizedUserAnswer,
    normalizedExpected,
  };
}

export interface ProgressStats {
  completedLessons: number;
  inProgressLessons: number;
  pendingLessons: number;
  overallPercent: number;
  averageQuizPercent: number;
}

export function computeProgressStats(
  lessons: Lesson[],
  courses: Course[],
  attempts: QuizAttempt[]
): ProgressStats {
  const completedLessons = lessons.filter((l) => l.status === 'completed').length;
  const inProgressLessons = lessons.filter((l) => l.status === 'in-progress').length;
  const pendingLessons = lessons.filter((l) => l.status === 'pending').length;

  const totalCourseLessons = courses.reduce((sum, c) => sum + c.totalLessons, 0);
  const totalCourseCompleted = courses.reduce((sum, c) => sum + c.lessonsCompleted, 0);
  const overallPercent =
    totalCourseLessons > 0 ? Math.round((totalCourseCompleted / totalCourseLessons) * 100) : 0;

  const averageQuizPercent =
    attempts.length > 0
      ? Math.round(attempts.reduce((sum, a) => sum + a.percent, 0) / attempts.length)
      : 0;

  return {
    completedLessons,
    inProgressLessons,
    pendingLessons,
    overallPercent,
    averageQuizPercent,
  };
}
