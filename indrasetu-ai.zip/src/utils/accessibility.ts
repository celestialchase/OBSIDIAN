import { AccessibilitySettings, BackgroundThemeId, ContentWidthOption, FontFamilyOption } from '../types';

export const STORAGE_KEY_ACCESSIBILITY = 'indrasetu_accessibility_v1';

export const BACKGROUND_THEMES: Record<
  BackgroundThemeId,
  { id: BackgroundThemeId; label: string; bgHex: string; textHex: string; borderHex: string }
> = {
  cream: {
    id: 'cream',
    label: 'Warm Cream',
    bgHex: '#FAF9F6',
    textHex: '#243447',
    borderHex: '#E6DFD1',
  },
  yellow: {
    id: 'yellow',
    label: 'Light Yellow',
    bgHex: '#FEF9DC',
    textHex: '#243447',
    borderHex: '#EADCA6',
  },
  peach: {
    id: 'peach',
    label: 'Soft Peach',
    bgHex: '#FDECE2',
    textHex: '#243447',
    borderHex: '#ECC7B3',
  },
  green: {
    id: 'green',
    label: 'Light Green',
    bgHex: '#E6F5EE',
    textHex: '#1D332B',
    borderHex: '#BBE0CF',
  },
  blue: {
    id: 'blue',
    label: 'Light Blue',
    bgHex: '#EAF3FF',
    textHex: '#1F3247',
    borderHex: '#C5DCF6',
  },
  white: {
    id: 'white',
    label: 'Default White',
    bgHex: '#FFFFFF',
    textHex: '#243447',
    borderHex: '#DCE5EF',
  },
};

export const DEFAULT_ACCESSIBILITY_SETTINGS: AccessibilitySettings = {
  dyslexiaMode: false,
  focusMode: false,
  readingRuler: false,
  textToSpeech: false,
  highContrast: false,
  screenReader: false,
  biggerText: false,
  smallText: false,
  lineHeightEnabled: false,
  highlightLinks: false,
  textSpacingEnabled: false,
  hideImages: false,
  customCursor: false,
  darkMode: false,
  invertColors: false,
  fontFamily: 'jakarta',
  fontSizePercent: 100,
  lineSpacing: 1.6,
  letterSpacing: 0.01,
  wordSpacing: 0,
  paragraphSpacing: 1.2,
  contentWidth: 'standard',
  backgroundTheme: 'cream',
  ttsRate: 1.0,
  captionsEnabled: true,
  captionSize: 'md',
  captionBackground: 'dark',
  islPanelDefaultVisible: true,
};

export const DYSLEXIA_PRESET_SETTINGS: Partial<AccessibilitySettings> = {
  dyslexiaMode: true,
  fontFamily: 'atkinson',
  fontSizePercent: 120,
  lineSpacing: 1.8,
  letterSpacing: 0.04,
  wordSpacing: 0.08,
  paragraphSpacing: 1.5,
  backgroundTheme: 'cream',
};

export function clampNumber(value: number, min: number, max: number): number {
  if (Number.isNaN(value)) return min;
  return Math.min(max, Math.max(min, value));
}

export function stepFontSize(currentPercent: number, delta: number): number {
  return clampNumber(Math.round((currentPercent + delta) / 5) * 5, 85, 160);
}

export function stepLineSpacing(current: number, delta: number): number {
  return clampNumber(Number((current + delta).toFixed(1)), 1.3, 2.2);
}

export function stepLetterSpacing(current: number, delta: number): number {
  return clampNumber(Number((current + delta).toFixed(2)), 0, 0.14);
}

export function getFontSizeLabel(percent: number): string {
  if (percent <= 95) return 'Compact';
  if (percent <= 110) return 'Standard';
  if (percent <= 130) return 'Large';
  return 'Extra Large';
}

export function getLetterSpacingLabel(em: number): string {
  if (em <= 0.015) return 'Normal';
  if (em <= 0.045) return 'Moderate';
  return 'Wide';
}

export function getContentMaxWidthPx(width: ContentWidthOption): number {
  switch (width) {
    case 'narrow':
      return 620;
    case 'wide':
      return 920;
    default:
      return 740;
  }
}

export function getFontFamilyCss(font: FontFamilyOption, dyslexiaMode: boolean): string {
  if (font === 'atkinson' || (dyslexiaMode && font === 'jakarta')) {
    return "'Atkinson Hyperlegible', Arial, sans-serif";
  }
  if (font === 'arial') {
    return 'Arial, Helvetica, sans-serif';
  }
  return "'Plus Jakarta Sans', Arial, sans-serif";
}

export interface ComputedReadingStyle {
  fontFamily: string;
  fontSizePx: number;
  rootFontSizePx: number;
  lineHeight: number;
  letterSpacingEm: string;
  wordSpacingEm: string;
  paragraphSpacingRem: string;
  maxWidthPx: number;
  backgroundColor: string;
  textColor: string;
  borderColor: string;
}

export function computeReadingStyles(settings: AccessibilitySettings): ComputedReadingStyle {
  const safePercent = clampNumber(settings.fontSizePercent, 85, 160);
  const safeLine = clampNumber(settings.lineSpacing, 1.3, 2.2);
  const safeLetter = clampNumber(settings.letterSpacing, 0, 0.14);
  const safeWord = clampNumber(settings.wordSpacing ?? 0, 0, 0.25);
  const safePara = clampNumber(settings.paragraphSpacing, 0.8, 2.4);

  const theme = BACKGROUND_THEMES[settings.backgroundTheme] ?? BACKGROUND_THEMES.cream;
  const fontSizePx = Number(((16 * safePercent) / 100).toFixed(1));
  // Scale root rem gently so Bigger Text / Small Text visibly changes all UI typography without breaking layout
  const rootFontSizePx = Number(clampNumber((16 * safePercent) / 100, 13.6, 20.8).toFixed(1));

  return {
    fontFamily: getFontFamilyCss(settings.fontFamily, settings.dyslexiaMode),
    fontSizePx,
    rootFontSizePx,
    lineHeight: safeLine,
    letterSpacingEm: `${safeLetter}em`,
    wordSpacingEm: `${safeWord}em`,
    paragraphSpacingRem: `${safePara}rem`,
    maxWidthPx: getContentMaxWidthPx(settings.contentWidth),
    backgroundColor: settings.highContrast
      ? '#FFFFFF'
      : settings.darkMode && settings.backgroundTheme === 'cream'
      ? '#162032'
      : theme.bgHex,
    textColor: settings.highContrast
      ? '#090D14'
      : settings.darkMode && settings.backgroundTheme === 'cream'
      ? '#F1F5F9'
      : theme.textHex,
    borderColor: settings.highContrast
      ? '#090D14'
      : settings.darkMode && settings.backgroundTheme === 'cream'
      ? '#334155'
      : theme.borderHex,
  };
}

export function splitIntoSentences(text: string): string[] {
  if (!text || !text.trim()) return [];
  const matches = text.match(/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g);
  if (!matches) return [text.trim()];
  return matches.map((s) => s.trim()).filter(Boolean);
}

export function loadAccessibilitySettings(): AccessibilitySettings {
  if (typeof window === 'undefined') return DEFAULT_ACCESSIBILITY_SETTINGS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY_ACCESSIBILITY);
    if (!raw) return DEFAULT_ACCESSIBILITY_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AccessibilitySettings>;
    return {
      ...DEFAULT_ACCESSIBILITY_SETTINGS,
      ...parsed,
      fontSizePercent: clampNumber(
        Number(parsed.fontSizePercent ?? DEFAULT_ACCESSIBILITY_SETTINGS.fontSizePercent),
        85,
        160
      ),
      lineSpacing: clampNumber(
        Number(parsed.lineSpacing ?? DEFAULT_ACCESSIBILITY_SETTINGS.lineSpacing),
        1.3,
        2.2
      ),
      letterSpacing: clampNumber(
        Number(parsed.letterSpacing ?? DEFAULT_ACCESSIBILITY_SETTINGS.letterSpacing),
        0,
        0.14
      ),
    };
  } catch {
    return DEFAULT_ACCESSIBILITY_SETTINGS;
  }
}

export function saveAccessibilitySettings(settings: AccessibilitySettings): boolean {
  if (typeof window === 'undefined') return false;
  try {
    window.localStorage.setItem(STORAGE_KEY_ACCESSIBILITY, JSON.stringify(settings));
    return true;
  } catch {
    return false;
  }
}

export function clearStoredAccessibilitySettings(): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(STORAGE_KEY_ACCESSIBILITY);
  } catch {
    // ignore storage errors
  }
}

