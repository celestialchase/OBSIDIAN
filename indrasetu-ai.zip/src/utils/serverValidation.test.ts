import assert from 'node:assert/strict';
import test from 'node:test';
import {
  classifyGeminiError,
  parseGeminiJson,
  validateDoubtRequest,
  validateGenerateQuizRequest,
  validateSimplifyRequest,
  validateTranscribeRequest,
  validateVisualConceptRequest,
} from './serverValidation';

test('validateDoubtRequest enforces question bounds, mode allowlist, and safe image MIMEs', () => {
  assert.equal(validateDoubtRequest({}).ok, false);
  assert.equal(validateDoubtRequest({ question: '   ' }).ok, false);
  assert.equal(validateDoubtRequest({ question: 'x'.repeat(4001) }).ok, false);
  assert.equal(
    validateDoubtRequest({ question: 'What is osmosis?', mode: 'hacked' }).ok,
    false
  );
  assert.equal(
    validateDoubtRequest({
      question: 'Read diagram',
      imageBase64: 'data:image/svg+xml;base64,PHN2Zz4=',
      imageMimeType: 'image/svg+xml',
    }).ok,
    false
  );

  const valid = validateDoubtRequest({
    question: '  Explain stomata  ',
    mode: 'visual',
    subject: 'Science',
    grade: 'Class 8',
    imageBase64: 'data:image/png;base64,AAAA',
    imageMimeType: 'image/png',
  });
  assert.equal(valid.ok, true);
  if (valid.ok) {
    assert.equal(valid.data.question, 'Explain stomata');
    assert.equal(valid.data.imageBase64, 'AAAA');
  }
});

test('validateSimplifyRequest rejects empty or oversized text', () => {
  assert.equal(validateSimplifyRequest({ text: '' }).ok, false);
  assert.equal(validateSimplifyRequest({ text: 'a'.repeat(12001) }).ok, false);
  const ok = validateSimplifyRequest({ text: 'Plants absorb sunlight.', title: 'Leaf' });
  assert.equal(ok.ok, true);
});

test('validateVisualConceptRequest enforces non-empty topic <= 300 chars', () => {
  assert.equal(validateVisualConceptRequest({ topic: '  ' }).ok, false);
  assert.equal(validateVisualConceptRequest({ topic: 'x'.repeat(301) }).ok, false);
  assert.equal(validateVisualConceptRequest({ topic: 'Water Cycle' }).ok, true);
});

test('validateGenerateQuizRequest rejects empty topic and out-of-range count', () => {
  assert.equal(validateGenerateQuizRequest({ topic: '' }).ok, false);
  assert.equal(validateGenerateQuizRequest({ topic: '   ' }).ok, false);
  assert.equal(validateGenerateQuizRequest({ topic: 'Fractions', count: 99 }).ok, false);
  const ok = validateGenerateQuizRequest({ topic: 'Fractions', count: 1 });
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.data.count, 2);
  }
});

test('validateTranscribeRequest normalizes codec suffix and rejects invalid audio types', () => {
  assert.equal(validateTranscribeRequest({ audioBase64: '' }).ok, false);
  assert.equal(
    validateTranscribeRequest({ audioBase64: 'AAAA', mimeType: 'application/javascript' }).ok,
    false
  );
  const ok = validateTranscribeRequest({
    audioBase64: 'data:audio/webm;codecs=opus;base64,T2dnUw==',
    mimeType: 'audio/webm;codecs=opus',
  });
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.data.mimeType, 'audio/webm');
    assert.equal(ok.data.audioBase64, 'T2dnUw==');
  }

  const m4a = validateTranscribeRequest({
    audioBase64: 'AAAA',
    mimeType: 'audio/x-m4a',
  });
  assert.equal(m4a.ok, true);
  if (m4a.ok) {
    assert.equal(m4a.data.mimeType, 'audio/mp4');
  }
});

test('classifyGeminiError maps upstream Gemini errors to accurate HTTP status codes', () => {
  assert.deepEqual(
    classifyGeminiError(new SyntaxError('Unexpected token in JSON')),
    {
      status: 502,
      error: 'The AI model returned an incomplete response. Please try again.',
    }
  );

  const quota = classifyGeminiError(new Error('429 RESOURCE_EXHAUSTED quota exceeded'));
  assert.equal(quota.status, 429);
  assert.match(quota.error, /rate limit/i);

  const denied = classifyGeminiError(new Error('403 PERMISSION_DENIED API_KEY_INVALID'));
  assert.equal(denied.status, 403);
  assert.match(denied.error, /API_KEY_INVALID/);

  const badArg = classifyGeminiError(new Error('400 INVALID_ARGUMENT unsupported image'));
  assert.equal(badArg.status, 400);
  assert.match(badArg.error, /INVALID_ARGUMENT/);

  const generic = classifyGeminiError(new Error('ECONNRESET'));
  assert.equal(generic.status, 503);
  assert.equal(generic.error, 'ECONNRESET');
});

test('parseGeminiJson parses valid JSON, handles empty strings via fallback, and throws SyntaxError on malformed text', () => {
  assert.deepEqual(parseGeminiJson<{ a: number }>('{"a":1}', { a: 0 }), { a: 1 });
  assert.deepEqual(parseGeminiJson<{ a: number }>(undefined, { a: 0 }), { a: 0 });
  assert.deepEqual(parseGeminiJson<{ a: number }>('   ', { a: 0 }), { a: 0 });
  assert.throws(() => parseGeminiJson('not-json', { a: 0 }), SyntaxError);
});


