export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateLoginForm(email: string, password: string): ValidationResult {
  const errors: Record<string, string> = {};
  if (!email.trim()) {
    errors.email = 'Please enter your email address.';
  } else if (!EMAIL_REGEX.test(email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!password) {
    errors.password = 'Please enter your password.';
  } else if (password.length < 6) {
    errors.password = 'Password must be at least 6 characters.';
  }
  return { valid: Object.keys(errors).length === 0, errors };
}

export function validateRegistrationForm(
  name: string,
  email: string,
  password: string,
  grade: string
): ValidationResult {
  const errors: Record<string, string> = {};
  if (!name.trim() || name.trim().length < 2) {
    errors.name = 'Please enter your full name (at least 2 characters).';
  }
  if (!email.trim()) {
    errors.email = 'Please enter your email address.';
  } else if (!EMAIL_REGEX.test(email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!password || password.length < 6) {
    errors.password = 'Create a password with at least 6 characters.';
  }
  if (!grade.trim()) {
    errors.grade = 'Please select your class.';
  }
  return { valid: Object.keys(errors).length === 0, errors };
}

export function validatePasswordRecoveryForm(email: string): ValidationResult {
  const errors: Record<string, string> = {};
  if (!email.trim()) {
    errors.email = 'Please enter your registered email address.';
  } else if (!EMAIL_REGEX.test(email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  return { valid: Object.keys(errors).length === 0, errors };
}
