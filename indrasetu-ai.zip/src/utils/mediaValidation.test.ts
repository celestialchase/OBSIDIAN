import assert from 'node:assert/strict';
import test from 'node:test';
import {
  isDirectVideoFileUrl,
  MAX_DOUBT_IMAGE_BYTES,
  MAX_SPEECH_AUDIO_BYTES,
  validateDoubtImageFile,
  validateExternalVideoUrl,
  validateSpeechAudioFile,
} from './mediaValidation';

test('validateDoubtImageFile accepts PNG/JPEG/WEBP/GIF within 8 MB and rejects unsupported or oversized files', () => {
  const okPng = validateDoubtImageFile({ type: 'image/png', size: 1024, name: 'diagram.png' });
  assert.equal(okPng.ok, true);
  if (okPng.ok) assert.equal(okPng.normalizedMime, 'image/png');

  const okFallbackExt = validateDoubtImageFile({ type: '', size: 2048, name: 'leaf.webp' });
  assert.equal(okFallbackExt.ok, true);
  if (okFallbackExt.ok) assert.equal(okFallbackExt.normalizedMime, 'image/webp');

  const badSvg = validateDoubtImageFile({ type: 'image/svg+xml', size: 512, name: 'icon.svg' });
  assert.equal(badSvg.ok, false);

  const badPdf = validateDoubtImageFile({ type: 'application/pdf', size: 512, name: 'doc.pdf' });
  assert.equal(badPdf.ok, false);

  const badEmpty = validateDoubtImageFile({ type: 'image/png', size: 0, name: 'empty.png' });
  assert.equal(badEmpty.ok, false);

  const badBig = validateDoubtImageFile({
    type: 'image/jpeg',
    size: MAX_DOUBT_IMAGE_BYTES + 1,
    name: 'huge.jpg',
  });
  assert.equal(badBig.ok, false);
});

test('validateSpeechAudioFile accepts supported audio MIMEs, normalizes m4a/codecs, and rejects unsupported/oversized files', () => {
  const okMp3 = validateSpeechAudioFile({ type: 'audio/mpeg', size: 4096, name: 'clip.mp3' });
  assert.equal(okMp3.ok, true);

  const okWebmCodec = validateSpeechAudioFile({
    type: 'audio/webm;codecs=opus',
    size: 4096,
    name: 'voice.webm',
  });
  assert.equal(okWebmCodec.ok, true);
  if (okWebmCodec.ok) assert.equal(okWebmCodec.normalizedMime, 'audio/webm');

  const okM4a = validateSpeechAudioFile({ type: 'audio/x-m4a', size: 4096, name: 'lecture.m4a' });
  assert.equal(okM4a.ok, true);
  if (okM4a.ok) assert.equal(okM4a.normalizedMime, 'audio/mp4');

  const badText = validateSpeechAudioFile({ type: 'text/plain', size: 128, name: 'notes.txt' });
  assert.equal(badText.ok, false);

  const badSize = validateSpeechAudioFile({
    type: 'audio/wav',
    size: MAX_SPEECH_AUDIO_BYTES + 10,
    name: 'long.wav',
  });
  assert.equal(badSize.ok, false);
});

test('validateExternalVideoUrl permits empty optional value or valid HTTPS URLs, and rejects http/blob/data URLs', () => {
  const empty = validateExternalVideoUrl('   ');
  assert.equal(empty.ok, true);
  if (empty.ok) assert.equal(empty.normalizedUrl, undefined);

  const httpsMp4 = validateExternalVideoUrl('  https://cdn.example.edu/isl/photosynthesis.mp4  ');
  assert.equal(httpsMp4.ok, true);
  if (httpsMp4.ok) {
    assert.equal(httpsMp4.normalizedUrl, 'https://cdn.example.edu/isl/photosynthesis.mp4');
    assert.equal(isDirectVideoFileUrl(httpsMp4.normalizedUrl!), true);
  }

  const httpsPortal = validateExternalVideoUrl('https://diksha.gov.in/play/collection/do_123');
  assert.equal(httpsPortal.ok, true);
  if (httpsPortal.ok) {
    assert.equal(isDirectVideoFileUrl(httpsPortal.normalizedUrl!), false);
  }

  assert.equal(validateExternalVideoUrl('http://example.edu/clip.mp4').ok, false);
  assert.equal(validateExternalVideoUrl('blob:https://example.edu/1234').ok, false);
  assert.equal(validateExternalVideoUrl('data:video/mp4;base64,AAAA').ok, false);
  assert.equal(validateExternalVideoUrl('javascript:alert(1)').ok, false);
  assert.equal(validateExternalVideoUrl('not a url').ok, false);
  assert.equal(validateExternalVideoUrl(`https://example.edu/${'a'.repeat(2000)}`).ok, false);
});
