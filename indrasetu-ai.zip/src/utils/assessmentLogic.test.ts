import test from 'node:test';
import assert from 'node:assert/strict';
import { computeProgressStats, evaluateQuizAnswer } from './assessmentLogic';
import { Course, Lesson, QuizAttempt, QuizQuestion } from '../types';

test('evaluateQuizAnswer grades MCQ and fill-in-the-blank case-insensitively', () => {
  const mcq: QuizQuestion = {
    id: 'q1',
    subject: 'Science',
    topic: 'Photosynthesis',
    type: 'mcq',
    instructions: 'Select one option.',
    prompt: 'Which gas is released during photosynthesis?',
    options: ['Nitrogen', 'Oxygen', 'Carbon Monoxide'],
    correctAnswer: 'Oxygen',
    explanation: 'Plants release oxygen as a byproduct.',
  };

  assert.equal(evaluateQuizAnswer(mcq, 'Oxygen').isCorrect, true);
  assert.equal(evaluateQuizAnswer(mcq, 'Nitrogen').isCorrect, false);

  const fillBlank: QuizQuestion = {
    ...mcq,
    id: 'q2',
    type: 'fill-blank',
    correctAnswer: 'Chlorophyll',
  };
  assert.equal(evaluateQuizAnswer(fillBlank, '  chlorophyll  ').isCorrect, true);
  assert.equal(evaluateQuizAnswer(fillBlank, '').isCorrect, false);
});

test('evaluateQuizAnswer grades matching pairs and sequence ordering', () => {
  const matching: QuizQuestion = {
    id: 'q3',
    subject: 'Science',
    topic: 'Plant Parts',
    type: 'matching',
    instructions: 'Match each part with its job.',
    prompt: 'Match plant parts',
    matchingPairs: [
      { left: 'Roots', right: 'Absorb water' },
      { left: 'Leaves', right: 'Make food' },
    ],
    correctAnswer: 'Roots->Absorb water; Leaves->Make food',
    explanation: 'Roots absorb water and leaves make food.',
  };

  assert.equal(
    evaluateQuizAnswer(matching, { Roots: 'Absorb water', Leaves: 'Make food' }).isCorrect,
    true
  );
  assert.equal(
    evaluateQuizAnswer(matching, { Roots: 'Make food', Leaves: 'Absorb water' }).isCorrect,
    false
  );

  const sequence: QuizQuestion = {
    id: 'q4',
    subject: 'Science',
    topic: 'Water Cycle',
    type: 'sequence',
    instructions: 'Order the steps.',
    prompt: 'Order water cycle stages',
    sequenceItems: ['Evaporation', 'Condensation', 'Precipitation'],
    correctAnswer: 'Evaporation -> Condensation -> Precipitation',
    explanation: 'Water evaporates, condenses into clouds, then falls as rain.',
  };

  assert.equal(
    evaluateQuizAnswer(sequence, ['Evaporation', 'Condensation', 'Precipitation']).isCorrect,
    true
  );
  assert.equal(
    evaluateQuizAnswer(sequence, ['Condensation', 'Evaporation', 'Precipitation']).isCorrect,
    false
  );
});

test('computeProgressStats aggregates lesson statuses and overall percentage', () => {
  const lessons: Lesson[] = [
    { id: '1', courseId: 'c1', subject: 'Science', grade: 'Class 8', title: 'L1', summary: '', status: 'completed', chapters: [] },
    { id: '2', courseId: 'c1', subject: 'Science', grade: 'Class 8', title: 'L2', summary: '', status: 'in-progress', chapters: [] },
    { id: '3', courseId: 'c2', subject: 'Mathematics', grade: 'Class 8', title: 'L3', summary: '', status: 'pending', chapters: [] },
  ];
  const courses: Course[] = [
    { id: 'c1', subject: 'Science', title: 'Science', grade: 'Class 8', lessonsCompleted: 7, totalLessons: 10, progressPercent: 70, currentChapter: 'Ch 2', colorToken: 'teal' },
    { id: 'c2', subject: 'Mathematics', title: 'Math', grade: 'Class 8', lessonsCompleted: 5, totalLessons: 10, progressPercent: 50, currentChapter: 'Ch 3', colorToken: 'blue' },
  ];
  const attempts: QuizAttempt[] = [
    { id: 'a1', subject: 'Science', topic: 'Plants', score: 4, total: 5, percent: 80, completedAt: 'Today' },
    { id: 'a2', subject: 'Mathematics', topic: 'Fractions', score: 5, total: 5, percent: 100, completedAt: 'Today' },
  ];

  const stats = computeProgressStats(lessons, courses, attempts);
  assert.equal(stats.completedLessons, 1);
  assert.equal(stats.inProgressLessons, 1);
  assert.equal(stats.pendingLessons, 1);
  assert.equal(stats.overallPercent, 60);
  assert.equal(stats.averageQuizPercent, 90);
});
