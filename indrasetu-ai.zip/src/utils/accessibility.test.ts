import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeReadingStyles,
  DEFAULT_ACCESSIBILITY_SETTINGS,
  DYSLEXIA_PRESET_SETTINGS,
  splitIntoSentences,
  stepFontSize,
  stepLetterSpacing,
  stepLineSpacing,
} from './accessibility';

test('computeReadingStyles applies Atkinson Hyperlegible and larger text in Dyslexia Mode', () => {
  const styles = computeReadingStyles({
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    ...DYSLEXIA_PRESET_SETTINGS,
  });

  assert.match(styles.fontFamily, /Atkinson Hyperlegible/);
  assert.equal(styles.fontSizePx, 19.2);
  assert.equal(styles.rootFontSizePx, 19.2);
  assert.equal(styles.lineHeight, 1.8);
  assert.equal(styles.letterSpacingEm, '0.04em');
  assert.equal(styles.wordSpacingEm, '0.08em');
  assert.equal(styles.backgroundColor, '#FAF9F6');
});

test('computeReadingStyles overrides surface colors when High Contrast or Dark Mode is enabled', () => {
  const hcStyles = computeReadingStyles({
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    backgroundTheme: 'peach',
    highContrast: true,
  });
  assert.equal(hcStyles.backgroundColor, '#FFFFFF');
  assert.equal(hcStyles.textColor, '#090D14');
  assert.equal(hcStyles.borderColor, '#090D14');

  const darkStyles = computeReadingStyles({
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    darkMode: true,
    backgroundTheme: 'cream',
  });
  assert.equal(darkStyles.backgroundColor, '#162032');
  assert.equal(darkStyles.textColor, '#F1F5F9');
});

test('computeReadingStyles clamps rootFontSizePx for Bigger Text and Small Text', () => {
  const bigStyles = computeReadingStyles({
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    biggerText: true,
    fontSizePercent: 150,
  });
  assert.equal(bigStyles.rootFontSizePx, 20.8);

  const smallStyles = computeReadingStyles({
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    smallText: true,
    fontSizePercent: 85,
  });
  assert.equal(smallStyles.rootFontSizePx, 13.6);
});

test('step helpers clamp values cleanly within accessible bounds', () => {
  assert.equal(stepFontSize(160, 10), 160);
  assert.equal(stepFontSize(85, -10), 85);
  assert.equal(stepLineSpacing(2.2, 0.2), 2.2);
  assert.equal(stepLineSpacing(1.3, -0.2), 1.3);
  assert.equal(stepLetterSpacing(0.14, 0.02), 0.14);
  assert.equal(stepLetterSpacing(0, -0.02), 0);
});

test('splitIntoSentences breaks prose into readable sentences without dropping text', () => {
  const sentences = splitIntoSentences(
    'Photosynthesis happens in leaves. Plants use sunlight! Does oxygen come out?'
  );
  assert.deepEqual(sentences, [
    'Photosynthesis happens in leaves.',
    'Plants use sunlight!',
    'Does oxygen come out?',
  ]);
  assert.deepEqual(splitIntoSentences('   '), []);
});
