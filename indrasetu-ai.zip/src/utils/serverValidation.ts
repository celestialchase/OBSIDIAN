export const ALLOWED_DOUBT_MODES = ['simple', 'detailed', 'visual'] as const;
export type AllowedDoubtMode = (typeof ALLOWED_DOUBT_MODES)[number];

export const ALLOWED_IMAGE_MIMES = [
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
  'image/gif',
] as const;

export const ALLOWED_AUDIO_MIMES = [
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave',
  'audio/webm',
  'audio/ogg',
  'audio/mp4',
  'audio/aac',
] as const;

export type ValidationResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string };

export function stripDataUriPrefix(raw: string): string {
  const idx = raw.indexOf(',');
  if (raw.startsWith('data:') && idx !== -1) {
    return raw.slice(idx + 1).trim();
  }
  return raw.trim();
}

export function normalizeMimeType(raw: unknown, fallback: string): string {
  if (typeof raw !== 'string' || !raw.trim()) return fallback;
  const base = raw.split(';')[0].trim().toLowerCase();
  if (base === 'audio/x-m4a' || base === 'audio/m4a') return 'audio/mp4';
  return base;
}

export function validateDoubtRequest(body: unknown): ValidationResult<{
  question: string;
  mode: AllowedDoubtMode;
  subject: string;
  grade: string;
  imageBase64?: string;
  imageMimeType: string;
}> {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  const rawQ = b.question;
  if (typeof rawQ !== 'string' || !rawQ.trim()) {
    return { ok: false, error: 'Please enter a question before asking.' };
  }
  const question = rawQ.trim();
  if (question.length > 4000) {
    return { ok: false, error: 'Question must be 4000 characters or fewer.' };
  }

  const rawMode = b.mode === undefined ? 'simple' : b.mode;
  if (typeof rawMode !== 'string' || !ALLOWED_DOUBT_MODES.includes(rawMode as AllowedDoubtMode)) {
    return { ok: false, error: 'Explanation mode must be simple, detailed, or visual.' };
  }

  const subject =
    typeof b.subject === 'string' && b.subject.trim()
      ? b.subject.trim().slice(0, 60)
      : 'General';
  const grade =
    typeof b.grade === 'string' && b.grade.trim()
      ? b.grade.trim().slice(0, 40)
      : 'Class 8';

  const imageMimeType = normalizeMimeType(b.imageMimeType, 'image/png');
  let imageBase64: string | undefined;
  if (b.imageBase64 !== undefined && b.imageBase64 !== null && b.imageBase64 !== '') {
    if (typeof b.imageBase64 !== 'string') {
      return { ok: false, error: 'Invalid image attachment payload.' };
    }
    if (b.imageBase64.length > 14_000_000) {
      return { ok: false, error: 'Attached image exceeds maximum allowed size.' };
    }
    if (!ALLOWED_IMAGE_MIMES.includes(imageMimeType as (typeof ALLOWED_IMAGE_MIMES)[number])) {
      return { ok: false, error: 'Unsupported image format. Use PNG, JPEG, WEBP, or GIF.' };
    }
    const clean = stripDataUriPrefix(b.imageBase64);
    if (!clean) {
      return { ok: false, error: 'Attached image payload is empty.' };
    }
    imageBase64 = clean;
  }

  return {
    ok: true,
    data: {
      question,
      mode: rawMode as AllowedDoubtMode,
      subject,
      grade,
      imageBase64,
      imageMimeType,
    },
  };
}

export function validateSimplifyRequest(body: unknown): ValidationResult<{
  text: string;
  title: string;
}> {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  if (typeof b.text !== 'string' || !b.text.trim()) {
    return { ok: false, error: 'Lesson text is required.' };
  }
  const text = b.text.trim();
  if (text.length > 12_000) {
    return { ok: false, error: 'Lesson text exceeds maximum length (12,000 characters).' };
  }
  const title =
    typeof b.title === 'string' && b.title.trim()
      ? b.title.trim().slice(0, 200)
      : 'Lesson Passage';

  return { ok: true, data: { text, title } };
}

export function validateVisualConceptRequest(body: unknown): ValidationResult<{
  topic: string;
  subject: string;
  grade: string;
}> {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  if (typeof b.topic !== 'string' || !b.topic.trim()) {
    return { ok: false, error: 'Please provide a topic to visualize.' };
  }
  const topic = b.topic.trim();
  if (topic.length > 300) {
    return { ok: false, error: 'Topic must be 300 characters or fewer.' };
  }
  const subject =
    typeof b.subject === 'string' && b.subject.trim()
      ? b.subject.trim().slice(0, 60)
      : 'Science';
  const grade =
    typeof b.grade === 'string' && b.grade.trim()
      ? b.grade.trim().slice(0, 40)
      : 'Class 8';

  return { ok: true, data: { topic, subject, grade } };
}

export function validateGenerateQuizRequest(body: unknown): ValidationResult<{
  topic: string;
  subject: string;
  grade: string;
  count: number;
}> {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  if (typeof b.topic !== 'string' || !b.topic.trim()) {
    return { ok: false, error: 'Quiz topic is required.' };
  }
  const topic = b.topic.trim();
  if (topic.length > 300) {
    return { ok: false, error: 'Quiz topic must be 300 characters or fewer.' };
  }
  const subject =
    typeof b.subject === 'string' && b.subject.trim()
      ? b.subject.trim().slice(0, 60)
      : 'Science';
  const grade =
    typeof b.grade === 'string' && b.grade.trim()
      ? b.grade.trim().slice(0, 40)
      : 'Class 8';

  let count = 3;
  if (b.count !== undefined) {
    const num = Number(b.count);
    if (!Number.isFinite(num) || num < 1 || num > 10) {
      return { ok: false, error: 'Quiz question count must be between 1 and 10.' };
    }
    count = Math.max(2, Math.min(5, Math.round(num)));
  }

  return { ok: true, data: { topic, subject, grade, count } };
}

export function validateTranscribeRequest(body: unknown): ValidationResult<{
  audioBase64: string;
  mimeType: string;
  lessonTitle: string;
}> {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  if (typeof b.audioBase64 !== 'string' || !b.audioBase64.trim()) {
    return { ok: false, error: 'Audio data is required for transcription.' };
  }
  if (b.audioBase64.length > 16_000_000) {
    return { ok: false, error: 'Audio upload exceeds maximum allowed payload size.' };
  }
  const cleanBase64 = stripDataUriPrefix(b.audioBase64);
  if (!cleanBase64) {
    return { ok: false, error: 'Audio upload payload is empty.' };
  }
  const mimeType = normalizeMimeType(b.mimeType, 'audio/mp3');
  if (!ALLOWED_AUDIO_MIMES.includes(mimeType as (typeof ALLOWED_AUDIO_MIMES)[number])) {
    return {
      ok: false,
      error: 'Unsupported audio format. Please upload MP3, WAV, WebM, OGG, M4A/MP4, or AAC audio.',
    };
  }
  const lessonTitle =
    typeof b.lessonTitle === 'string' && b.lessonTitle.trim()
      ? b.lessonTitle.trim().slice(0, 200)
      : 'Educational Audio';

  return {
    ok: true,
    data: { audioBase64: cleanBase64, mimeType, lessonTitle },
  };
}

export function formatGeminiError(error: unknown): string {
  const raw = error instanceof Error ? error.message : 'Unable to reach AI service.';
  try {
    const parsed = JSON.parse(raw);
    const msg = parsed?.error?.message;
    if (typeof msg === 'string' && msg.trim()) return msg;
  } catch {
    // not JSON, return trimmed message
  }
  return raw.length > 220 ? 'The AI tutor is temporarily unavailable. Please try again shortly.' : raw;
}

export function classifyGeminiError(error: unknown): { status: number; error: string } {
  if (error instanceof SyntaxError) {
    return {
      status: 502,
      error: 'The AI model returned an incomplete response. Please try again.',
    };
  }
  const raw = error instanceof Error ? error.message : '';
  const friendly = formatGeminiError(error);
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return { status: 429, error: 'AI rate limit or quota reached. Please wait a moment and retry.' };
  }
  if (raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
    return { status: 403, error: friendly };
  }
  if (raw.includes('INVALID_ARGUMENT') || raw.includes('400')) {
    return { status: 400, error: friendly };
  }
  return { status: 503, error: friendly };
}

export function parseGeminiJson<T>(rawText: string | undefined, fallback: T): T {
  const trimmed = (rawText ?? '').trim();
  if (!trimmed) return fallback;
  return JSON.parse(trimmed) as T;
}
