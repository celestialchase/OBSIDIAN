import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateDoubtPrompt,
  validateNoteInput,
  validateProfilePatch,
  validateQuizAttemptInput,
} from './firestoreValidation';

test('validateProfilePatch enforces name bounds and CBSE grades', () => {
  assert.equal(validateProfilePatch({ name: 'A', grade: 'Class 8' }).valid, false);
  assert.equal(validateProfilePatch({ name: 'Aarav', grade: 'Class 12' }).valid, false);
  const ok = validateProfilePatch({ name: '  Aarav Verma  ', grade: 'Class 8' });
  assert.equal(ok.valid, true);
  assert.equal(ok.cleanName, 'Aarav Verma');
});

test('validateNoteInput rejects empty or oversized fields', () => {
  assert.equal(
    validateNoteInput({ title: '', content: 'Hello', subject: 'Science' }).valid,
    false
  );
  assert.equal(
    validateNoteInput({ title: 'Title', content: '   ', subject: 'Science' }).valid,
    false
  );
  assert.equal(
    validateNoteInput({ title: 'Title', content: 'Notes', subject: 'Science' }).valid,
    true
  );
});

test('validateQuizAttemptInput enforces score <= total bounds', () => {
  assert.equal(
    validateQuizAttemptInput({ topic: 'Solar System', score: 5, total: 3 }).valid,
    false
  );
  assert.equal(
    validateQuizAttemptInput({ topic: 'Solar System', score: 3, total: 3 }).valid,
    true
  );
});

test('validateDoubtPrompt enforces non-empty prompt <= 4000 chars', () => {
  assert.equal(validateDoubtPrompt('   ').valid, false);
  assert.equal(validateDoubtPrompt('a'.repeat(4001)).valid, false);
  assert.equal(validateDoubtPrompt('How do stomata work?').valid, true);
});
