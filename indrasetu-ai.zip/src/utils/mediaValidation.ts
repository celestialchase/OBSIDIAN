export const MAX_DOUBT_IMAGE_BYTES = 8 * 1024 * 1024; // 8 MB raw (fits 12 MB JSON body limit when base64-encoded)
export const MAX_SPEECH_AUDIO_BYTES = 8 * 1024 * 1024; // 8 MB raw (fits 12 MB JSON body limit when base64-encoded)
export const MAX_EXTERNAL_VIDEO_URL_LENGTH = 2000;

export const ALLOWED_DOUBT_IMAGE_MIMES = [
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
  'image/gif',
] as const;

export const ALLOWED_SPEECH_AUDIO_MIMES = [
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave',
  'audio/webm',
  'audio/ogg',
  'audio/mp4',
  'audio/aac',
] as const;

const IMAGE_EXT_TO_MIME: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
};

const AUDIO_EXT_TO_MIME: Record<string, string> = {
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.webm': 'audio/webm',
  '.ogg': 'audio/ogg',
  '.m4a': 'audio/mp4',
  '.mp4': 'audio/mp4',
  '.aac': 'audio/aac',
};

export interface MediaFileLike {
  type: string;
  size: number;
  name?: string;
}

export type FileValidationResult =
  | { ok: true; normalizedMime: string }
  | { ok: false; error: string };

export type ExternalUrlValidationResult =
  | { ok: true; normalizedUrl?: string }
  | { ok: false; error: string };

function getExtension(name?: string): string {
  if (!name) return '';
  const idx = name.lastIndexOf('.');
  return idx >= 0 ? name.slice(idx).toLowerCase() : '';
}

export function normalizeMediaMime(rawType: string): string {
  const base = (rawType || '').split(';')[0].trim().toLowerCase();
  if (base === 'audio/x-m4a' || base === 'audio/m4a') {
    return 'audio/mp4';
  }
  return base;
}

export function validateDoubtImageFile(file: MediaFileLike): FileValidationResult {
  const baseType = normalizeMediaMime(file.type);
  const ext = getExtension(file.name);
  const resolvedMime = baseType || IMAGE_EXT_TO_MIME[ext] || '';

  if (
    !resolvedMime ||
    !ALLOWED_DOUBT_IMAGE_MIMES.includes(resolvedMime as (typeof ALLOWED_DOUBT_IMAGE_MIMES)[number])
  ) {
    return {
      ok: false,
      error:
        'Unsupported image format. Please choose a PNG, JPEG, WEBP, or GIF image (maximum 8 MB). SVG, PDF, and video files are not supported.',
    };
  }

  if (!Number.isFinite(file.size) || file.size <= 0) {
    return {
      ok: false,
      error: 'The selected image file is empty. Please choose a valid PNG, JPEG, WEBP, or GIF image.',
    };
  }

  if (file.size > MAX_DOUBT_IMAGE_BYTES) {
    return {
      ok: false,
      error: 'Image file is too large (maximum 8 MB). Please choose a smaller diagram or photo.',
    };
  }

  return { ok: true, normalizedMime: resolvedMime };
}

export function validateSpeechAudioFile(file: MediaFileLike): FileValidationResult {
  const baseType = normalizeMediaMime(file.type);
  const ext = getExtension(file.name);
  const resolvedMime = baseType || AUDIO_EXT_TO_MIME[ext] || '';

  if (
    !resolvedMime ||
    !ALLOWED_SPEECH_AUDIO_MIMES.includes(resolvedMime as (typeof ALLOWED_SPEECH_AUDIO_MIMES)[number])
  ) {
    return {
      ok: false,
      error:
        'Unsupported audio format. Please upload an MP3, WAV, WebM, OGG, M4A/MP4, or AAC audio file (maximum 8 MB).',
    };
  }

  if (!Number.isFinite(file.size) || file.size <= 0) {
    return {
      ok: false,
      error: 'The selected audio file is empty. Please upload a valid audio recording.',
    };
  }

  if (file.size > MAX_SPEECH_AUDIO_BYTES) {
    return {
      ok: false,
      error: 'Audio file is too large (maximum 8 MB). Please upload a shorter clip.',
    };
  }

  return { ok: true, normalizedMime: resolvedMime };
}

export function validateExternalVideoUrl(rawUrl: string): ExternalUrlValidationResult {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return { ok: true, normalizedUrl: undefined };
  }

  if (trimmed.length > MAX_EXTERNAL_VIDEO_URL_LENGTH) {
    return {
      ok: false,
      error: `External video URL must be ${MAX_EXTERNAL_VIDEO_URL_LENGTH} characters or fewer.`,
    };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return {
      ok: false,
      error: 'Please enter a valid external HTTPS video URL (starting with https://).',
    };
  }

  if (parsed.protocol !== 'https:' || !parsed.hostname || !parsed.hostname.includes('.')) {
    return {
      ok: false,
      error:
        'Only verified external HTTPS video URLs (https://...) are supported. Local blob:, data:, or insecure http:// links cannot be saved.',
    };
  }

  return { ok: true, normalizedUrl: parsed.toString() };
}

export function isDirectVideoFileUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return /\.(mp4|webm|ogg|mov)$/i.test(parsed.pathname);
  } catch {
    return false;
  }
}
