export interface FirebaseEnvVars {
  VITE_FIREBASE_API_KEY?: string;
  VITE_FIREBASE_AUTH_DOMAIN?: string;
  VITE_FIREBASE_PROJECT_ID?: string;
  VITE_FIREBASE_MESSAGING_SENDER_ID?: string;
  VITE_FIREBASE_APP_ID?: string;
  VITE_FIREBASE_MEASUREMENT_ID?: string;
  VITE_FIREBASE_DATABASE_ID?: string;
}

export interface FirebaseAppletConfigShape {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId?: string;
  messagingSenderId?: string;
  measurementId?: string;
}

export interface ResolvedFirebaseConfig {
  source: 'env' | 'applet-config';
  options: {
    apiKey: string;
    authDomain: string;
    projectId: string;
    messagingSenderId?: string;
    appId: string;
    measurementId?: string;
  };
  firestoreDatabaseId?: string;
}

const PLACEHOLDER_PREFIXES = ['YOUR_', 'MY_'];

function isConfiguredValue(value: string | undefined): value is string {
  if (!value) return false;
  const trimmed = value.trim();
  if (!trimmed) return false;
  return !PLACEHOLDER_PREFIXES.some((prefix) => trimmed.startsWith(prefix));
}

export function resolveFirebaseClientConfig(
  env: FirebaseEnvVars,
  fallbackConfig: FirebaseAppletConfigShape
): ResolvedFirebaseConfig {
  const hasEnvConfig =
    isConfiguredValue(env.VITE_FIREBASE_API_KEY) &&
    isConfiguredValue(env.VITE_FIREBASE_AUTH_DOMAIN) &&
    isConfiguredValue(env.VITE_FIREBASE_PROJECT_ID) &&
    isConfiguredValue(env.VITE_FIREBASE_APP_ID);

  if (hasEnvConfig) {
    const dbId = env.VITE_FIREBASE_DATABASE_ID?.trim();
    return {
      source: 'env',
      options: {
        apiKey: env.VITE_FIREBASE_API_KEY!.trim(),
        authDomain: env.VITE_FIREBASE_AUTH_DOMAIN!.trim(),
        projectId: env.VITE_FIREBASE_PROJECT_ID!.trim(),
        ...(isConfiguredValue(env.VITE_FIREBASE_MESSAGING_SENDER_ID)
          ? { messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID.trim() }
          : {}),
        appId: env.VITE_FIREBASE_APP_ID!.trim(),
        ...(isConfiguredValue(env.VITE_FIREBASE_MEASUREMENT_ID)
          ? { measurementId: env.VITE_FIREBASE_MEASUREMENT_ID.trim() }
          : {}),
      },
      ...(dbId && dbId !== '(default)' ? { firestoreDatabaseId: dbId } : {}),
    };
  }

  return {
    source: 'applet-config',
    options: {
      apiKey: fallbackConfig.apiKey,
      authDomain: fallbackConfig.authDomain,
      projectId: fallbackConfig.projectId,
      ...(fallbackConfig.messagingSenderId
        ? { messagingSenderId: fallbackConfig.messagingSenderId }
        : {}),
      appId: fallbackConfig.appId,
      ...(fallbackConfig.measurementId ? { measurementId: fallbackConfig.measurementId } : {}),
    },
    ...(fallbackConfig.firestoreDatabaseId && fallbackConfig.firestoreDatabaseId !== '(default)'
      ? { firestoreDatabaseId: fallbackConfig.firestoreDatabaseId }
      : {}),
  };
}
