export type NavRoute =
  | 'landing'
  | 'dashboard'
  | 'learning'
  | 'videos'
  | 'isl'
  | 'visual'
  | 'doubt'
  | 'assessments'
  | 'progress'
  | 'accessibility'
  | 'profile';

export type BackgroundThemeId =
  | 'cream'
  | 'yellow'
  | 'peach'
  | 'green'
  | 'blue'
  | 'white';

export type FontFamilyOption = 'atkinson' | 'arial' | 'jakarta';
export type ContentWidthOption = 'narrow' | 'standard' | 'wide';

export interface AccessibilitySettings {
  dyslexiaMode: boolean;
  focusMode: boolean;
  readingRuler: boolean;
  textToSpeech: boolean;
  highContrast: boolean;
  screenReader: boolean;
  biggerText: boolean;
  smallText: boolean;
  lineHeightEnabled: boolean;
  highlightLinks: boolean;
  textSpacingEnabled: boolean;
  hideImages: boolean;
  customCursor: boolean;
  darkMode: boolean;
  invertColors: boolean;
  fontFamily: FontFamilyOption;
  fontSizePercent: number; // 85 to 160
  lineSpacing: number; // 1.3 to 2.2
  letterSpacing: number; // 0 to 0.14 em
  wordSpacing: number; // 0 to 0.25 em
  paragraphSpacing: number; // 0.8 to 2.4 rem
  contentWidth: ContentWidthOption;
  backgroundTheme: BackgroundThemeId;
  ttsRate: number; // 0.7 to 1.5
  captionsEnabled: boolean;
  captionSize: 'sm' | 'md' | 'lg';
  captionBackground: 'dark' | 'cream' | 'high-contrast';
  islPanelDefaultVisible: boolean;
}

export type UserRole = 'student' | 'teacher';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  grade: string;
  board: string;
  isDemo: boolean;
  emailVerified?: boolean;
}

export type SubjectName =
  | 'English'
  | 'Mathematics'
  | 'Science'
  | 'Social Science'
  | 'Hindi'
  | 'Computer';

export interface Course {
  id: string;
  subject: SubjectName;
  title: string;
  grade: string;
  lessonsCompleted: number;
  totalLessons: number;
  progressPercent: number;
  currentChapter: string;
  colorToken: string;
}

export interface LessonChapter {
  id: string;
  number: number;
  title: string;
  estimatedMinutes: number;
  paragraphs: string[];
  keyTerms: Array<{ term: string; definition: string }>;
  imageSrc?: string;
  imageAlt?: string;
}

export interface Lesson {
  id: string;
  courseId: string;
  subject: SubjectName;
  grade: string;
  title: string;
  summary: string;
  status: 'completed' | 'in-progress' | 'pending';
  chapters: LessonChapter[];
}

export interface CaptionCue {
  id: string;
  startSec: number;
  endSec: number;
  text: string;
  keywords: string[];
  islGloss: string;
  islHandCue: string;
}

export interface VideoLesson {
  id: string;
  subject: SubjectName;
  grade: string;
  title: string;
  durationSec: number;
  thumbnailSrc: string;
  summary: string;
  keywords: string[];
  cues: CaptionCue[];
  visualSteps: Array<{
    atSec: number;
    heading: string;
    caption: string;
    diagramHighlight: string;
  }>;
}

export type ISLCategory =
  | 'Common vocabulary'
  | 'Classroom communication'
  | 'Science terminology'
  | 'Mathematics terminology'
  | 'Educational expressions'
  | 'Frequently used phrases';

export interface ISLEntry {
  id: string;
  createdByUid?: string;
  term: string;
  category: ISLCategory;
  meaning: string;
  handshapeGuide: string;
  usageExample: string;
  isVerifiedClip: boolean;
  verificationLabel: string;
  customVideoUrl?: string;
}

export type ExplanationMode = 'simple' | 'detailed' | 'visual';

export interface DoubtMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  mode?: ExplanationMode;
  subject?: SubjectName;
  keyPoints?: string[];
  visualSteps?: string[];
  imagePreview?: string;
  saved?: boolean;
  timestamp: string;
  source?: 'gemini' | 'offline-guide';
}

export interface CommunicationCard {
  id: string;
  label: string;
  phrase: string;
  category: 'Classroom' | 'Doubt' | 'Need Help' | 'Subjects';
  iconName: string;
}

export type QuestionType = 'mcq' | 'fill-blank' | 'matching' | 'sequence';

export interface QuizQuestion {
  id: string;
  subject: SubjectName;
  topic: string;
  type: QuestionType;
  instructions: string;
  prompt: string;
  imageSrc?: string;
  imageAlt?: string;
  options?: string[];
  correctAnswer: string;
  matchingPairs?: Array<{ left: string; right: string }>;
  sequenceItems?: string[];
  explanation: string;
}

export interface SavedNote {
  id: string;
  title: string;
  subject: SubjectName;
  content: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  detail: string;
  category: 'lesson' | 'assessment' | 'message' | 'update';
  timeLabel: string;
  read: boolean;
}

export interface QuizAttempt {
  id: string;
  subject: SubjectName;
  topic: string;
  score: number;
  total: number;
  percent: number;
  completedAt: string;
}

export interface VideoProgressRecord {
  videoId: string;
  currentSec: number;
  durationSec: number;
  completed: boolean;
}

