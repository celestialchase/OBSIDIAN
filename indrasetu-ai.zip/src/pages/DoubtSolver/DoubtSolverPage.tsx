import React, { useEffect, useState } from 'react';
import {
  BookmarkPlus,
  ImagePlus,
  MessageSquareText,
  Send,
  Sparkles,
  Trash2,
  Volume2,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { AAC_COMMUNICATION_CARDS } from '../../data/curriculum';
import { formatReadableFirestoreError } from '../../lib/firestoreErrors';
import {
  createDoubtMessageDoc,
  markDoubtMessageSavedDoc,
  subscribeDoubtMessages,
} from '../../services/firestoreService';
import { DoubtMessage, ExplanationMode, SubjectName } from '../../types';
import { validateDoubtPrompt } from '../../utils/firestoreValidation';
import { validateDoubtImageFile } from '../../utils/mediaValidation';

const WELCOME_MESSAGE: DoubtMessage = {
  id: 'welcome-msg',
  role: 'assistant',
  content:
    'Welcome to the IndraSetu AI Doubt Solver and Visual Communication Board. You can type a question, attach a temporary textbook image (PNG/JPEG/WEBP/GIF), or tap communication cards below without needing any voice input.',
  keyPoints: [
    'Simple Mode: Short, calm sentences with everyday examples.',
    'Detailed Mode: Complete CBSE-aligned step-by-step explanation.',
    'Visual Mode: Clear spatial stages and diagram cues.',
  ],
  timestamp: 'Ready',
  source: 'offline-guide',
};

export const DoubtSolverPage: React.FC = () => {
  const {
    selectedGrade,
    geminiAvailable,
    addNote,
    firebaseUid,
    authReady,
    getAuthHeaders,
    openAuthModal,
  } = useApp();

  const [mode, setMode] = useState<ExplanationMode>('simple');
  const [subject, setSubject] = useState<SubjectName>('Science');
  const [inputText, setInputText] = useState('');
  const [sentenceTokens, setSentenceTokens] = useState<string[]>([]);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/png');
  const [sessionImagePreviews, setSessionImagePreviews] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiRequiresAuth, setAiRequiresAuth] = useState(false);
  const [lastFailedPayload, setLastFailedPayload] = useState<{
    question: string;
    mode: ExplanationMode;
    subject: SubjectName;
    imagePreview: string | null;
    imageMime: string;
  } | null>(null);

  const [messages, setMessages] = useState<DoubtMessage[]>([WELCOME_MESSAGE]);

  useEffect(() => {
    if (!authReady || !firebaseUid) {
      setHistoryLoading(false);
      setHistoryError(null);
      setSessionImagePreviews({});
      setMessages([WELCOME_MESSAGE]);
      return;
    }
    setHistoryLoading(true);
    setHistoryError(null);
    const unsub = subscribeDoubtMessages(
      firebaseUid,
      (remote) => {
        setHistoryLoading(false);
        setHistoryError(null);
        setMessages([WELCOME_MESSAGE, ...remote]);
      },
      (errMsg) => {
        setHistoryLoading(false);
        setHistoryError(errMsg);
      }
    );
    return () => unsub();
  }, [authReady, firebaseUid]);

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const check = validateDoubtImageFile({
      type: file.type,
      size: file.size,
      name: file.name,
    });
    if (!check.ok) {
      setImagePreview(null);
      setActionError(check.error);
      return;
    }

    setActionError(null);
    setImageMime(check.normalizedMime);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(String(reader.result));
    reader.onerror = () => {
      setImagePreview(null);
      setActionError('Unable to read the selected image file. Please try another PNG, JPEG, WEBP, or GIF image.');
    };
    reader.readAsDataURL(file);
  };

  const handleSpeakText = (text: string) => {
    if (!text.trim() || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-IN';
    window.speechSynthesis.speak(utterance);
  };

  const handleAppendCard = (phrase: string) => {
    setSentenceTokens((prev) => [...prev, phrase]);
    setInputText((prev) => (prev.trim() ? `${prev.trim()} ${phrase}` : phrase));
  };

  const runDoubtRequest = async (payload: {
    question: string;
    mode: ExplanationMode;
    subject: SubjectName;
    imagePreview: string | null;
    imageMime: string;
  }) => {
    setLoading(true);
    setAiError(null);
    setAiRequiresAuth(false);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/ai/doubt', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          question: payload.question,
          mode: payload.mode,
          subject: payload.subject,
          grade: selectedGrade,
          imageBase64: payload.imagePreview || undefined,
          imageMimeType: payload.imageMime,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          setAiRequiresAuth(true);
        }
        throw new Error(data?.error || 'Live AI service unavailable.');
      }

      const assistantMsg: DoubtMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: data.answer,
        mode: payload.mode,
        subject: payload.subject,
        keyPoints: data.keyPoints,
        visualSteps: data.visualSteps,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: 'gemini',
      };
      setLastFailedPayload(null);
      if (firebaseUid) {
        try {
          await createDoubtMessageDoc(firebaseUid, assistantMsg);
        } catch (err) {
          setActionError(formatReadableFirestoreError(err));
          setMessages((prev) => [...prev, assistantMsg]);
        }
      } else {
        setMessages((prev) => [...prev, assistantMsg]);
      }
    } catch (err: unknown) {
      const reason =
        err instanceof Error ? err.message : 'Live Gemini AI could not respond right now.';
      setAiError(reason);
      setLastFailedPayload(payload);
    } finally {
      setLoading(false);
    }
  };

  const handleUseOfflineGuide = async () => {
    if (!lastFailedPayload) return;
    const { question, mode: reqMode, subject: reqSubject } = lastFailedPayload;
    const guideMsg: DoubtMessage = {
      id: `guide-${Date.now()}`,
      role: 'assistant',
      content: `Offline Study Guide for "${question}": Break the topic into input, process, and result, and review the My Learning chapter summary or Visual Learning simulator.`,
      mode: reqMode,
      subject: reqSubject,
      keyPoints: [
        'Read the chapter Key Vocabulary terms first.',
        'Use Visual Learning to adjust inputs and observe cause and effect.',
        'Offline Study Guide shown — not generated by Live Gemini AI.',
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      source: 'offline-guide',
    };
    setAiError(null);
    setAiRequiresAuth(false);
    setLastFailedPayload(null);
    if (firebaseUid) {
      try {
        await createDoubtMessageDoc(firebaseUid, guideMsg);
      } catch (persistErr) {
        setActionError(formatReadableFirestoreError(persistErr));
        setMessages((prev) => [...prev, guideMsg]);
      }
    } else {
      setMessages((prev) => [...prev, guideMsg]);
    }
  };

  const handleAsk = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setActionError(null);
    setAiError(null);
    setAiRequiresAuth(false);
    const check = validateDoubtPrompt(inputText);
    if (!check.valid) {
      setActionError(check.error || 'Please enter a valid question.');
      return;
    }
    const finalQuestion = inputText.trim();
    const attachedImg = imagePreview;
    const attachedMime = imageMime;

    setInputText('');
    setSentenceTokens([]);
    setImagePreview(null);

    const userMsgId = `user-${Date.now()}`;
    if (attachedImg) {
      setSessionImagePreviews((prev) => ({ ...prev, [userMsgId]: attachedImg }));
    }

    const userMsg: DoubtMessage = {
      id: userMsgId,
      role: 'user',
      content: finalQuestion,
      mode,
      subject,
      imagePreview: attachedImg || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    if (firebaseUid) {
      try {
        await createDoubtMessageDoc(firebaseUid, {
          ...userMsg,
          // Never store base64/large media data in Firestore
          imagePreview: undefined,
        });
      } catch (err) {
        setActionError(formatReadableFirestoreError(err));
      }
    } else {
      setMessages((prev) => [...prev, userMsg]);
    }

    await runDoubtRequest({
      question: finalQuestion,
      mode,
      subject,
      imagePreview: attachedImg,
      imageMime: attachedMime,
    });
  };

  const handleSaveMessage = async (msg: DoubtMessage) => {
    setActionError(null);
    try {
      await addNote({
        title: `AI Explanation (${subject})`,
        subject,
        content: msg.content,
      });
      if (firebaseUid) {
        await markDoubtMessageSavedDoc(firebaseUid, msg.id);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === msg.id ? { ...m, saved: true } : m))
      );
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : 'Unable to save explanation to notes.'
      );
    }
  };

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">
            AI Doubt Solver & Non-Speaking Communication Board
          </h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Ask questions using text, temporary diagram images (PNG/JPEG/WEBP/GIF), or visual phrase cards — no voice input required.
          </p>
        </div>

        <div className="text-xs font-semibold text-[#3C8D91] dark:text-teal-400">
          {geminiAvailable ? 'Gemini AI Connected' : 'Demo Study Guide Active (Add GEMINI_API_KEY for Live AI)'}
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Non-Speaking Visual Communication Board (AAC) */}
        <section
          aria-label="Visual Communication Board"
          className="lg:col-span-4 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 space-y-4 self-start"
        >
          <div>
            <h2 className="text-base font-bold text-[#243447] dark:text-slate-100">Visual Communication Cards</h2>
            <p className="mt-0.5 text-xs text-[#526275] dark:text-slate-400">
              Tap cards to build a message for your teacher or AI tutor.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {AAC_COMMUNICATION_CARDS.map((card) => (
              <button
                key={card.id}
                type="button"
                onClick={() => handleAppendCard(card.phrase)}
                className="rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3 text-left hover:border-[#0B63CE] hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors"
              >
                <div className="text-[11px] font-bold text-[#3C8D91] dark:text-teal-400">{card.category}</div>
                <div className="mt-1 text-sm font-bold text-[#243447] dark:text-slate-100">{card.label}</div>
              </button>
            ))}
          </div>

          {sentenceTokens.length > 0 && (
            <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#0B63CE] dark:text-sky-400">Sentence Builder</span>
                <button
                  type="button"
                  onClick={() => {
                    setSentenceTokens([]);
                    setInputText('');
                  }}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#526275] dark:text-slate-300 hover:text-[#C53030]"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clear</span>
                </button>
              </div>
              <p className="text-xs font-medium text-[#243447] dark:text-slate-100">{inputText}</p>
            </div>
          )}

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              disabled={!inputText.trim()}
              onClick={() => handleSpeakText(inputText)}
              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 disabled:opacity-40"
            >
              <Volume2 className="h-4 w-4 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
              <span>Speak Message (Optional)</span>
            </button>
          </div>
        </section>

        {/* Right: AI Doubt Solver Chat */}
        <section className="lg:col-span-8 flex flex-col rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 space-y-4">
          {/* Explanation Mode & Subject Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#EBF0F5] dark:border-slate-800">
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  { id: 'simple', label: 'Simple Explanation' },
                  { id: 'detailed', label: 'Detailed Explanation' },
                  { id: 'visual', label: 'Visual Explanation' },
                ] as const
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMode(m.id)}
                  className={`rounded-xl px-3.5 py-2 text-xs font-bold transition-colors ${
                    mode === m.id
                      ? 'bg-[#0B63CE] text-white'
                      : 'bg-[#EAF3FF] dark:bg-slate-800 text-[#243447] dark:text-slate-200 hover:bg-[#DCEBFA] dark:hover:bg-slate-700'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <select
              aria-label="Doubt subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value as SubjectName)}
              className="rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#243447] dark:text-slate-100"
            >
              <option value="Science">Science</option>
              <option value="Mathematics">Mathematics</option>
              <option value="English">English</option>
              <option value="Social Science">Social Science</option>
              <option value="Hindi">Hindi</option>
              <option value="Computer">Computer</option>
            </select>
          </div>

          {/* Conversation History */}
          <div className="flex-1 space-y-4 max-h-[460px] overflow-y-auto pr-1">
            {historyLoading && (
              <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
                Loading your saved AI Doubt Solver history...
              </div>
            )}

            {(historyError || actionError || aiError) && (
              <div
                role="alert"
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
              >
                <span>{aiError || actionError || historyError}</span>
                {aiError && (
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {aiRequiresAuth && (
                      <button
                        type="button"
                        onClick={() => openAuthModal('login')}
                        className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
                      >
                        Sign In
                      </button>
                    )}
                    {lastFailedPayload && (
                      <>
                        <button
                          type="button"
                          disabled={loading}
                          onClick={() => void runDoubtRequest(lastFailedPayload)}
                          className="rounded-lg border border-[#F5C2C7] dark:border-red-700 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#9B1C1C] dark:text-red-200 hover:bg-[#FDE8E8]"
                        >
                          Retry
                        </button>
                        <button
                          type="button"
                          disabled={loading}
                          onClick={() => void handleUseOfflineGuide()}
                          className="rounded-lg border border-[#CFE0F5] dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF]"
                        >
                          Use Offline Study Guide
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}

            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`rounded-2xl p-4 ${
                  msg.role === 'user'
                    ? 'ml-auto max-w-[85%] bg-[#EAF3FF] dark:bg-sky-950/60 border border-[#CFE0F5] dark:border-sky-800'
                    : 'mr-auto max-w-[95%] bg-[#FAF9F6] dark:bg-slate-800 border border-[#E3EAF2] dark:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs font-bold text-[#526275] dark:text-slate-400">
                  <span className="flex flex-wrap items-center gap-1.5 text-[#243447] dark:text-slate-100">
                    {msg.role === 'assistant' ? (
                      <Sparkles className="h-3.5 w-3.5 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
                    ) : (
                      <MessageSquareText className="h-3.5 w-3.5 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                    )}
                    <span>{msg.role === 'assistant' ? 'IndraSetu Tutor' : 'You'}</span>
                    {msg.mode && <span className="text-[#3C8D91] dark:text-teal-400">· {msg.mode}</span>}
                    {msg.role === 'assistant' && msg.source && (
                      <span
                        className={
                          msg.source === 'gemini'
                            ? 'text-[#0B63CE] dark:text-sky-400'
                            : 'text-[#526275] dark:text-slate-400'
                        }
                      >
                        ({msg.source === 'gemini' ? 'Live Gemini AI' : 'Offline Study Guide'})
                      </span>
                    )}
                  </span>
                  <span>{msg.timestamp}</span>
                </div>

                {(msg.imagePreview || sessionImagePreviews[msg.id]) && (
                  <img
                    src={msg.imagePreview || sessionImagePreviews[msg.id]}
                    alt="Temporary question attachment"
                    data-essential="true"
                    className="mt-2 max-h-40 rounded-xl border border-[#D4DFEC] dark:border-slate-700"
                  />
                )}

                <p className="mt-2 text-sm leading-relaxed text-[#243447] dark:text-slate-100 whitespace-pre-line">
                  {msg.content}
                </p>

                {msg.keyPoints && msg.keyPoints.length > 0 && (
                  <ul className="mt-3 list-disc pl-5 space-y-1 text-xs text-[#354B63] dark:text-slate-300">
                    {msg.keyPoints.map((pt, idx) => (
                      <li key={idx}>{pt}</li>
                    ))}
                  </ul>
                )}

                {msg.visualSteps && msg.visualSteps.length > 0 && (
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
                    {msg.visualSteps.map((step, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-xs text-[#243447] dark:text-slate-100"
                      >
                        <div className="font-bold text-[#0B63CE] dark:text-sky-400">Step {idx + 1}</div>
                        <div className="mt-0.5">{step}</div>
                      </div>
                    ))}
                  </div>
                )}

                {msg.role === 'assistant' && msg.id !== 'welcome-msg' && (
                  <div className="mt-3 flex flex-wrap items-center gap-2 pt-2 border-t border-[#EBF0F5] dark:border-slate-700">
                    <button
                      type="button"
                      onClick={() => handleSaveMessage(msg)}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700"
                    >
                      <BookmarkPlus className="h-3.5 w-3.5 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                      <span>{msg.saved ? 'Saved to Notes' : 'Save Answer'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSpeakText(msg.content)}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700"
                    >
                      <Volume2 className="h-3.5 w-3.5 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
                      <span>Read Aloud</span>
                    </button>
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="rounded-2xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-4 text-sm font-semibold text-[#3C8D91] dark:text-teal-400">
                Thinking through a clear {mode} explanation...
              </div>
            )}
          </div>

          {/* Input Bar */}
          <form onSubmit={handleAsk} className="space-y-2.5 pt-2 border-t border-[#EBF0F5] dark:border-slate-800">
            {imagePreview && (
              <div className="flex items-center gap-3 rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-2">
                <img
                  src={imagePreview}
                  alt="Selected attachment preview"
                  data-essential="true"
                  className="h-12 w-12 rounded-lg object-cover"
                />
                <span className="text-xs font-semibold text-[#243447] dark:text-slate-100 flex-1">
                  Image attached for temporary AI analysis (not stored permanently)
                </span>
                <button
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="text-xs font-bold text-[#C53030] dark:text-red-400 hover:underline"
                >
                  Remove
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700">
                <ImagePlus className="h-5 w-5 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                <span className="sr-only">Attach temporary PNG, JPEG, WEBP, or GIF image</span>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={handleImagePick}
                  className="sr-only"
                />
              </label>

              <input
                type="text"
                aria-label="Type your study question"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ask a question (e.g., How do stomata help plants breathe?)"
                className="flex-1 min-w-[200px] rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-4 py-3 text-sm text-[#243447] dark:text-slate-100"
              />

              <button
                type="submit"
                disabled={loading || !inputText.trim()}
                className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-5 py-3 text-sm font-bold text-white hover:bg-[#094FA6] disabled:opacity-50"
              >
                <Send className="h-4 w-4" aria-hidden="true" />
                <span>Ask AI</span>
              </button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
};
