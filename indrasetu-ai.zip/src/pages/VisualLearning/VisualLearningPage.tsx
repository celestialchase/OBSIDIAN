import React, { useState } from 'react';
import { Calculator, Eye, FlaskConical, Sparkles, Sun } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { ASSET_PATHS } from '../../data/curriculum';

interface VisualConceptResponse {
  title: string;
  summary: string;
  stages: Array<{
    step: number;
    title: string;
    description: string;
    visualCue: string;
    formulaOrFact: string;
  }>;
  keyTerms: Array<{ term: string; definition: string }>;
  source: 'gemini' | 'offline';
  fallbackNote?: string;
}

export const VisualLearningPage: React.FC = () => {
  const { selectedGrade, getAuthHeaders, openAuthModal } = useApp();
  const [activeLab, setActiveLab] = useState<'photosynthesis' | 'ratios' | 'ai-explainer'>(
    'photosynthesis'
  );

  // Interactive Photosynthesis Simulation State
  const [sunlight, setSunlight] = useState(75);
  const [water, setWater] = useState(70);
  const [co2, setCo2] = useState(65);

  const glucoseRate = Math.round(Math.min(sunlight, water, co2) * 0.95);
  const oxygenRate = Math.round(glucoseRate * 1.05);
  const limitingFactor =
    sunlight <= water && sunlight <= co2
      ? 'Sunlight'
      : water <= sunlight && water <= co2
      ? 'Water (H2O)'
      : 'Carbon Dioxide (CO2)';

  // Interactive Ratio Visualizer State
  const [blueParts, setBlueParts] = useState(2);
  const [greenParts, setGreenParts] = useState(4);
  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const divisor = gcd(blueParts, greenParts);
  const simpleBlue = blueParts / divisor;
  const simpleGreen = greenParts / divisor;

  // AI Visual Concept Generator
  const [topicInput, setTopicInput] = useState('Water Cycle and Evaporation');
  const [topicSubject, setTopicSubject] = useState('Science');
  const [generating, setGenerating] = useState(false);
  const [visualError, setVisualError] = useState<string | null>(null);
  const [visualRequiresAuth, setVisualRequiresAuth] = useState(false);
  const [aiConcept, setAiConcept] = useState<VisualConceptResponse | null>(null);

  const runVisualConcept = async () => {
    const trimmedTopic = topicInput.trim();
    if (!trimmedTopic) {
      setVisualError('Please enter a topic to visualize.');
      setVisualRequiresAuth(false);
      return;
    }
    setGenerating(true);
    setVisualError(null);
    setVisualRequiresAuth(false);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/ai/visual-concept', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          topic: trimmedTopic,
          subject: topicSubject,
          grade: selectedGrade,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          setVisualRequiresAuth(true);
        }
        throw new Error(data?.error || 'Live AI visual generation unavailable.');
      }
      setAiConcept({
        ...data,
        source: 'gemini',
      });
    } catch (err: unknown) {
      setVisualError(
        err instanceof Error
          ? err.message
          : 'Live Gemini AI could not build the visual stages. Please try again.'
      );
    } finally {
      setGenerating(false);
    }
  };

  const handleGenerateVisual = async (e: React.FormEvent) => {
    e.preventDefault();
    await runVisualConcept();
  };

  const handleUseOfflineScaffold = () => {
    const trimmedTopic = topicInput.trim() || 'Core Concept';
    setVisualError(null);
    setVisualRequiresAuth(false);
    setAiConcept({
      title: trimmedTopic,
      summary: `Step-by-step visual overview for ${trimmedTopic} (${selectedGrade} ${topicSubject}).`,
      stages: [
        {
          step: 1,
          title: 'Identify Core Inputs',
          description: 'Observe what starts the process or forms the base parts of the problem.',
          visualCue: 'Draw two clear boxes showing initial inputs and arrows moving inward.',
          formulaOrFact: 'Start with observable quantities first.',
        },
        {
          step: 2,
          title: 'Trace the Transformation',
          description: 'Follow how energy or operations change the inputs step by step.',
          visualCue: 'Highlight the middle stage in teal to separate cause from effect.',
          formulaOrFact: 'Every change follows a predictable rule.',
        },
        {
          step: 3,
          title: 'Check the Final Outcome',
          description: 'Verify the resulting output or solution and connect it to an everyday example.',
          visualCue: 'Compare final result box side-by-side with Step 1.',
          formulaOrFact: 'Verify units and direction.',
        },
      ],
      keyTerms: [
        {
          term: 'Visual Cue',
          definition: 'A color-coded arrow, box, or diagram step that anchors memory without dense text.',
        },
      ],
      source: 'offline',
      fallbackNote: 'Offline Visual Scaffold (not generated by Live Gemini AI).',
    });
  };

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">AI Visual Learning Studio</h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Interactive science simulations, visual math bars, and step-by-step concept breakdowns.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setActiveLab('photosynthesis')}
            className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
              activeLab === 'photosynthesis'
                ? 'bg-[#0B63CE] text-white'
                : 'border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800'
            }`}
          >
            <FlaskConical className="h-4 w-4" aria-hidden="true" />
            <span>Photosynthesis Simulator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLab('ratios')}
            className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
              activeLab === 'ratios'
                ? 'bg-[#0B63CE] text-white'
                : 'border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800'
            }`}
          >
            <Calculator className="h-4 w-4" aria-hidden="true" />
            <span>Ratio & Proportion Explorer</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLab('ai-explainer')}
            className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
              activeLab === 'ai-explainer'
                ? 'bg-[#0B63CE] text-white'
                : 'border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800'
            }`}
          >
            <Sparkles className="h-4 w-4" aria-hidden="true" />
            <span>AI Concept Visualizer</span>
          </button>
        </div>
      </section>

      {/* Lab 1: Interactive Photosynthesis Simulator */}
      {activeLab === 'photosynthesis' && (
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">
                Interactive Leaf Energy & Gas Exchange
              </h2>
              <span className="text-xs font-bold text-[#3C8D91] dark:text-teal-400 font-tabular">
                Glucose Output: {glucoseRate}%
              </span>
            </div>

            <div className="overflow-hidden rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800">
              <div data-image-container="true" className="relative overflow-hidden">
                <img
                  src={ASSET_PATHS.photosynthesis}
                  alt="Interactive photosynthesis diagram"
                  referrerPolicy="no-referrer"
                  className="w-full h-64 sm:h-72 object-cover"
                />
              </div>
              {/* Live visual state indicators paired with text labels */}
              <div className="grid grid-cols-3 gap-2 border-t border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-center text-xs">
                <div className="rounded-lg bg-[#FEF9DC] dark:bg-amber-950/60 p-2">
                  <div className="font-bold text-[#243447] dark:text-amber-100">Sunlight Input</div>
                  <div className="mt-0.5 font-tabular font-extrabold text-[#B45309] dark:text-amber-300">
                    {sunlight}%
                  </div>
                </div>
                <div className="rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 p-2">
                  <div className="font-bold text-[#243447] dark:text-sky-100">Xylem Water</div>
                  <div className="mt-0.5 font-tabular font-extrabold text-[#0B63CE] dark:text-sky-300">
                    {water}%
                  </div>
                </div>
                <div className="rounded-lg bg-[#E6F5EE] dark:bg-emerald-950/60 p-2">
                  <div className="font-bold text-[#243447] dark:text-emerald-100">Oxygen Output</div>
                  <div className="mt-0.5 font-tabular font-extrabold text-[#15803D] dark:text-emerald-300">
                    {oxygenRate}%
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-3.5 text-sm text-[#243447] dark:text-slate-100">
              <strong>Current Observation:</strong>{' '}
              {glucoseRate >= 65
                ? 'High photosynthesis rate! Balanced sunlight, water, and CO2 produce steady glucose and oxygen.'
                : `Output is currently limited by ${limitingFactor}. Increase ${limitingFactor} using the slider to raise oxygen output.`}
            </div>
          </div>

          <div className="lg:col-span-5 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-5">
            <h3 className="text-base font-bold text-[#243447] dark:text-slate-100">Adjust Environmental Inputs</h3>

            <div>
              <div className="flex justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                <label htmlFor="sim-sun">Sunlight Intensity</label>
                <span className="font-tabular font-bold text-[#B45309] dark:text-amber-400">{sunlight}%</span>
              </div>
              <input
                id="sim-sun"
                type="range"
                min={10}
                max={100}
                value={sunlight}
                onChange={(e) => setSunlight(Number(e.target.value))}
                className="mt-2 w-full accent-[#D97706]"
              />
            </div>

            <div>
              <div className="flex justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                <label htmlFor="sim-water">Soil Water (H2O)</label>
                <span className="font-tabular font-bold text-[#0B63CE] dark:text-sky-400">{water}%</span>
              </div>
              <input
                id="sim-water"
                type="range"
                min={10}
                max={100}
                value={water}
                onChange={(e) => setWater(Number(e.target.value))}
                className="mt-2 w-full accent-[#0B63CE]"
              />
            </div>

            <div>
              <div className="flex justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                <label htmlFor="sim-co2">Carbon Dioxide (CO2)</label>
                <span className="font-tabular font-bold text-[#3C8D91] dark:text-teal-400">{co2}%</span>
              </div>
              <input
                id="sim-co2"
                type="range"
                min={10}
                max={100}
                value={co2}
                onChange={(e) => setCo2(Number(e.target.value))}
                className="mt-2 w-full accent-[#3C8D91]"
              />
            </div>

            <div className="rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-4 space-y-1.5 text-xs text-[#354B63] dark:text-slate-300">
              <div className="flex items-center gap-1.5 font-bold text-[#243447] dark:text-slate-100">
                <Sun className="h-4 w-4 text-[#D97706] dark:text-amber-400" aria-hidden="true" />
                <span>Balanced Chemical Word Equation</span>
              </div>
              <p className="font-tabular font-semibold text-[#243447] dark:text-slate-200">
                Water + Carbon Dioxide + Sunlight → Glucose + Oxygen
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Lab 2: Ratio & Proportion Explorer */}
      {activeLab === 'ratios' && (
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-5">
            <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Visual Ratio Bar Comparison</h2>

            <div className="space-y-4">
              <div>
                <div className="text-xs font-bold text-[#0B63CE] dark:text-sky-400 mb-1.5">
                  Blue Blocks ({blueParts})
                </div>
                <div className="flex flex-wrap gap-2">
                  {Array.from({ length: blueParts }).map((_, i) => (
                    <div
                      key={i}
                      className="h-11 w-11 rounded-xl bg-[#0B63CE] text-white flex items-center justify-center text-sm font-bold font-tabular"
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-[#3C8D91] dark:text-teal-400 mb-1.5">
                  Green Blocks ({greenParts})
                </div>
                <div className="flex flex-wrap gap-2">
                  {Array.from({ length: greenParts }).map((_, i) => (
                    <div
                      key={i}
                      className="h-11 w-11 rounded-xl bg-[#3C8D91] text-white flex items-center justify-center text-sm font-bold font-tabular"
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-semibold text-[#4A5E75] dark:text-slate-300">Current Ratio</div>
                <div className="text-2xl font-extrabold text-[#243447] dark:text-slate-100 font-tabular">
                  {blueParts} : {greenParts}
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-[#4A5E75] dark:text-slate-300">Simplest Equivalent Form</div>
                <div className="text-2xl font-extrabold text-[#0B63CE] dark:text-sky-400 font-tabular">
                  {simpleBlue} : {simpleGreen}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-5">
            <h3 className="text-base font-bold text-[#243447] dark:text-slate-100">Change Block Counts</h3>
            <div>
              <div className="flex justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                <label htmlFor="ratio-blue">Blue Quantity</label>
                <span className="font-tabular font-bold">{blueParts}</span>
              </div>
              <input
                id="ratio-blue"
                type="range"
                min={1}
                max={12}
                value={blueParts}
                onChange={(e) => setBlueParts(Number(e.target.value))}
                className="mt-2 w-full accent-[#0B63CE]"
              />
            </div>

            <div>
              <div className="flex justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                <label htmlFor="ratio-green">Green Quantity</label>
                <span className="font-tabular font-bold">{greenParts}</span>
              </div>
              <input
                id="ratio-green"
                type="range"
                min={1}
                max={12}
                value={greenParts}
                onChange={(e) => setGreenParts(Number(e.target.value))}
                className="mt-2 w-full accent-[#3C8D91]"
              />
            </div>

            <p className="text-xs leading-relaxed text-[#4A5E75] dark:text-slate-300">
              Both numbers share a highest common factor of <strong className="font-tabular">{divisor}</strong>. Dividing both sides by {divisor} keeps the visual proportion identical.
            </p>
          </div>
        </section>
      )}

      {/* Lab 3: Gemini AI Concept Visualizer */}
      {activeLab === 'ai-explainer' && (
        <section className="space-y-6">
          <form
            onSubmit={handleGenerateVisual}
            className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 flex flex-wrap items-end gap-3"
          >
            <div className="flex-1 min-w-[220px]">
              <label htmlFor="visual-topic" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                Topic to Visualize
              </label>
              <input
                id="visual-topic"
                type="text"
                value={topicInput}
                onChange={(e) => setTopicInput(e.target.value)}
                placeholder="e.g., Water Cycle, Human Digestive System, Pythagoras Theorem"
                className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
              />
            </div>
            <div className="w-44">
              <label htmlFor="visual-subject" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                Subject
              </label>
              <select
                id="visual-subject"
                value={topicSubject}
                onChange={(e) => setTopicSubject(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2.5 text-sm text-[#243447] dark:text-slate-100"
              >
                <option value="Science">Science</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Social Science">Social Science</option>
                <option value="Computer">Computer</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={generating}
              className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6] disabled:opacity-60"
            >
              <Eye className="h-4 w-4" aria-hidden="true" />
              <span>{generating ? 'Building Visual Stages...' : 'Generate Visual Steps'}</span>
            </button>
          </form>

          {visualError && (
            <div
              role="alert"
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
            >
              <span>{visualError}</span>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {visualRequiresAuth && (
                  <button
                    type="button"
                    onClick={() => openAuthModal('login')}
                    className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
                  >
                    Sign In
                  </button>
                )}
                <button
                  type="button"
                  disabled={generating}
                  onClick={() => void runVisualConcept()}
                  className="rounded-lg border border-[#F5C2C7] dark:border-red-700 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#9B1C1C] dark:text-red-200 hover:bg-[#FDE8E8]"
                >
                  Retry
                </button>
                <button
                  type="button"
                  disabled={generating}
                  onClick={handleUseOfflineScaffold}
                  className="rounded-lg border border-[#CFE0F5] dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF]"
                >
                  View Offline Visual Scaffold
                </button>
              </div>
            </div>
          )}

          {aiConcept && (
            <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-6 space-y-5">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h2 className="text-xl font-extrabold text-[#243447] dark:text-slate-100">{aiConcept.title}</h2>
                  <span className="text-xs font-bold text-[#0B63CE] dark:text-sky-400">
                    {aiConcept.source === 'gemini' ? 'Live Gemini AI' : 'Offline Visual Scaffold'}
                  </span>
                </div>
                <p className="mt-1 text-sm text-[#4A5E75] dark:text-slate-300">{aiConcept.summary}</p>
                {aiConcept.fallbackNote && (
                  <p className="mt-2 text-xs font-medium text-[#3C8D91] dark:text-teal-400">{aiConcept.fallbackNote}</p>
                )}
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                {aiConcept.stages.map((st) => (
                  <div
                    key={st.step}
                    className="rounded-2xl border border-[#CFE0F5] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-4 space-y-2"
                  >
                    <div className="text-xs font-bold text-[#0B63CE] dark:text-sky-400">Stage {st.step}</div>
                    <h3 className="text-base font-bold text-[#243447] dark:text-slate-100">{st.title}</h3>
                    <p className="text-xs leading-relaxed text-[#354B63] dark:text-slate-300">{st.description}</p>
                    <div className="rounded-xl bg-[#EAF3FF] dark:bg-slate-700 p-2.5 text-xs text-[#243447] dark:text-slate-100">
                      <strong>Visual Cue:</strong> {st.visualCue}
                    </div>
                    <div className="text-[11px] font-bold text-[#3C8D91] dark:text-teal-400">
                      Key Fact: {st.formulaOrFact}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
};
