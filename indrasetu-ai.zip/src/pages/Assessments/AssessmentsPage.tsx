import React, { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { QuizQuestion, SubjectName } from '../../types';
import { evaluateQuizAnswer } from '../../utils/assessmentLogic';

export const AssessmentsPage: React.FC = () => {
  const {
    quizQuestions,
    setQuizQuestions,
    recordQuizAttempt,
    selectedGrade,
    navigate,
    getAuthHeaders,
    openAuthModal,
  } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [mcqChoice, setMcqChoice] = useState('');
  const [blankInput, setBlankInput] = useState('');
  const [matchMap, setMatchMap] = useState<Record<string, string>>({});
  const [sequenceOrder, setSequenceOrder] = useState<string[]>([]);
  const [submittedCurrent, setSubmittedCurrent] = useState<boolean>(false);
  const [isCurrentCorrect, setIsCurrentCorrect] = useState<boolean>(false);
  const [scoreCount, setScoreCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [savingAttempt, setSavingAttempt] = useState(false);
  const [attemptSaveError, setAttemptSaveError] = useState<string | null>(null);

  const [genSubject, setGenSubject] = useState<SubjectName>('Science');
  const [genTopic, setGenTopic] = useState('Solar System');
  const [generating, setGenerating] = useState(false);
  const [genNotice, setGenNotice] = useState<string | null>(null);
  const [genError, setGenError] = useState<string | null>(null);
  const [genRequiresAuth, setGenRequiresAuth] = useState(false);
  const [quizSource, setQuizSource] = useState<'built-in' | 'gemini'>('built-in');

  const question = quizQuestions[currentIndex] || quizQuestions[0];

  useEffect(() => {
    if (!question) return;
    setMcqChoice('');
    setBlankInput('');
    setMatchMap({});
    setSubmittedCurrent(false);
    if (question.type === 'sequence' && question.sequenceItems) {
      // Present an intentionally shifted initial order for interactive sorting
      const items = [...question.sequenceItems];
      if (items.length >= 2) {
        const first = items.shift()!;
        items.push(first);
      }
      setSequenceOrder(items);
    } else {
      setSequenceOrder([]);
    }
  }, [currentIndex, question]);

  const moveSequenceItem = (idx: number, direction: -1 | 1) => {
    if (submittedCurrent) return;
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= sequenceOrder.length) return;
    const copy = [...sequenceOrder];
    const [removed] = copy.splice(idx, 1);
    copy.splice(targetIdx, 0, removed);
    setSequenceOrder(copy);
  };

  const handleCheckAnswer = () => {
    if (!question || submittedCurrent) return;
    let userResponse: string | Record<string, string> | string[] = '';
    if (question.type === 'mcq') userResponse = mcqChoice;
    else if (question.type === 'fill-blank') userResponse = blankInput;
    else if (question.type === 'matching') userResponse = matchMap;
    else if (question.type === 'sequence') userResponse = sequenceOrder;

    const result = evaluateQuizAnswer(question, userResponse);
    setIsCurrentCorrect(result.isCorrect);
    setSubmittedCurrent(true);
    if (result.isCorrect) {
      setScoreCount((prev) => prev + 1);
    }
  };

  const handleNext = async () => {
    if (currentIndex + 1 >= quizQuestions.length) {
      const percent = Math.round((scoreCount / Math.max(1, quizQuestions.length)) * 100);
      setFinished(true);
      setSavingAttempt(true);
      setAttemptSaveError(null);
      try {
        await recordQuizAttempt({
          subject: question.subject,
          topic: question.topic,
          score: scoreCount,
          total: quizQuestions.length,
          percent,
        });
      } catch (err) {
        setAttemptSaveError(
          err instanceof Error ? err.message : 'Could not save assessment result.'
        );
      } finally {
        setSavingAttempt(false);
      }
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setScoreCount(0);
    setFinished(false);
    setSubmittedCurrent(false);
    setAttemptSaveError(null);
  };

  const runGenerateAIQuiz = async () => {
    const trimmedTopic = genTopic.trim();
    if (!trimmedTopic) {
      setGenError('Please enter a quiz topic before generating.');
      setGenRequiresAuth(false);
      return;
    }
    setGenerating(true);
    setGenNotice(null);
    setGenError(null);
    setGenRequiresAuth(false);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/ai/generate-quiz', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          subject: genSubject,
          topic: trimmedTopic,
          grade: selectedGrade,
          count: 3,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          setGenRequiresAuth(true);
        }
        throw new Error(data?.error || 'Live quiz generation unavailable.');
      }
      if (!Array.isArray(data.questions) || data.questions.length === 0) {
        throw new Error('Live AI returned no quiz questions. Please try another topic.');
      }
      const formatted: QuizQuestion[] = data.questions.map(
        (q: {
          id?: string;
          type?: string;
          prompt: string;
          options?: string[];
          correctAnswer: string;
          explanation: string;
        }, i: number) => ({
          id: q.id || `ai-q-${Date.now()}-${i}`,
          subject: genSubject,
          topic: trimmedTopic,
          type: q.type === 'fill-blank' ? 'fill-blank' : 'mcq',
          instructions:
            q.type === 'fill-blank'
              ? 'Type the missing term in the box below.'
              : 'Select the best answer.',
          prompt: q.prompt,
          options: q.options && q.options.length > 0 ? q.options : [q.correctAnswer, 'Option B', 'Option C'],
          correctAnswer: q.correctAnswer,
          explanation: q.explanation,
        })
      );
      setQuizQuestions(formatted);
      setQuizSource('gemini');
      setCurrentIndex(0);
      setScoreCount(0);
      setFinished(false);
      setGenNotice(
        `Generated ${formatted.length} accessible questions on "${trimmedTopic}" (Live Gemini AI).`
      );
    } catch (err: unknown) {
      setGenError(
        err instanceof Error
          ? err.message
          : 'Live Gemini AI quiz generation failed. Please try again.'
      );
    } finally {
      setGenerating(false);
    }
  };

  const handleGenerateAIQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    await runGenerateAIQuiz();
  };

  const canCheck =
    (question.type === 'mcq' && Boolean(mcqChoice)) ||
    (question.type === 'fill-blank' && Boolean(blankInput.trim())) ||
    (question.type === 'matching' &&
      Boolean(question.matchingPairs?.every((p) => Boolean(matchMap[p.left])))) ||
    question.type === 'sequence';

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">
            Interactive Accessible Assessments
          </h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Image MCQs, fill-in-the-blanks, matching exercises, and step ordering — 100% visual and keyboard friendly.
          </p>
        </div>

        <form onSubmit={handleGenerateAIQuiz} className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Quiz subject"
            value={genSubject}
            onChange={(e) => setGenSubject(e.target.value as SubjectName)}
            className="rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#243447] dark:text-slate-100"
          >
            <option value="Science">Science</option>
            <option value="Mathematics">Mathematics</option>
            <option value="English">English</option>
            <option value="Social Science">Social Science</option>
          </select>
          <input
            type="text"
            aria-label="Quiz topic"
            value={genTopic}
            onChange={(e) => setGenTopic(e.target.value)}
            placeholder="Topic..."
            className="w-40 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-[#243447] dark:text-slate-100"
          />
          <button
            type="submit"
            disabled={generating}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#3C8D91] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#2F7377] disabled:opacity-60"
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{generating ? 'Generating...' : 'AI Quiz'}</span>
          </button>
        </form>
      </section>

      {genError && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
        >
          <span>{genError}</span>
          <div className="flex items-center gap-2 shrink-0">
            {genRequiresAuth && (
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
              >
                Sign In
              </button>
            )}
            <button
              type="button"
              disabled={generating}
              onClick={() => void runGenerateAIQuiz()}
              className="rounded-lg border border-[#F5C2C7] dark:border-red-700 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#9B1C1C] dark:text-red-200 hover:bg-[#FDE8E8]"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {genNotice && (
        <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#243447] dark:text-slate-100">
          {genNotice}
        </div>
      )}

      {finished ? (
        <section className="mx-auto max-w-2xl rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-8 text-center space-y-4">
          <CheckCircle2 className="mx-auto h-12 w-12 text-[#16A34A]" aria-hidden="true" />
          <h2 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">Assessment Complete!</h2>
          <p className="text-base text-[#4A5E75] dark:text-slate-300">
            You scored{' '}
            <strong className="text-[#0B63CE] dark:text-sky-400 font-tabular">
              {scoreCount} / {quizQuestions.length}
            </strong>{' '}
            (
            <strong className="font-tabular">
              {Math.round((scoreCount / Math.max(1, quizQuestions.length)) * 100)}%
            </strong>
            ).{' '}
            {savingAttempt
              ? 'Saving your progress...'
              : attemptSaveError
              ? 'Could not save to cloud.'
              : 'Your progress has been saved.'}
          </p>
          {attemptSaveError && (
            <div
              role="alert"
              className="mx-auto max-w-md rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
            >
              {attemptSaveError}
            </div>
          )}
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleRestart}
              className="inline-flex items-center gap-2 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-5 py-2.5 text-sm font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>Practice Again</span>
            </button>
            <button
              type="button"
              onClick={() => navigate('progress')}
              className="rounded-xl bg-[#0B63CE] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6]"
            >
              View My Progress
            </button>
          </div>
        </section>
      ) : (
        <section className="mx-auto max-w-3xl rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-5">
          {/* Progress header */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#EBF0F5] dark:border-slate-800">
            <div className="text-xs font-bold text-[#3C8D91] dark:text-teal-400">
              {question.subject} · {question.topic} ·{' '}
              <span className="text-[#0B63CE] dark:text-sky-400">
                {quizSource === 'gemini' ? 'Live Gemini AI' : 'Built-in CBSE Assessment'}
              </span>
            </div>
            <div className="text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular">
              Question {currentIndex + 1} of {quizQuestions.length} · Score: {scoreCount}
            </div>
          </div>

          <div className="rounded-xl bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
            Instructions: {question.instructions}
          </div>

          <h2 className="text-xl font-bold text-[#243447] dark:text-slate-100">{question.prompt}</h2>

          {question.imageSrc && (
            <div
              data-image-container="true"
              className="overflow-hidden rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800"
            >
              <img
                src={question.imageSrc}
                alt={question.imageAlt || question.prompt}
                referrerPolicy="no-referrer"
                className="w-full max-h-[240px] object-cover"
              />
            </div>
          )}

          {/* Question Type 1: Image/Text MCQ */}
          {question.type === 'mcq' && question.options && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {question.options.map((opt) => {
                const selected = mcqChoice === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={submittedCurrent}
                    onClick={() => setMcqChoice(opt)}
                    className={`rounded-xl border-2 px-4 py-3.5 text-left text-sm font-bold transition-colors ${
                      selected
                        ? 'border-[#0B63CE] bg-[#EAF3FF] dark:bg-sky-950 text-[#0B63CE] dark:text-sky-300'
                        : 'border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 text-[#243447] dark:text-slate-100 hover:border-[#3C8D91]'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          )}

          {/* Question Type 2: Fill in the Blank (with optional quick word bank) */}
          {question.type === 'fill-blank' && (
            <div className="space-y-3">
              <label htmlFor="fill-blank-input" className="block text-xs font-bold text-[#526275] dark:text-slate-400">
                Your Answer
              </label>
              <input
                id="fill-blank-input"
                type="text"
                disabled={submittedCurrent}
                value={blankInput}
                onChange={(e) => setBlankInput(e.target.value)}
                placeholder="Type your answer here..."
                className="w-full rounded-xl border-2 border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-4 py-3 text-base font-bold text-[#243447] dark:text-slate-100"
              />
              {question.options && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-[#526275] dark:text-slate-400">Word Bank:</span>
                  {question.options.map((word) => (
                    <button
                      key={word}
                      type="button"
                      disabled={submittedCurrent}
                      onClick={() => setBlankInput(word)}
                      className="rounded-lg border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-3 py-1 text-xs font-bold text-[#0B63CE] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700"
                    >
                      {word}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Question Type 3: Accessible Matching Pairs */}
          {question.type === 'matching' && question.matchingPairs && (
            <div className="space-y-3">
              {question.matchingPairs.map((pair) => {
                const rightOptions = question.matchingPairs!.map((p) => p.right);
                return (
                  <div
                    key={pair.left}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
                  >
                    <span className="text-sm font-bold text-[#243447] dark:text-slate-100">{pair.left}</span>
                    <select
                      aria-label={`Match for ${pair.left}`}
                      disabled={submittedCurrent}
                      value={matchMap[pair.left] || ''}
                      onChange={(e) =>
                        setMatchMap((prev) => ({ ...prev, [pair.left]: e.target.value }))
                      }
                      className="min-w-[230px] rounded-xl border border-[#D4DFEC] dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 text-sm font-semibold text-[#243447] dark:text-slate-100"
                    >
                      <option value="">Select matching function...</option>
                      {rightOptions.map((ro) => (
                        <option key={ro} value={ro}>
                          {ro}
                        </option>
                      ))}
                    </select>
                  </div>
                );
              })}
            </div>
          )}

          {/* Question Type 4: Accessible Sequence Ordering */}
          {question.type === 'sequence' && (
            <div className="space-y-2.5">
              {sequenceOrder.map((step, idx) => (
                <div
                  key={step}
                  className="flex items-center justify-between gap-3 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[#0B63CE] text-xs font-bold text-white font-tabular">
                      {idx + 1}
                    </span>
                    <span className="text-sm font-semibold text-[#243447] dark:text-slate-100">{step}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      disabled={submittedCurrent || idx === 0}
                      onClick={() => moveSequenceItem(idx, -1)}
                      aria-label={`Move "${step}" up`}
                      className="rounded-lg border border-[#DCE5EF] dark:border-slate-600 bg-white dark:bg-slate-900 p-1.5 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 disabled:opacity-40"
                    >
                      <ArrowUp className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      disabled={submittedCurrent || idx === sequenceOrder.length - 1}
                      onClick={() => moveSequenceItem(idx, 1)}
                      aria-label={`Move "${step}" down`}
                      className="rounded-lg border border-[#DCE5EF] dark:border-slate-600 bg-white dark:bg-slate-900 p-1.5 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 disabled:opacity-40"
                    >
                      <ArrowDown className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Instant Feedback */}
          {submittedCurrent && (
            <div
              className={`rounded-xl border p-4 ${
                isCurrentCorrect
                  ? 'border-[#B6E0DA] dark:border-emerald-700 bg-[#E6F5EE] dark:bg-emerald-950/60 text-[#1D3538] dark:text-emerald-200'
                  : 'border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 text-[#7F1D1D] dark:text-red-200'
              }`}
            >
              <div className="flex items-center gap-2 text-sm font-extrabold">
                {isCurrentCorrect ? (
                  <CheckCircle2 className="h-5 w-5 text-[#16A34A]" aria-hidden="true" />
                ) : (
                  <XCircle className="h-5 w-5 text-[#DC2626]" aria-hidden="true" />
                )}
                <span>{isCurrentCorrect ? 'Correct Answer!' : 'Review This Step'}</span>
              </div>
              <p className="mt-1.5 text-sm leading-relaxed">{question.explanation}</p>
              {!isCurrentCorrect && (
                <p className="mt-1 text-xs font-bold">Expected: {question.correctAnswer}</p>
              )}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2 border-t border-[#EBF0F5] dark:border-slate-800">
            {!submittedCurrent ? (
              <button
                type="button"
                disabled={!canCheck}
                onClick={handleCheckAnswer}
                className="rounded-xl bg-[#0B63CE] px-6 py-3 text-sm font-bold text-white hover:bg-[#094FA6] disabled:opacity-40"
              >
                Check Answer
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="rounded-xl bg-[#243447] dark:bg-[#0B63CE] px-6 py-3 text-sm font-bold text-white hover:bg-[#172330] dark:hover:bg-[#094FA6]"
              >
                {currentIndex + 1 >= quizQuestions.length ? 'Finish Assessment' : 'Next Question'}
              </button>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
