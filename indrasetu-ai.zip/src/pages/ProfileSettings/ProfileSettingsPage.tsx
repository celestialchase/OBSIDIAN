import React, { useEffect, useState } from 'react';
import { Accessibility, Check, User } from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { CBSE_GRADES } from '../../data/curriculum';
import { formatReadableFirestoreError } from '../../lib/firestoreErrors';
import { updateUserProfileDoc } from '../../services/firestoreService';
import { validateProfilePatch } from '../../utils/firestoreValidation';

export const ProfileSettingsPage: React.FC = () => {
  const {
    user,
    setUser,
    firebaseUid,
    openAuthModal,
    navigate,
    offlineMode,
    resendVerificationEmail,
  } = useApp();
  const [verificationFeedback, setVerificationFeedback] = useState<string | null>(null);
  const {
    settings,
    prefsSaving,
    prefsError,
    updateSettings,
    toggleDyslexiaMode,
    openDrawer,
    saveChanges,
  } = useAccessibility();

  const [name, setName] = useState(user.name);
  const [grade, setGrade] = useState(user.grade);
  const [savedBanner, setSavedBanner] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  useEffect(() => {
    setName(user.name);
    setGrade(user.grade);
  }, [user.id, user.name, user.grade]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError(null);
    setSavedBanner(false);

    const check = validateProfilePatch({ name, grade });
    if (!check.valid) {
      setProfileError(check.error || 'Please enter a valid profile name and class.');
      return;
    }

    setSavingProfile(true);
    try {
      if (firebaseUid) {
        await updateUserProfileDoc(firebaseUid, { name: check.cleanName, grade });
      }
      setUser({
        ...user,
        name: check.cleanName,
        grade,
      });
      const prefsSaved = await saveChanges();
      if (!prefsSaved) {
        setProfileError('Profile updated, but accessibility preferences could not be saved.');
        return;
      }
      setSavedBanner(true);
      window.setTimeout(() => setSavedBanner(false), 2500);
    } catch (err) {
      setProfileError(formatReadableFirestoreError(err));
    } finally {
      setSavingProfile(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">Profile & Personalization</h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Combine multiple accessibility preferences freely across reading, captions, ISL, and visual alerts.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={openDrawer}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#0B49B8] px-4 py-2 text-xs font-bold text-white hover:bg-[#083B96]"
          >
            <Accessibility className="h-4 w-4" aria-hidden="true" />
            <span>Accessibility Options</span>
          </button>
          <button
            type="button"
            onClick={() => openAuthModal('login')}
            className="rounded-xl border border-[#0B63CE] dark:border-sky-500 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2 text-xs font-bold text-[#0B63CE] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700"
          >
            Switch Account / Sign In
          </button>
        </div>
      </section>

      <form
        onSubmit={handleSaveProfile}
        className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-6 space-y-5"
      >
        {offlineMode && (
          <div
            role="status"
            className="rounded-xl border border-[#F2DFBE] dark:border-amber-800 bg-[#FEF4E4] dark:bg-amber-950/50 px-4 py-2.5 text-xs font-semibold text-[#7C2D12] dark:text-amber-200"
          >
            Offline mode detected — changes will fail until network connectivity is restored.
          </div>
        )}

        {!user.isDemo && user.emailVerified === false && (
          <div
            role="alert"
            className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#F2DFBE] dark:border-amber-800 bg-[#FEF4E4] dark:bg-amber-950/50 px-4 py-2.5 text-xs font-semibold text-[#7C2D12] dark:text-amber-200"
          >
            <span>
              Email verification pending. Verify your email to save cloud profile & preference changes.
              {verificationFeedback ? ` (${verificationFeedback})` : ''}
            </span>
            <button
              type="button"
              onClick={() => {
                resendVerificationEmail()
                  .then(() => setVerificationFeedback('Verification link sent'))
                  .catch((err) =>
                    setVerificationFeedback(err instanceof Error ? err.message : 'Unable to send link')
                  );
              }}
              className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
            >
              Resend Link
            </button>
          </div>
        )}

        <div className="flex items-center gap-3 pb-3 border-b border-[#EBF0F5] dark:border-slate-800">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-400">
            <User className="h-5 w-5" aria-hidden="true" />
          </span>
          <div>
            <h2 className="text-base font-bold text-[#243447] dark:text-slate-100">Account Details</h2>
            <p className="text-xs text-[#526275] dark:text-slate-400">
              {user.email} · {user.isDemo ? 'Demo Mode Session' : 'Registered Account'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="prof-name" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
              Display Name
            </label>
            <input
              id="prof-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
            />
          </div>

          <div>
            <label htmlFor="prof-grade" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
              CBSE Class
            </label>
            <select
              id="prof-grade"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
            >
              {CBSE_GRADES.map((g) => (
                <option key={g} value={g}>
                  {g} (CBSE)
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="pt-2 border-t border-[#EBF0F5] dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-[#243447] dark:text-slate-100">Combine Accessibility Support</div>
              <div className="text-xs text-[#526275] dark:text-slate-400">
                Enable any combination of Dyslexia, Captions, ISL, and Text-to-Speech preferences.
              </div>
            </div>
            <button
              type="button"
              data-link-style="true"
              onClick={() => navigate('accessibility')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0B63CE] dark:text-sky-400 hover:underline"
            >
              <Accessibility className="h-4 w-4" aria-hidden="true" />
              <span>Open Full Control Center</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {[
              {
                label: 'Dyslexia Mode (Atkinson font & spacing)',
                checked: settings.dyslexiaMode,
                onToggle: toggleDyslexiaMode,
              },
              {
                label: 'Automatic Video Captions',
                checked: settings.captionsEnabled,
                onToggle: () => updateSettings({ captionsEnabled: !settings.captionsEnabled }),
              },
              {
                label: 'Show ISL Panel by Default in Videos',
                checked: settings.islPanelDefaultVisible,
                onToggle: () =>
                  updateSettings({ islPanelDefaultVisible: !settings.islPanelDefaultVisible }),
              },
              {
                label: 'High Contrast Reading Surfaces',
                checked: settings.highContrast,
                onToggle: () => updateSettings({ highContrast: !settings.highContrast }),
              },
            ].map((item) => (
              <label
                key={item.label}
                className="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
              >
                <span className="text-xs font-bold text-[#243447] dark:text-slate-100">{item.label}</span>
                <input
                  type="checkbox"
                  checked={item.checked}
                  onChange={item.onToggle}
                  className="h-4 w-4 accent-[#0B63CE]"
                />
              </label>
            ))}
          </div>
        </div>

        {(profileError || prefsError) && (
          <div
            role="alert"
            className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
          >
            {profileError || prefsError}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          {savedBanner ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#15803D] dark:text-emerald-400">
              <Check className="h-4 w-4" aria-hidden="true" />
              <span>Profile and preferences saved!</span>
            </span>
          ) : (
            <span />
          )}
          <button
            type="submit"
            disabled={savingProfile || prefsSaving}
            className="rounded-xl bg-[#0B63CE] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6] disabled:opacity-60"
          >
            {savingProfile || prefsSaving ? 'Saving...' : 'Save Profile Preferences'}
          </button>
        </div>
      </form>
    </div>
  );
};
