import React, { useState } from 'react';
import {
  Accessibility,
  AlignJustify,
  BookOpen,
  Check,
  Contrast,
  Crosshair,
  Minus,
  Palette,
  Plus,
  RotateCcw,
  Save,
  Type,
  Volume2,
} from 'lucide-react';
import { ReadingRulerContainer } from '../../components/Accessibility/ReadingRuler';
import { TextToSpeechBar } from '../../components/Accessibility/TextToSpeechBar';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { BackgroundThemeId, ContentWidthOption, FontFamilyOption } from '../../types';
import {
  BACKGROUND_THEMES,
  getFontSizeLabel,
  getLetterSpacingLabel,
  splitIntoSentences,
  stepFontSize,
  stepLetterSpacing,
  stepLineSpacing,
} from '../../utils/accessibility';

const PREVIEW_TEXT =
  'Photosynthesis is the process by which green plants make their own food. Plants use sunlight, water and carbon dioxide to prepare food in their leaves. This process also releases oxygen, which is important for all living beings.';

export const AccessibilitySettingsPage: React.FC = () => {
  const { selectedGrade } = useApp();
  const {
    settings,
    readingStyles,
    lastSavedAt,
    prefsLoading,
    prefsSaving,
    prefsError,
    updateSettings,
    openDrawer,
    toggleDyslexiaMode,
    resetToDefaults,
    saveChanges,
  } = useAccessibility();

  const [activeSentenceIdx, setActiveSentenceIdx] = useState<number | null>(null);
  const previewSentences = splitIntoSentences(PREVIEW_TEXT);

  const toggleCards = [
    {
      id: 'dyslexia',
      title: 'Dyslexia Mode',
      desc: 'Uses a dyslexia-friendly font, extra spacing and a calm layout.',
      icon: Type,
      checked: settings.dyslexiaMode,
      onToggle: toggleDyslexiaMode,
    },
    {
      id: 'focus',
      title: 'Focus Mode',
      desc: 'Reduces distractions and keeps only the essential content.',
      icon: Crosshair,
      checked: settings.focusMode,
      onToggle: () => updateSettings({ focusMode: !settings.focusMode }),
    },
    {
      id: 'ruler',
      title: 'Reading Ruler',
      desc: 'Adds a movable highlight to help you read line by line.',
      icon: AlignJustify,
      checked: settings.readingRuler,
      onToggle: () => updateSettings({ readingRuler: !settings.readingRuler }),
    },
    {
      id: 'tts',
      title: 'Text-to-Speech',
      desc: 'Listen to the text read aloud in a clear voice.',
      icon: Volume2,
      checked: settings.textToSpeech,
      onToggle: () => updateSettings({ textToSpeech: !settings.textToSpeech }),
    },
    {
      id: 'contrast',
      title: 'High Contrast',
      desc: 'Increases colour contrast for clearer and easier reading.',
      icon: Contrast,
      checked: settings.highContrast,
      onToggle: () => updateSettings({ highContrast: !settings.highContrast }),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner (Reference 2 & 3) */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#CFE0F5] dark:border-slate-700 bg-[#DCEBFA] dark:bg-slate-800 px-5 py-4">
        <div className="flex items-center gap-3.5">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#0B63CE] text-white shrink-0">
            <Accessibility className="h-6 w-6" aria-hidden="true" />
          </span>
          <div>
            <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">
              Accessibility Control Center
            </h1>
            <p className="text-sm text-[#354B63] dark:text-slate-300">
              Customize your learning experience for easier reading, better focus and greater comfort ({selectedGrade} · CBSE).
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={openDrawer}
            className="inline-flex items-center gap-2 rounded-xl bg-[#0B49B8] px-4 py-2 text-xs font-bold text-white hover:bg-[#083B96] transition-colors whitespace-nowrap"
          >
            <Accessibility className="h-4 w-4" aria-hidden="true" />
            <span>Open Slide-Out Panel</span>
          </button>
          {lastSavedAt && (
            <div className="inline-flex items-center gap-1.5 rounded-xl bg-white dark:bg-slate-900 px-3.5 py-2 text-xs font-bold text-[#15803D] dark:text-emerald-400 border border-[#B6E0DA] dark:border-emerald-800">
              <Check className="h-4 w-4" aria-hidden="true" />
              <span>Saved ({lastSavedAt})</span>
            </div>
          )}
        </div>
      </div>

      {prefsLoading && (
        <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
          Restoring your saved accessibility preferences...
        </div>
      )}

      {prefsError && (
        <div
          role="alert"
          className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
        >
          {prefsError}
        </div>
      )}

      {/* 5 Top Control Cards (Reference 2) */}
      <section aria-label="Primary Accessibility Modes" className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-5">
        {toggleCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              className={`flex flex-col justify-between rounded-2xl border p-4 transition-colors ${
                card.checked
                  ? 'border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800'
                  : 'border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900'
              }`}
            >
              <div>
                <Icon className="h-6 w-6 text-[#243447] dark:text-slate-100" aria-hidden="true" />
                <h2 className="mt-3 text-base font-bold text-[#243447] dark:text-slate-100">{card.title}</h2>
                <p className="mt-1 text-xs leading-relaxed text-[#4A5E75] dark:text-slate-300">{card.desc}</p>
              </div>
              <div className="mt-4 flex items-center gap-2.5">
                <button
                  type="button"
                  role="switch"
                  aria-checked={card.checked}
                  aria-label={`Toggle ${card.title}`}
                  onClick={card.onToggle}
                  className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full transition-colors ${
                    card.checked ? 'bg-[#0B63CE]' : 'bg-[#B8C5D4] dark:bg-slate-600'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${
                      card.checked ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
                <span className="text-xs font-bold text-[#243447] dark:text-slate-200">
                  {card.checked ? 'On' : 'Off'}
                </span>
              </div>
            </div>
          );
        })}
      </section>

      {/* Typography Stepper Bar (Reference 3) */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center gap-2.5">
            <Type className="h-5 w-5 text-[#243447] dark:text-slate-100" aria-hidden="true" />
            <div>
              <div className="text-sm font-bold text-[#243447] dark:text-slate-100">Font Size</div>
              <div className="text-xs text-[#526275] dark:text-slate-400">Make text larger or smaller</div>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between gap-2">
            <button
              type="button"
              aria-label="Decrease font size"
              onClick={() => updateSettings({ fontSizePercent: stepFontSize(settings.fontSizePercent, -10) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Minus className="h-4 w-4" />
            </button>
            <div className="flex-1 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 py-2 text-center text-sm font-bold text-[#243447] dark:text-slate-100 font-tabular">
              {getFontSizeLabel(settings.fontSizePercent)} ({settings.fontSizePercent}%)
            </div>
            <button
              type="button"
              aria-label="Increase font size"
              onClick={() => updateSettings({ fontSizePercent: stepFontSize(settings.fontSizePercent, 10) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center gap-2.5">
            <AlignJustify className="h-5 w-5 text-[#243447] dark:text-slate-100" aria-hidden="true" />
            <div>
              <div className="text-sm font-bold text-[#243447] dark:text-slate-100">Line Spacing</div>
              <div className="text-xs text-[#526275] dark:text-slate-400">Adjust space between lines</div>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between gap-2">
            <button
              type="button"
              aria-label="Decrease line spacing"
              onClick={() => updateSettings({ lineSpacing: stepLineSpacing(settings.lineSpacing, -0.1) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Minus className="h-4 w-4" />
            </button>
            <div className="flex-1 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 py-2 text-center text-sm font-bold text-[#243447] dark:text-slate-100 font-tabular">
              {settings.lineSpacing.toFixed(1)}×
            </div>
            <button
              type="button"
              aria-label="Increase line spacing"
              onClick={() => updateSettings({ lineSpacing: stepLineSpacing(settings.lineSpacing, 0.1) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
          <div className="flex items-center gap-2.5">
            <span className="text-sm font-bold text-[#243447] dark:text-slate-100" aria-hidden="true">
              A↔A
            </span>
            <div>
              <div className="text-sm font-bold text-[#243447] dark:text-slate-100">Letter Spacing</div>
              <div className="text-xs text-[#526275] dark:text-slate-400">Adjust space between letters</div>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between gap-2">
            <button
              type="button"
              aria-label="Decrease letter spacing"
              onClick={() => updateSettings({ letterSpacing: stepLetterSpacing(settings.letterSpacing, -0.02) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Minus className="h-4 w-4" />
            </button>
            <div className="flex-1 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 py-2 text-center text-sm font-bold text-[#243447] dark:text-slate-100 font-tabular">
              {getLetterSpacingLabel(settings.letterSpacing)} ({settings.letterSpacing.toFixed(2)}em)
            </div>
            <button
              type="button"
              aria-label="Increase letter spacing"
              onClick={() => updateSettings({ letterSpacing: stepLetterSpacing(settings.letterSpacing, 0.02) })}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DCEBFA] dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300 hover:bg-[#C6DFFA] dark:hover:bg-slate-700"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Main Split: Sliders + Font/Width/Color Controls | Live Preview */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-6 space-y-5 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6">
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="slider-text-size" className="text-sm font-bold text-[#243447] dark:text-slate-100">
                Text Size Slider
              </label>
              <span className="rounded-lg border border-[#DCE5EF] dark:border-slate-700 px-2.5 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular">
                {settings.fontSizePercent}%
              </span>
            </div>
            <input
              id="slider-text-size"
              type="range"
              min={85}
              max={160}
              step={5}
              value={settings.fontSizePercent}
              onChange={(e) => updateSettings({ fontSizePercent: Number(e.target.value) })}
              className="mt-2.5 w-full accent-[#0B63CE] cursor-pointer"
            />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="slider-line-spacing" className="text-sm font-bold text-[#243447] dark:text-slate-100">
                Line Spacing Slider
              </label>
              <span className="rounded-lg border border-[#DCE5EF] dark:border-slate-700 px-2.5 py-1 text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular">
                {settings.lineSpacing.toFixed(1)}×
              </span>
            </div>
            <input
              id="slider-line-spacing"
              type="range"
              min={1.3}
              max={2.2}
              step={0.1}
              value={settings.lineSpacing}
              onChange={(e) => updateSettings({ lineSpacing: Number(e.target.value) })}
              className="mt-2.5 w-full accent-[#0B63CE] cursor-pointer"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="select-font-family" className="block text-sm font-bold text-[#243447] dark:text-slate-100">
                Reading Font
              </label>
              <select
                id="select-font-family"
                value={settings.fontFamily}
                onChange={(e) => updateSettings({ fontFamily: e.target.value as FontFamilyOption })}
                className="mt-1.5 w-full rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-2 text-sm font-semibold text-[#243447] dark:text-slate-100"
              >
                <option value="atkinson">Atkinson Hyperlegible</option>
                <option value="arial">Arial (Clean Sans)</option>
                <option value="jakarta">Plus Jakarta Sans</option>
              </select>
            </div>

            <div>
              <label htmlFor="select-content-width" className="block text-sm font-bold text-[#243447] dark:text-slate-100">
                Reading Width
              </label>
              <select
                id="select-content-width"
                value={settings.contentWidth}
                onChange={(e) => updateSettings({ contentWidth: e.target.value as ContentWidthOption })}
                className="mt-1.5 w-full rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-2 text-sm font-semibold text-[#243447] dark:text-slate-100"
              >
                <option value="narrow">Narrow (620px)</option>
                <option value="standard">Standard (740px)</option>
                <option value="wide">Wide (920px)</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="slider-para-spacing" className="text-sm font-bold text-[#243447] dark:text-slate-100">
                Paragraph Spacing
              </label>
              <span className="text-xs font-bold text-[#526275] dark:text-slate-300 font-tabular">
                {settings.paragraphSpacing.toFixed(1)} rem
              </span>
            </div>
            <input
              id="slider-para-spacing"
              type="range"
              min={0.8}
              max={2.4}
              step={0.2}
              value={settings.paragraphSpacing}
              onChange={(e) => updateSettings({ paragraphSpacing: Number(e.target.value) })}
              className="mt-2 w-full accent-[#0B63CE] cursor-pointer"
            />
          </div>

          {/* Warm Background Color Swatches (Reference 3) */}
          <div>
            <div className="flex items-center gap-2 text-sm font-bold text-[#243447] dark:text-slate-100">
              <Palette className="h-4 w-4 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
              <span>Warm Background Color</span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2.5 sm:grid-cols-6">
              {(Object.keys(BACKGROUND_THEMES) as BackgroundThemeId[]).map((key) => {
                const theme = BACKGROUND_THEMES[key];
                const selected = settings.backgroundTheme === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => updateSettings({ backgroundTheme: key })}
                    aria-pressed={selected}
                    className="flex flex-col items-center gap-1.5 text-center"
                  >
                    <span
                      className={`flex h-12 w-full items-center justify-center rounded-xl border-2 transition-all ${
                        selected ? 'border-[#0B63CE] ring-2 ring-[#0B63CE]/25' : 'border-[#D4DFEC] dark:border-slate-600'
                      }`}
                      style={{ backgroundColor: theme.bgHex }}
                    >
                      {selected && <Check className="h-5 w-5 text-[#0B63CE]" aria-hidden="true" />}
                    </span>
                    <span className="text-[11px] font-semibold text-[#243447] dark:text-slate-200">{theme.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#EBF0F5] dark:border-slate-800">
            <button
              type="button"
              onClick={resetToDefaults}
              className="inline-flex items-center gap-2 rounded-xl border border-[#243447] dark:border-slate-600 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm font-bold text-[#243447] dark:text-slate-100 hover:bg-[#FAF9F6] dark:hover:bg-slate-700 transition-colors"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>Reset to Default</span>
            </button>
            <button
              type="button"
              disabled={prefsSaving}
              onClick={() => {
                void saveChanges();
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-[#243447] dark:bg-[#0B63CE] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#182331] dark:hover:bg-[#094FA6] transition-colors disabled:opacity-60"
            >
              <Save className="h-4 w-4" aria-hidden="true" />
              <span>{prefsSaving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </div>

        {/* Right: Live Reading Preview Panel (Reference 2) */}
        <div className="lg:col-span-6 flex flex-col justify-between rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4">
          <div>
            <div className="flex items-center gap-2.5">
              <BookOpen className="h-5 w-5 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
              <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Live Preview (Reading Panel)</h2>
            </div>
            <p className="mt-1 text-xs text-[#526275] dark:text-slate-400">
              Move your cursor over the text below to test the Reading Ruler, or adjust any slider on the left.
            </p>
          </div>

          <ReadingRulerContainer
            enabled={settings.readingRuler}
            className="rounded-2xl border p-5 sm:p-6 transition-colors"
            style={{
              backgroundColor: readingStyles.backgroundColor,
              color: readingStyles.textColor,
              borderColor: readingStyles.borderColor,
              fontFamily: readingStyles.fontFamily,
              fontSize: `${readingStyles.fontSizePx}px`,
              lineHeight: readingStyles.lineHeight,
              letterSpacing: readingStyles.letterSpacingEm,
              wordSpacing: readingStyles.wordSpacingEm,
            }}
          >
            <p className="text-left">
              {previewSentences.map((sentence, idx) => (
                <span
                  key={idx}
                  className={
                    activeSentenceIdx === idx
                      ? 'rounded bg-[#FDE047]/65 px-1 py-0.5 text-[#090D14]'
                      : ''
                  }
                >
                  {sentence}{' '}
                </span>
              ))}
            </p>
          </ReadingRulerContainer>

          <TextToSpeechBar
            text={PREVIEW_TEXT}
            rate={settings.ttsRate}
            onRateChange={(rate) => updateSettings({ ttsRate: rate })}
            onActiveSentenceChange={(sentenceIdx) => setActiveSentenceIdx(sentenceIdx)}
          />
        </div>
      </section>
    </div>
  );
};
