import React from 'react';
import {
  Accessibility,
  ArrowRight,
  BookOpen,
  Calculator,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  FlaskConical,
  Globe2,
  Hand,
  Laptop,
  Leaf,
  MessageSquareText,
  Play,
  Settings,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { SubjectName } from '../../types';
import { computeProgressStats } from '../../utils/assessmentLogic';

const SUBJECT_ICONS: Record<SubjectName, React.ComponentType<{ className?: string }>> = {
  English: BookOpen,
  Mathematics: Calculator,
  Science: FlaskConical,
  'Social Science': Globe2,
  Hindi: Leaf,
  Computer: Laptop,
};

const SUBJECT_COLORS: Record<SubjectName, string> = {
  English: 'text-[#0B63CE] bg-[#EAF3FF] dark:bg-sky-950/60 dark:text-sky-300',
  Mathematics: 'text-[#4F46E5] bg-[#EEF2FF] dark:bg-indigo-950/60 dark:text-indigo-300',
  Science: 'text-[#3C8D91] bg-[#E6F5EE] dark:bg-teal-950/60 dark:text-teal-300',
  'Social Science': 'text-[#0D9488] bg-[#E6F5EE] dark:bg-emerald-950/60 dark:text-emerald-300',
  Hindi: 'text-[#15803D] bg-[#ECFDF5] dark:bg-green-950/60 dark:text-green-300',
  Computer: 'text-[#0284C7] bg-[#EAF3FF] dark:bg-sky-950/60 dark:text-sky-300',
};

export const DashboardPage: React.FC = () => {
  const {
    user,
    selectedGrade,
    courses,
    lessons,
    notes,
    quizAttempts,
    navigate,
    openLesson,
    setSelectedSubjectFilter,
    syncLoading,
    firestoreError,
    offlineMode,
    resendVerificationEmail,
  } = useApp();
  const [verificationSent, setVerificationSent] = React.useState(false);
  const [verificationError, setVerificationError] = React.useState<string | null>(null);
  const { settings, toggleDyslexiaMode, openDrawer } = useAccessibility();

  const stats = computeProgressStats(lessons, courses, quizAttempts);
  const firstName = user.name.split(' ')[0] || 'Student';

  const handleOpenCourse = (subject: SubjectName) => {
    setSelectedSubjectFilter(subject);
    const matching = lessons.find((l) => l.subject === subject);
    if (matching) {
      openLesson(matching.id);
    } else {
      navigate('learning');
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-[#243447] dark:text-white sm:text-3xl">
            Welcome, {firstName}!
          </h1>
          <p className="mt-1 text-base text-[#4A5E75] dark:text-slate-300">
            Continue your inclusive learning journey at your own pace · {selectedGrade} CBSE
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={openDrawer}
            className="inline-flex items-center gap-2 rounded-xl border border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2 text-sm font-bold text-[#0B49B8] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700 whitespace-nowrap shrink-0"
          >
            <Accessibility className="h-4 w-4" aria-hidden="true" />
            <span>Accessibility Options</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('doubt')}
            className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-4 py-2 text-sm font-semibold text-white hover:bg-[#094FA6] transition-colors whitespace-nowrap shrink-0"
          >
            <MessageSquareText className="h-4 w-4" aria-hidden="true" />
            <span>Ask AI Doubt Solver</span>
          </button>
        </div>
      </section>

      {offlineMode && (
        <div
          role="status"
          className="rounded-xl border border-[#F2DFBE] dark:border-amber-800 bg-[#FEF4E4] dark:bg-amber-950/50 px-4 py-2.5 text-xs font-semibold text-[#7C2D12] dark:text-amber-200"
        >
          You are currently offline. Live AI features and cloud writes will resume once internet connectivity returns.
        </div>
      )}

      {!user.isDemo && user.emailVerified === false && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#F2DFBE] dark:border-amber-800 bg-[#FEF4E4] dark:bg-amber-950/50 px-4 py-2.5 text-xs font-semibold text-[#7C2D12] dark:text-amber-200"
        >
          <span>
            Please verify your email address ({user.email}) using the link sent to your inbox to save progress and use live AI tools.
            {verificationSent && ' Verification email resent.'}
            {verificationError && ` (${verificationError})`}
          </span>
          <button
            type="button"
            onClick={() => {
              setVerificationError(null);
              resendVerificationEmail()
                .then(() => setVerificationSent(true))
                .catch((err) =>
                  setVerificationError(err instanceof Error ? err.message : 'Unable to resend link.')
                );
            }}
            className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6] shrink-0"
          >
            Resend Verification Email
          </button>
        </div>
      )}

      {syncLoading && (
        <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
          Syncing your saved profile, progress, and notes from Cloud Firestore...
        </div>
      )}

      {firestoreError && (
        <div
          role="alert"
          className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
        >
          {firestoreError}
        </div>
      )}

      {/* Top 4 Quick Actions Grid (Matches Reference Image) */}
      <section aria-label="Quick Actions" className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <button
          type="button"
          onClick={() => openLesson('lesson-photosynthesis')}
          className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-900 p-5 text-center hover:border-[#0B63CE]"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300">
            <BookOpen className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="text-sm font-bold text-[#243447] dark:text-white">Continue Learning</div>
          <div className="text-xs text-[#4A5E75] dark:text-slate-300">Resume where you left off</div>
        </button>

        <button
          type="button"
          onClick={() => navigate('isl')}
          className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-[#D8D8F2] dark:border-slate-700 bg-[#F2F0FF] dark:bg-slate-900 p-5 text-center hover:border-[#0B63CE]"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-[#4F46E5] dark:text-indigo-300">
            <Hand className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="text-sm font-bold text-[#243447] dark:text-white">ISL Library</div>
          <div className="text-xs text-[#4A5E75] dark:text-slate-300">Browse Indian Sign Language</div>
        </button>

        <button
          type="button"
          onClick={() => navigate('doubt')}
          className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-[#F2DFBE] dark:border-slate-700 bg-[#FEF4E4] dark:bg-slate-900 p-5 text-center hover:border-[#D97706]"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-[#B45309] dark:text-amber-300">
            <Sparkles className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="text-sm font-bold text-[#243447] dark:text-white">Ask AI Doubt Solver</div>
          <div className="text-xs text-[#4A5E75] dark:text-slate-300">Text & visual explanations</div>
        </button>

        <button
          type="button"
          onClick={openDrawer}
          className="flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 p-5 text-center hover:bg-[#DCEBFA] dark:hover:bg-slate-700"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white dark:bg-slate-900 text-[#0B49B8] dark:text-sky-300">
            <Settings className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="text-sm font-bold text-[#0B49B8] dark:text-sky-300">
            Accessibility Options
          </div>
          <div className="text-xs text-[#354B63] dark:text-slate-300">Open quick slide-out panel</div>
        </button>
      </section>

      {/* Main 2-Column Portal Section: My Courses (CBSE) + My Learning Progress */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: My Courses */}
        <div className="lg:col-span-8 rounded-2xl border border-[#DCE5EF] dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-lg font-bold text-[#243447] dark:text-white">My Courses (CBSE)</h2>
            <button
              type="button"
              onClick={() => navigate('learning')}
              className="text-sm font-semibold text-[#0B63CE] dark:text-sky-400 hover:underline whitespace-nowrap"
            >
              View All Courses →
            </button>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-3.5 sm:grid-cols-2 md:grid-cols-3">
            {courses.map((course) => {
              const Icon = SUBJECT_ICONS[course.subject];
              const iconTone = SUBJECT_COLORS[course.subject];
              return (
                <button
                  key={course.id}
                  type="button"
                  onClick={() => handleOpenCourse(course.subject)}
                  className="flex flex-col items-start justify-between rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800/80 p-4 text-left hover:border-[#0B63CE] hover:bg-[#F5F9FF] dark:hover:bg-slate-800"
                >
                  <div className="flex w-full items-center justify-between">
                    <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${iconTone}`}>
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <span className="text-xs font-bold text-[#3C8D91] dark:text-teal-400 font-tabular">
                      {course.progressPercent}%
                    </span>
                  </div>
                  <div className="mt-3 text-base font-bold text-[#243447] dark:text-white">
                    {course.subject}
                  </div>
                  <div className="mt-1 text-xs text-[#526275] dark:text-slate-400 line-clamp-1">
                    {course.lessonsCompleted}/{course.totalLessons} lessons
                  </div>
                  <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-[#DCE5EF] dark:bg-slate-700">
                    <div
                      className="h-full rounded-full bg-[#3C8D91]"
                      style={{ width: `${course.progressPercent}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: My Learning Progress */}
        <div className="lg:col-span-4 rounded-2xl border border-[#DCE5EF] dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-[#243447] dark:text-white">
                My Learning Progress
              </h2>
              <button
                type="button"
                onClick={() => navigate('progress')}
                className="text-xs font-semibold text-[#0B63CE] dark:text-sky-400 hover:underline"
              >
                Details
              </button>
            </div>

            <div className="mt-5">
              <div className="flex items-center justify-between text-sm font-semibold text-[#243447] dark:text-slate-200">
                <span>Overall Progress</span>
                <span className="font-tabular text-base font-bold">{stats.overallPercent}%</span>
              </div>
              <div className="mt-2 h-3 w-full overflow-hidden rounded-full bg-[#E5EDF5] dark:bg-slate-700">
                <div
                  className="h-full rounded-full bg-[#3C8D91] transition-all"
                  style={{ width: `${stats.overallPercent}%` }}
                />
              </div>
            </div>

            <ul className="mt-6 space-y-3 text-sm">
              <li className="flex items-center gap-3 text-[#243447] dark:text-slate-200">
                <CheckCircle2 className="h-5 w-5 text-[#16A34A] shrink-0" aria-hidden="true" />
                <span>
                  <strong className="font-tabular">{stats.completedLessons}</strong>{' '}
                  {stats.completedLessons === 1 ? 'lesson' : 'lessons'} completed
                </span>
              </li>
              <li className="flex items-center gap-3 text-[#243447] dark:text-slate-200">
                <Clock className="h-5 w-5 text-[#0B63CE] dark:text-sky-400 shrink-0" aria-hidden="true" />
                <span>
                  <strong className="font-tabular">{stats.inProgressLessons}</strong>{' '}
                  {stats.inProgressLessons === 1 ? 'lesson' : 'lessons'} in progress
                </span>
              </li>
              <li className="flex items-center gap-3 text-[#243447] dark:text-slate-200">
                <span className="h-5 w-5 rounded-full border-2 border-[#64748B] shrink-0" aria-hidden="true" />
                <span>
                  <strong className="font-tabular">{stats.pendingLessons}</strong>{' '}
                  {stats.pendingLessons === 1 ? 'lesson' : 'lessons'} pending
                </span>
              </li>
            </ul>
          </div>

          <div className="mt-6 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5 text-xs text-[#4A5E75] dark:text-slate-300">
            Average Quiz Score:{' '}
            <strong className="text-[#243447] dark:text-white font-tabular">
              {stats.averageQuizPercent}%
            </strong>{' '}
            across {quizAttempts.length} assessments
          </div>
        </div>
      </section>

      {/* Bottom 3 Accessibility & Study Shortcut Cards */}
      <section aria-label="Accessibility Quick Access" className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <button
          type="button"
          onClick={() => navigate('videos')}
          className="flex items-center justify-between gap-4 rounded-2xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-900 p-4 text-left hover:border-[#0B63CE]"
        >
          <div className="flex items-center gap-3.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-[#0B63CE] dark:text-sky-300">
              <Play className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="text-base font-bold text-[#243447] dark:text-white">
                Captioned Video Lessons
              </div>
              <div className="text-xs text-[#4A5E75] dark:text-slate-300">
                Watch with ISL & transcripts
              </div>
            </div>
          </div>
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#3C8D91] text-white">
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </span>
        </button>

        <button
          type="button"
          onClick={() => navigate('accessibility')}
          className="flex items-center justify-between gap-4 rounded-2xl border border-[#C6E8DA] dark:border-slate-700 bg-[#E6F5EE] dark:bg-slate-900 p-4 text-left hover:border-[#3C8D91]"
        >
          <div className="flex items-center gap-3.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-[#3C8D91] dark:text-teal-300">
              <SlidersHorizontal className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="text-base font-bold text-[#243447] dark:text-white">
                Accessibility Settings
              </div>
              <div className="text-xs text-[#4A5E75] dark:text-slate-400">
                Live preview & reading ruler
              </div>
            </div>
          </div>
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#3C8D91] text-white">
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </span>
        </button>

        <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#C6E8DA] dark:border-slate-700 bg-[#E6F5EE] dark:bg-slate-900 p-4">
          <div className="flex items-center gap-3.5">
            <button
              type="button"
              role="switch"
              aria-checked={settings.dyslexiaMode}
              aria-label="Toggle Dyslexia Mode shortcut"
              onClick={toggleDyslexiaMode}
              className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full transition-colors ${
                settings.dyslexiaMode ? 'bg-[#3C8D91]' : 'bg-[#94A8B8] dark:bg-slate-600'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${
                  settings.dyslexiaMode ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <div>
              <div className="text-base font-bold text-[#243447] dark:text-white">Dyslexia Mode</div>
              <div className="text-xs text-[#4A5E75] dark:text-slate-400">
                {settings.dyslexiaMode ? 'Active across app' : 'A reading-friendly view'}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigate('assessments')}
            aria-label="Open Practice Assessments"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#3C8D91] text-white hover:bg-[#2F7275]"
          >
            <ClipboardCheck className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </section>

      {/* Recently Viewed / Recommended Lessons & Saved Notes */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7 rounded-2xl border border-[#DCE5EF] dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6">
          <h2 className="text-lg font-bold text-[#243447] dark:text-white">
            Recently Viewed & Recommended Lessons
          </h2>
          <div className="mt-4 space-y-3">
            {lessons.slice(0, 3).map((lesson) => (
              <div
                key={lesson.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-4"
              >
                <div className="min-w-[200px] flex-1">
                  <div className="text-xs font-semibold text-[#3C8D91] dark:text-teal-400">
                    {lesson.subject} · {lesson.grade} ·{' '}
                    {lesson.status === 'completed'
                      ? 'Completed'
                      : lesson.status === 'in-progress'
                      ? 'In Progress'
                      : 'Recommended'}
                  </div>
                  <div className="mt-0.5 text-base font-bold text-[#243447] dark:text-white">
                    {lesson.title}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => openLesson(lesson.id)}
                  className="rounded-xl bg-[#0B63CE] px-4 py-2 text-xs font-bold text-white hover:bg-[#094FA6] transition-colors whitespace-nowrap shrink-0"
                >
                  Open Reader
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 rounded-2xl border border-[#DCE5EF] dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-[#243447] dark:text-white">
              Saved Notes & Upcoming Checks
            </h2>
            <button
              type="button"
              onClick={() => navigate('progress')}
              className="text-xs font-semibold text-[#0B63CE] dark:text-sky-400 hover:underline"
            >
              All Notes
            </button>
          </div>
          <div className="mt-4 space-y-3">
            {notes.length === 0 ? (
              <div className="rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5 text-xs text-[#526275] dark:text-slate-400">
                No saved notes yet — save key passages while reading or using AI Doubt Solver.
              </div>
            ) : (
              notes.slice(0, 2).map((note) => (
                <div
                  key={note.id}
                  className="rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
                >
                  <div className="flex items-center justify-between gap-2 text-xs font-semibold text-[#3C8D91] dark:text-teal-400">
                    <span>{note.subject}</span>
                    <span className="text-[#526275] dark:text-slate-400">{note.createdAt}</span>
                  </div>
                  <div className="mt-1 text-sm font-bold text-[#243447] dark:text-white">
                    {note.title}
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-[#4A5E75] dark:text-slate-300">
                    {note.content}
                  </p>
                </div>
              ))
            )}
            <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-3.5 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#0B63CE] dark:text-sky-300">
                  Upcoming Assessment
                </div>
                <div className="text-sm font-bold text-[#243447] dark:text-white">
                  Science & Math Visual Quiz
                </div>
              </div>
              <button
                type="button"
                onClick={() => navigate('assessments')}
                className="rounded-lg bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-bold text-[#0B63CE] dark:text-sky-300 border border-[#CFE0F5] dark:border-slate-700 hover:bg-[#DCEBFA] whitespace-nowrap"
              >
                Start Quiz
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
