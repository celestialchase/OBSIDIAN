import React from 'react';
import {
  Accessibility,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Eye,
  Hand,
  MessageSquareText,
  PlaySquare,
  Sparkles,
} from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { ASSET_PATHS } from '../../data/curriculum';

export const LandingPage: React.FC = () => {
  const { navigate, openAuthModal } = useApp();
  const { openDrawer } = useAccessibility();

  return (
    <div className="min-h-screen bg-[#FAF9F6] dark:bg-slate-950 text-[#243447] dark:text-slate-100">
      {/* Clean 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 border-b border-[#E3EAF2] dark:border-slate-800 bg-[#FAF9F6]/95 dark:bg-slate-900/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-4">
          <button
            type="button"
            onClick={() => navigate('landing')}
            className="text-xl font-extrabold tracking-tight text-[#243447] dark:text-white whitespace-nowrap shrink-0"
          >
            IndraSetu AI
          </button>

          <nav aria-label="Landing Navigation" className="hidden md:flex items-center gap-7 text-sm font-semibold text-[#4A5E75] dark:text-slate-300">
            <a href="#features" className="hover:text-[#0B63CE] dark:hover:text-sky-400 hover:underline whitespace-nowrap shrink-0">
              Features
            </a>
            <a href="#how-it-works" className="hover:text-[#0B63CE] dark:hover:text-sky-400 hover:underline whitespace-nowrap shrink-0">
              How It Works
            </a>
            <a href="#inclusive-support" className="hover:text-[#0B63CE] dark:hover:text-sky-400 hover:underline whitespace-nowrap shrink-0">
              Accessibility
            </a>
            <button
              type="button"
              onClick={() => openAuthModal('login')}
              className="hover:text-[#0B63CE] dark:hover:text-sky-400 hover:underline whitespace-nowrap shrink-0"
            >
              Sign In
            </button>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate('dashboard')}
              className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6] transition-colors whitespace-nowrap shrink-0"
            >
              <span>Get Started</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main>
        <section className="mx-auto max-w-6xl px-6 py-12 lg:py-20">
          <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-6 space-y-6">
              <p className="text-sm font-bold tracking-wide text-[#3C8D91] dark:text-teal-400">
                Har ishare se seekhna, har kisi ke liye
              </p>
              <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-[#243447] dark:text-white sm:text-5xl text-balance">
                Learning Without Communication Barriers.
              </h1>
              <p className="text-lg leading-relaxed text-[#4A5E75] dark:text-slate-300 max-w-xl">
                An AI-powered inclusive learning platform that transforms conventional CBSE education into accessible, visual, and interactive learning experiences.
              </p>

              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <button
                  type="button"
                  onClick={() => navigate('dashboard')}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-6 py-3.5 text-base font-bold text-white hover:bg-[#094FA6] transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Get Started</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
                <a
                  href="#features"
                  className="inline-flex items-center gap-2 rounded-xl border border-[#C7D7EA] dark:border-slate-700 bg-white dark:bg-slate-900 px-5 py-3.5 text-base font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Explore Features</span>
                </a>
                <button
                  type="button"
                  onClick={openDrawer}
                  className="inline-flex items-center gap-2 rounded-xl border border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 px-4 py-3 text-sm font-bold text-[#0B49B8] dark:text-sky-300 hover:bg-[#DCEBFA] transition-colors whitespace-nowrap shrink-0"
                >
                  <Accessibility className="h-4 w-4" aria-hidden="true" />
                  <span>Accessibility Options</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 pt-3 text-sm font-medium text-[#526275] dark:text-slate-400 sm:flex sm:flex-wrap sm:items-center sm:gap-x-5">
                <span className="whitespace-nowrap">CBSE Classes 6–10</span>
                <span className="whitespace-nowrap">Dyslexia Reading Engine</span>
                <span className="whitespace-nowrap">Captioned Video + ISL</span>
                <span className="whitespace-nowrap">Gemini AI Tutor</span>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div
                data-image-container="true"
                className="relative overflow-hidden rounded-2xl border border-[#D7E4F3] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-900 p-3 shadow-sm"
              >
                <img
                  src={ASSET_PATHS.heroInclusive}
                  alt="Diverse Indian middle-school students learning together using visual diagrams and sign language support on a tablet."
                  referrerPolicy="no-referrer"
                  className="h-full w-full rounded-xl object-cover aspect-[4/3]"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Designed for Diverse Learners */}
        <section id="inclusive-support" className="border-y border-[#E3EAF2] dark:border-slate-800 bg-white dark:bg-slate-900 py-14">
          <div className="mx-auto max-w-6xl px-6">
            <div className="max-w-2xl">
              <h2 className="text-2xl font-extrabold text-[#243447] dark:text-white sm:text-3xl">
                Built Around Real Accessibility Needs
              </h2>
              <p className="mt-2 text-base text-[#4A5E75] dark:text-slate-300">
                Students can combine reading, captioning, sign language, and visual communication tools freely without being locked into fixed categories.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-5">
                <BookOpen className="h-6 w-6 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                <h3 className="mt-3 text-base font-bold text-[#243447] dark:text-white">Dyslexia Support</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                  Atkinson Hyperlegible font, customizable line and letter spacing, warm paper backgrounds, and a live reading ruler.
                </p>
              </div>

              <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-5">
                <Hand className="h-6 w-6 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
                <h3 className="mt-3 text-base font-bold text-[#243447] dark:text-white">Deaf & Hard-of-Hearing</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                  Synchronized customizable captions, downloadable transcripts, key-term highlights, and a searchable ISL library.
                </p>
              </div>

              <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-5">
                <MessageSquareText className="h-6 w-6 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                <h3 className="mt-3 text-base font-bold text-[#243447] dark:text-white">Non-Speaking Friendly</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                  Visual communication cards, phrase builders, text-first AI doubt solving, and optional Text-to-Speech output.
                </p>
              </div>

              <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-5">
                <Eye className="h-6 w-6 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
                <h3 className="mt-3 text-base font-bold text-[#243447] dark:text-white">Visual Learners</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                  Interactive Science and Math diagrams, step-by-step concept breakdowns, and image-based accessible quizzes.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section id="features" className="mx-auto max-w-6xl px-6 py-16">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-extrabold text-[#243447] dark:text-white sm:text-3xl">
                Core Learning Modules
              </h2>
              <p className="mt-2 text-base text-[#4A5E75] dark:text-slate-300">
                Explore every workspace directly in Demo Mode with realistic CBSE Class 8 lessons.
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('dashboard')}
              className="inline-flex items-center gap-2 rounded-xl border border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-sm font-bold text-[#0B63CE] dark:text-sky-300 hover:bg-[#DCEBFA] transition-colors whitespace-nowrap"
            >
              <span>Open Student Portal</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: 'Accessibility Control Center',
                desc: 'Adjust font size, line height, letter spacing, background tint, Focus Mode, and Reading Ruler with a live reading preview.',
                icon: Accessibility,
                route: 'accessibility' as const,
                bg: 'bg-[#EAF3FF] dark:bg-sky-950/60',
              },
              {
                title: 'Dyslexia-Friendly Reader',
                desc: 'Read structured chapters with sentence-by-sentence Text-to-Speech highlighting and AI passage simplification.',
                icon: BookOpen,
                route: 'learning' as const,
                bg: 'bg-[#E6F5EE] dark:bg-teal-950/60',
              },
              {
                title: 'Captioned Video & ISL Panel',
                desc: 'Watch visual science lessons with adjustable captions, movable ISL interpreter window, and downloadable transcripts.',
                icon: PlaySquare,
                route: 'videos' as const,
                bg: 'bg-[#EAF3FF] dark:bg-sky-950/60',
              },
              {
                title: 'AI Doubt Solver & AAC Board',
                desc: 'Ask questions by text, image upload, or visual communication cards with Simple, Detailed, and Visual AI explanations.',
                icon: Sparkles,
                route: 'doubt' as const,
                bg: 'bg-[#E6F5EE] dark:bg-teal-950/60',
              },
              {
                title: 'Interactive Visual Learning',
                desc: 'Explore interactive Photosynthesis and Ratio visualizers or generate step-by-step diagrams for any CBSE topic.',
                icon: Eye,
                route: 'visual' as const,
                bg: 'bg-[#EAF3FF] dark:bg-sky-950/60',
              },
              {
                title: 'Accessible Assessments',
                desc: 'Practice image MCQs, matching exercises, fill-in-the-blanks, and step ordering with zero audio-only barriers.',
                icon: CheckCircle2,
                route: 'assessments' as const,
                bg: 'bg-[#E6F5EE] dark:bg-teal-950/60',
              },
            ].map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.title}
                  className="flex flex-col justify-between rounded-2xl border border-[#DCE5EF] dark:border-slate-800 bg-white dark:bg-slate-900 p-6"
                >
                  <div>
                    <div className={`inline-flex h-11 w-11 items-center justify-center rounded-xl ${card.bg} text-[#243447] dark:text-white`}>
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <h3 className="mt-4 text-lg font-bold text-[#243447] dark:text-white">
                      {card.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                      {card.desc}
                    </p>
                  </div>
                  <button
                    type="button"
                    data-link-style="true"
                    onClick={() => navigate(card.route)}
                    className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-[#0B63CE] dark:text-sky-400 hover:underline self-start"
                  >
                    <span>Try {card.title}</span>
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" className="border-t border-[#E3EAF2] dark:border-slate-800 bg-[#EAF3FF]/60 dark:bg-slate-900/70 py-14">
          <div className="mx-auto max-w-6xl px-6">
            <h2 className="text-2xl font-extrabold text-[#243447] dark:text-white sm:text-3xl">
              How It Works
            </h2>
            <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3">
              {[
                {
                  step: '01. Set Your Reading & Visual Comfort',
                  body: 'Turn on Dyslexia Friendly mode, adjust spacing, pick a calm paper tint, or open Accessibility Options in one click.',
                },
                {
                  step: '02. Learn With Visual & Captioned Lessons',
                  body: 'Study CBSE chapters through structured text, synchronized captions, interactive simulations, and sign language terminology.',
                },
                {
                  step: '03. Ask Doubts & Practice Without Voice Barriers',
                  body: 'Use text, images, or communication cards to ask Gemini AI for clear explanations and track mastery in My Progress.',
                },
              ].map((item) => (
                <div
                  key={item.step}
                  className="rounded-2xl border border-[#CFE0F5] dark:border-slate-700 bg-white dark:bg-slate-900 p-6"
                >
                  <h3 className="text-base font-bold text-[#0B63CE] dark:text-sky-400">{item.step}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#4A5E75] dark:text-slate-300">
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#E3EAF2] dark:border-slate-800 bg-white dark:bg-slate-900 py-8">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 text-sm text-[#526275] dark:text-slate-400">
          <div>
            <span className="font-bold text-[#243447] dark:text-white">IndraSetu AI</span> · Har ishare se seekhna, har kisi ke liye.
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              data-link-style="true"
              onClick={() => navigate('dashboard')}
              className="font-semibold text-[#0B63CE] dark:text-sky-400 hover:underline"
            >
              Student Portal
            </button>
            <button
              type="button"
              data-link-style="true"
              onClick={openDrawer}
              className="font-semibold text-[#243447] dark:text-slate-200 hover:underline"
            >
              Accessibility Options
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
