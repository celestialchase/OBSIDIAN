import React, { useState } from 'react';
import { Award, BookOpen, CheckCircle2, Trash2, TrendingUp } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { computeProgressStats } from '../../utils/assessmentLogic';

export const ProgressPage: React.FC = () => {
  const {
    courses,
    lessons,
    quizAttempts,
    notes,
    deleteNote,
    openLesson,
    navigate,
    syncLoading,
    firestoreError,
  } = useApp();
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const stats = computeProgressStats(lessons, courses, quizAttempts);

  const areasToImprove = courses
    .filter((c) => c.progressPercent < 70)
    .map((c) => `${c.subject}: ${c.currentChapter}`);

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">My Learning Progress</h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Track completed chapters, topic-wise mastery, saved study notes, and recommended practice areas.
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate('assessments')}
          className="rounded-xl bg-[#0B63CE] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6]"
        >
          Take Practice Quiz
        </button>
      </section>

      {syncLoading && (
        <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-4 py-2.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
          Syncing your learning progress and notes from Cloud Firestore...
        </div>
      )}

      {(firestoreError || deleteError) && (
        <div
          role="alert"
          className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
        >
          {deleteError || firestoreError}
        </div>
      )}

      {/* Top 4 Summary Figures */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5">
          <div className="flex items-center justify-between text-xs font-bold text-[#526275] dark:text-slate-400">
            <span>Overall Progress</span>
            <TrendingUp className="h-4 w-4 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-[#243447] dark:text-slate-100 font-tabular">
            {stats.overallPercent}%
          </div>
        </div>

        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5">
          <div className="flex items-center justify-between text-xs font-bold text-[#526275] dark:text-slate-400">
            <span>Lessons Completed</span>
            <CheckCircle2 className="h-4 w-4 text-[#16A34A]" aria-hidden="true" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-[#243447] dark:text-slate-100 font-tabular">
            {stats.completedLessons}
          </div>
        </div>

        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5">
          <div className="flex items-center justify-between text-xs font-bold text-[#526275] dark:text-slate-400">
            <span>Average Quiz Score</span>
            <Award className="h-4 w-4 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-[#243447] dark:text-slate-100 font-tabular">
            {stats.averageQuizPercent}%
          </div>
        </div>

        <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5">
          <div className="flex items-center justify-between text-xs font-bold text-[#526275] dark:text-slate-400">
            <span>Saved Notes</span>
            <BookOpen className="h-4 w-4 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-[#243447] dark:text-slate-100 font-tabular">
            {notes.length}
          </div>
        </div>
      </section>

      {/* Subject Performance + Quiz History */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-6 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4">
          <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Subject-Wise Completion</h2>
          <div className="space-y-3.5">
            {courses.map((c) => (
              <div key={c.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm font-semibold text-[#243447] dark:text-slate-100">
                  <span>{c.subject}</span>
                  <span className="font-tabular text-xs font-bold text-[#3C8D91] dark:text-teal-400">
                    {c.lessonsCompleted}/{c.totalLessons} ({c.progressPercent}%)
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-[#E5EDF5] dark:bg-slate-700">
                  <div
                    className="h-full rounded-full bg-[#3C8D91]"
                    style={{ width: `${c.progressPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 p-4">
            <h3 className="text-xs font-bold text-[#0B63CE] dark:text-sky-400">Areas to Focus Next</h3>
            <ul className="mt-1.5 list-disc pl-4 space-y-1 text-xs text-[#243447] dark:text-slate-200">
              {areasToImprove.length > 0 ? (
                areasToImprove.map((area) => <li key={area}>{area}</li>)
              ) : (
                <li>Great consistency! All subjects are above 70% completion.</li>
              )}
            </ul>
          </div>
        </div>

        <div className="lg:col-span-6 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4">
          <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Recent Assessment History</h2>
          <div className="space-y-2.5">
            {quizAttempts.length === 0 ? (
              <p className="text-sm text-[#526275] dark:text-slate-400">
                No assessments recorded yet. Take a practice quiz to track your topic-wise scores.
              </p>
            ) : (
              quizAttempts.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
                >
                  <div>
                    <div className="text-xs font-bold text-[#3C8D91] dark:text-teal-400">{att.subject}</div>
                    <div className="text-sm font-bold text-[#243447] dark:text-slate-100">{att.topic}</div>
                    <div className="text-xs text-[#526275] dark:text-slate-400">{att.completedAt}</div>
                  </div>
                  <div className="text-right font-tabular">
                    <div className="text-base font-extrabold text-[#0B63CE] dark:text-sky-400">{att.percent}%</div>
                    <div className="text-xs text-[#526275] dark:text-slate-400">
                      {att.score}/{att.total}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Saved Lessons & Notes */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-6 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-3">
          <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Lesson History</h2>
          {lessons.map((l) => (
            <div
              key={l.id}
              className="flex items-center justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
            >
              <div>
                <div className="text-xs font-bold text-[#3C8D91] dark:text-teal-400">
                  {l.subject} · {l.status}
                </div>
                <div className="text-sm font-bold text-[#243447] dark:text-slate-100">{l.title}</div>
              </div>
              <button
                type="button"
                onClick={() => openLesson(l.id)}
                className="rounded-lg border border-[#DCE5EF] dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-bold text-[#0B63CE] dark:text-sky-400 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 shrink-0"
              >
                Open
              </button>
            </div>
          ))}
        </div>

        <div className="lg:col-span-6 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-3">
          <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Saved Study Notes</h2>
          {notes.length === 0 ? (
            <p className="text-sm text-[#526275] dark:text-slate-400">
              No saved notes yet. Save passages from My Learning, Video Lessons, or AI Doubt Solver.
            </p>
          ) : (
            notes.map((n) => (
              <div
                key={n.id}
                className="flex items-start justify-between gap-3 rounded-xl border border-[#E3EAF2] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 p-3.5"
              >
                <div>
                  <div className="text-xs font-bold text-[#3C8D91] dark:text-teal-400">
                    {n.subject} · {n.createdAt}
                  </div>
                  <div className="text-sm font-bold text-[#243447] dark:text-slate-100">{n.title}</div>
                  <p className="mt-1 text-xs leading-relaxed text-[#4A5E75] dark:text-slate-300">{n.content}</p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    setDeleteError(null);
                    try {
                      await deleteNote(n.id);
                    } catch (err) {
                      setDeleteError(err instanceof Error ? err.message : 'Unable to delete note.');
                    }
                  }}
                  aria-label={`Delete note ${n.title}`}
                  className="rounded-lg p-1.5 text-[#526275] dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-[#C53030] shrink-0"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
};
