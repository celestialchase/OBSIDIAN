import React, { useMemo, useState } from 'react';
import { ExternalLink, Hand, Plus, Search, Video, X } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { ASSET_PATHS } from '../../data/curriculum';
import { ISLCategory, ISLEntry } from '../../types';
import { isDirectVideoFileUrl, validateExternalVideoUrl } from '../../utils/mediaValidation';

const CATEGORIES: Array<ISLCategory | 'All'> = [
  'All',
  'Common vocabulary',
  'Classroom communication',
  'Science terminology',
  'Mathematics terminology',
  'Educational expressions',
  'Frequently used phrases',
];

export const ISLLibraryPage: React.FC = () => {
  const { islEntries, addISLEntry, firebaseUid, user, openAuthModal } = useApp();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<ISLCategory | 'All'>('All');
  const [selectedEntry, setSelectedEntry] = useState<ISLEntry | null>(islEntries[0] || null);
  const [uploadOpen, setUploadOpen] = useState(false);

  const [newTerm, setNewTerm] = useState('');
  const [newCategory, setNewCategory] = useState<ISLCategory>('Classroom communication');
  const [newMeaning, setNewMeaning] = useState('');
  const [newGuide, setNewGuide] = useState('');
  const [newVideoUrlInput, setNewVideoUrlInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return islEntries.filter((entry) => {
      const matchesCat = category === 'All' || entry.category === category;
      const q = search.trim().toLowerCase();
      const matchesQuery =
        !q ||
        entry.term.toLowerCase().includes(q) ||
        entry.meaning.toLowerCase().includes(q) ||
        entry.category.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  }, [islEntries, category, search]);

  const handleCreateEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTerm.trim() || !newMeaning.trim()) {
      setFormError('Please provide both the ISL term and its meaning.');
      return;
    }

    const urlCheck = validateExternalVideoUrl(newVideoUrlInput);
    if (!urlCheck.ok) {
      setFormError(urlCheck.error);
      return;
    }

    setFormError(null);
    setSaving(true);
    try {
      const persistedVideoUrl = urlCheck.normalizedUrl;
      const isEducator = Boolean(firebaseUid && user.role === 'teacher');
      const isVerified = Boolean(persistedVideoUrl && isEducator);
      const verificationLabel = persistedVideoUrl
        ? firebaseUid
          ? isEducator
            ? 'Verified External ISL Video'
            : 'Student Submission (Pending Verification)'
          : 'Demo External Video (Sign In to Publish)'
        : 'Educator Text & Handshape Reference';

      const created: ISLEntry = {
        id: `isl-custom-${Date.now()}`,
        createdByUid: firebaseUid || undefined,
        term: newTerm.trim(),
        category: newCategory,
        meaning: newMeaning.trim(),
        handshapeGuide:
          newGuide.trim() || 'Human ISL video demonstration reference.',
        usageExample: `Classroom usage: "${newTerm.trim()}"`,
        isVerifiedClip: isVerified,
        verificationLabel,
        customVideoUrl: persistedVideoUrl,
      };

      await addISLEntry(created);
      setSelectedEntry(created);
      setNewTerm('');
      setNewMeaning('');
      setNewGuide('');
      setNewVideoUrlInput('');
      setUploadOpen(false);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Unable to save ISL entry right now. Please try again.'
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">
            Indian Sign Language (ISL) Library
          </h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Searchable classroom and subject terminology. Sample reference cards are clearly labeled alongside verified external ISL video links.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setUploadOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#094FA6] whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add Verified ISL Clip</span>
        </button>
      </section>

      {/* Search & Category Filters */}
      <section className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4 space-y-4">
        <div className="relative max-w-md">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#64748B] dark:text-slate-400"
            aria-hidden="true"
          />
          <input
            type="search"
            aria-label="Search ISL signs and phrases"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search ISL terms (e.g., Photosynthesis, Ratio, Repeat)"
            className="w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 py-2 pl-10 pr-4 text-sm text-[#243447] dark:text-slate-100"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategory(cat)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                category === cat
                  ? 'bg-[#0B63CE] text-white'
                  : 'bg-[#EAF3FF] dark:bg-slate-800 text-[#243447] dark:text-slate-200 hover:bg-[#DCEBFA] dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Grid + Detail Preview */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          {filtered.length === 0 ? (
            <div className="sm:col-span-2 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-8 text-center">
              <p className="text-sm font-semibold text-[#243447] dark:text-slate-100">
                No ISL entries matched "{search}".
              </p>
              <button
                type="button"
                data-link-style="true"
                onClick={() => {
                  setSearch('');
                  setCategory('All');
                }}
                className="mt-3 text-xs font-bold text-[#0B63CE] dark:text-sky-400 hover:underline"
              >
                Clear filters
              </button>
            </div>
          ) : (
            filtered.map((entry) => {
              const active = selectedEntry?.id === entry.id;
              return (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => setSelectedEntry(entry)}
                  className={`flex flex-col justify-between rounded-2xl border p-4 text-left transition-colors ${
                    active
                      ? 'border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800'
                      : 'border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-[#3C8D91]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-[11px] font-bold text-[#3C8D91] dark:text-teal-400">
                      <span>{entry.category}</span>
                      <Hand className="h-4 w-4 shrink-0" aria-hidden="true" />
                    </div>
                    <h2 className="mt-1.5 text-base font-bold text-[#243447] dark:text-slate-100">{entry.term}</h2>
                    <p className="mt-1 text-xs leading-relaxed text-[#4A5E75] dark:text-slate-300 line-clamp-2">
                      {entry.meaning}
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-[#EBF0F5] dark:border-slate-800 text-[11px] font-semibold text-[#526275] dark:text-slate-400">
                    {entry.verificationLabel}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {selectedEntry && (
          <div className="lg:col-span-5 rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4 self-start">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#3C8D91] dark:text-teal-400">{selectedEntry.category}</span>
              <span className="text-xs font-semibold text-[#526275] dark:text-slate-400">
                {selectedEntry.isVerifiedClip ? 'Verified Video' : 'Sample Reference'}
              </span>
            </div>

            <h2 className="text-xl font-extrabold text-[#243447] dark:text-slate-100">{selectedEntry.term}</h2>

            <div className="overflow-hidden rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800">
              {selectedEntry.customVideoUrl ? (
                isDirectVideoFileUrl(selectedEntry.customVideoUrl) ? (
                  <video
                    src={selectedEntry.customVideoUrl}
                    controls
                    className="w-full max-h-[240px] bg-black"
                  />
                ) : (
                  <div className="p-4 space-y-3 bg-[#FAF9F6] dark:bg-slate-800">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#0B63CE] dark:text-sky-400">
                      <Video className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span>External Verified ISL Video Resource</span>
                    </div>
                    <p className="text-xs text-[#4A5E75] dark:text-slate-300 break-all">
                      {selectedEntry.customVideoUrl}
                    </p>
                    <a
                      href={selectedEntry.customVideoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-xl bg-[#0B63CE] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#094FA6]"
                    >
                      <span>Open External ISL Video</span>
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  </div>
                )
              ) : (
                <div>
                  <div data-image-container="true" className="relative overflow-hidden">
                    <img
                      src={ASSET_PATHS.islGuide}
                      alt={`Sample ISL reference card for ${selectedEntry.term}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-52 object-cover object-top"
                    />
                  </div>
                  <div className="bg-[#243447]/90 px-3 py-2 text-[11px] font-semibold text-white">
                    Sample demonstration graphic — add a verified external ISL video link for full motion.
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3 text-sm">
              <div>
                <div className="text-xs font-bold text-[#526275] dark:text-slate-400">Meaning</div>
                <p className="mt-0.5 text-[#243447] dark:text-slate-200 leading-relaxed">{selectedEntry.meaning}</p>
              </div>
              <div className="rounded-xl bg-[#FAF9F6] dark:bg-slate-800 border border-[#E3EAF2] dark:border-slate-700 p-3.5">
                <div className="text-xs font-bold text-[#0B63CE] dark:text-sky-400">Handshape & Movement Note</div>
                <p className="mt-1 text-xs leading-relaxed text-[#243447] dark:text-slate-200">
                  {selectedEntry.handshapeGuide}
                </p>
              </div>
              <div>
                <div className="text-xs font-bold text-[#526275] dark:text-slate-400">Classroom Example</div>
                <p className="mt-0.5 text-xs text-[#4A5E75] dark:text-slate-300">{selectedEntry.usageExample}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Upload Verified ISL Video Modal */}
      {uploadOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#243447]/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="isl-upload-title"
        >
          <div className="w-full max-w-lg rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-6 shadow-xl text-[#243447] dark:text-slate-100">
            <div className="flex items-center justify-between">
              <h2 id="isl-upload-title" className="text-lg font-bold text-[#243447] dark:text-slate-100">
                {user.role === 'teacher' ? 'Add Verified ISL Video Clip' : 'Submit ISL Reference Clip'}
              </h2>
              <button
                type="button"
                onClick={() => setUploadOpen(false)}
                aria-label="Close upload modal"
                className="rounded-lg p-1.5 text-[#526275] dark:text-slate-400 hover:bg-[#EAF3FF] dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {!firebaseUid && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-3 py-2 text-xs text-[#243447] dark:text-slate-200">
                <span>Sign in to save ISL entries to the shared cloud catalog.</span>
                <button
                  type="button"
                  onClick={() => {
                    setUploadOpen(false);
                    openAuthModal('login');
                  }}
                  className="rounded-lg bg-[#0B63CE] px-2.5 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
                >
                  Sign In
                </button>
              </div>
            )}

            <form onSubmit={handleCreateEntry} className="mt-4 space-y-4">
              <div>
                <label htmlFor="isl-term" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                  Term or Phrase
                </label>
                <input
                  id="isl-term"
                  type="text"
                  value={newTerm}
                  onChange={(e) => setNewTerm(e.target.value)}
                  placeholder="e.g., Gravity"
                  className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-[#243447] dark:text-slate-100"
                />
              </div>

              <div>
                <label htmlFor="isl-cat" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                  Category
                </label>
                <select
                  id="isl-cat"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as ISLCategory)}
                  className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-[#243447] dark:text-slate-100"
                >
                  {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="isl-meaning" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                  Clear Meaning
                </label>
                <textarea
                  id="isl-meaning"
                  rows={2}
                  value={newMeaning}
                  onChange={(e) => setNewMeaning(e.target.value)}
                  placeholder="Plain-language explanation for students"
                  className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-[#243447] dark:text-slate-100"
                />
              </div>

              <div>
                <label htmlFor="isl-guide" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                  Handshape Description (Optional)
                </label>
                <input
                  id="isl-guide"
                  type="text"
                  value={newGuide}
                  onChange={(e) => setNewGuide(e.target.value)}
                  placeholder="Describe hand orientation or movement"
                  className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-[#243447] dark:text-slate-100"
                />
              </div>

              <div>
                <label htmlFor="isl-video-url" className="block text-xs font-bold text-[#243447] dark:text-slate-200">
                  Verified External Video URL (Optional)
                </label>
                <input
                  id="isl-video-url"
                  type="url"
                  value={newVideoUrlInput}
                  onChange={(e) => {
                    setNewVideoUrlInput(e.target.value);
                    if (formError) setFormError(null);
                  }}
                  placeholder="https://... (verified NCERT/Diksha portal or direct .mp4/.webm URL)"
                  className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-[#243447] dark:text-slate-100"
                />
                <p className="mt-1 text-[11px] text-[#526275] dark:text-slate-400">
                  Only external HTTPS URLs are accepted. Direct .mp4/.webm/.ogg links play inline; educational portal links open in a new tab.
                </p>
              </div>

              {formError && (
                <p role="alert" className="text-xs font-medium text-[#C53030] dark:text-red-400">
                  {formError}
                </p>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setUploadOpen(false)}
                  className="rounded-xl border border-[#D4DFEC] dark:border-slate-700 px-4 py-2 text-xs font-bold text-[#243447] dark:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-[#0B63CE] px-4 py-2 text-xs font-bold text-white hover:bg-[#094FA6] disabled:opacity-60"
                >
                  {saving ? 'Saving...' : 'Add to ISL Library'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
