import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BookmarkPlus,
  Captions,
  Download,
  Hand,
  Maximize2,
  MessageSquareText,
  Pause,
  Play,
  RotateCcw,
  Upload,
} from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { ASSET_PATHS, INITIAL_VIDEO_LESSONS } from '../../data/curriculum';
import { validateSpeechAudioFile } from '../../utils/mediaValidation';

export const VideoLessonsPage: React.FC = () => {
  const { addNote, navigate, getAuthHeaders, openAuthModal, videoProgress, saveVideoProgress } = useApp();
  const { settings, updateSettings } = useAccessibility();

  const [selectedVideoId, setSelectedVideoId] = useState(INITIAL_VIDEO_LESSONS[0].id);
  const [currentSec, setCurrentSec] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [islVisible, setIslVisible] = useState(settings.islPanelDefaultVisible);
  const [islPosition, setIslPosition] = useState<'side' | 'overlay-right' | 'overlay-left'>('side');
  const [islSize, setIslSize] = useState<'compact' | 'standard' | 'large'>('standard');
  const [noteSaved, setNoteSaved] = useState(false);
  const [savingNote, setSavingNote] = useState(false);
  const [noteError, setNoteError] = useState<string | null>(null);
  const [transcribing, setTranscribing] = useState(false);
  const [customTranscript, setCustomTranscript] = useState<string | null>(null);
  const [transcribeError, setTranscribeError] = useState<string | null>(null);
  const [transcribeRequiresAuth, setTranscribeRequiresAuth] = useState(false);
  const [lastAudioFile, setLastAudioFile] = useState<File | null>(null);

  const playerWrapperRef = useRef<HTMLDivElement | null>(null);
  const lastSavedSecRef = useRef<number>(0);

  const video = useMemo(
    () => INITIAL_VIDEO_LESSONS.find((v) => v.id === selectedVideoId) || INITIAL_VIDEO_LESSONS[0],
    [selectedVideoId]
  );

  // Restore persisted timestamp when switching videos or loading from Firestore
  useEffect(() => {
    const saved = videoProgress[selectedVideoId];
    if (saved && !isPlaying && currentSec === 0 && saved.currentSec > 0) {
      const restored = saved.currentSec >= video.durationSec ? 0 : saved.currentSec;
      setCurrentSec(restored);
      lastSavedSecRef.current = restored;
    }
  }, [selectedVideoId, videoProgress, video.durationSec, isPlaying, currentSec]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = window.setInterval(() => {
      setCurrentSec((prev) => {
        const next = prev + 0.5 * playbackSpeed;
        if (next >= video.durationSec) {
          setIsPlaying(false);
          lastSavedSecRef.current = video.durationSec;
          saveVideoProgress(video.id, video.durationSec, video.durationSec);
          return video.durationSec;
        }
        if (Math.abs(next - lastSavedSecRef.current) >= 5) {
          lastSavedSecRef.current = next;
          saveVideoProgress(video.id, next, video.durationSec);
        }
        return next;
      });
    }, 500);
    return () => window.clearInterval(interval);
  }, [isPlaying, playbackSpeed, video.id, video.durationSec, saveVideoProgress]);

  const activeCue = useMemo(() => {
    return (
      video.cues.find((c) => currentSec >= c.startSec && currentSec < c.endSec) ||
      video.cues[video.cues.length - 1]
    );
  }, [video, currentSec]);

  const activeVisualStep = useMemo(() => {
    let chosen = video.visualSteps[0];
    for (const step of video.visualSteps) {
      if (currentSec >= step.atSec) chosen = step;
    }
    return chosen;
  }, [video, currentSec]);

  const formatTime = (sec: number) => {
    const rounded = Math.floor(sec);
    const m = Math.floor(rounded / 60);
    const s = rounded % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const highlightKeywords = (text: string, keywords: string[]) => {
    if (!keywords.length) return text;
    const regex = new RegExp(`(${keywords.join('|')})`, 'gi');
    const parts = text.split(regex);
    return parts.map((part, idx) => {
      const matched = keywords.some((kw) => kw.toLowerCase() === part.toLowerCase());
      return matched ? (
        <mark
          key={idx}
          className="rounded bg-[#FDE047] px-1 font-bold text-[#090D14]"
        >
          {part}
        </mark>
      ) : (
        <span key={idx}>{part}</span>
      );
    });
  };

  const handleDownloadTranscript = () => {
    const lines = [
      `IndraSetu AI — Accessible Transcript`,
      `Lesson: ${video.title} (${video.subject} · ${video.grade})`,
      `Key Terms: ${video.keywords.join(', ')}`,
      '',
      ...video.cues.map(
        (c) => `[${formatTime(c.startSec)} - ${formatTime(c.endSec)}] ${c.text}\nISL Gloss: ${c.islGloss}`
      ),
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${video.id}-transcript.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFullscreen = () => {
    const el = playerWrapperRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else if (el.requestFullscreen) {
      el.requestFullscreen().catch(() => {});
    }
  };

  const runTranscribeFile = async (file: File) => {
    const check = validateSpeechAudioFile({
      type: file.type,
      size: file.size,
      name: file.name,
    });
    if (!check.ok) {
      setLastAudioFile(null);
      setTranscribeRequiresAuth(false);
      setTranscribeError(check.error);
      return;
    }

    setLastAudioFile(file);
    setTranscribing(true);
    setTranscribeError(null);
    setTranscribeRequiresAuth(false);

    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Could not read audio file'));
        reader.readAsDataURL(file);
      });
      const headers = await getAuthHeaders();
      const res = await fetch('/api/speech/transcribe', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          audioBase64: base64,
          mimeType: check.normalizedMime,
          lessonTitle: video.title,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          setTranscribeRequiresAuth(true);
        }
        throw new Error(data?.error || 'Live audio transcription failed.');
      }
      setCustomTranscript(data.transcript);
    } catch (err: unknown) {
      setTranscribeError(
        err instanceof Error
          ? err.message
          : 'Live audio transcription could not be completed. Please try again.'
      );
    } finally {
      setTranscribing(false);
    }
  };

  const handleAudioTranscribeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    await runTranscribeFile(file);
  };

  const captionSizeClass =
    settings.captionSize === 'lg'
      ? 'text-lg sm:text-xl'
      : settings.captionSize === 'sm'
      ? 'text-xs sm:text-sm'
      : 'text-sm sm:text-base';

  const captionStyleClass =
    settings.captionBackground === 'cream'
      ? 'bg-[#FAF9F6] text-[#243447] border border-[#DCE5EF]'
      : settings.captionBackground === 'high-contrast'
      ? 'bg-[#090D14] text-[#FDE047] border-2 border-[#FDE047]'
      : 'bg-[#172230]/95 text-white';

  const islWidthClass =
    islSize === 'compact' ? 'w-56' : islSize === 'large' ? 'w-80' : 'w-68';

  const islBox = islVisible && (
    <div
      className={`rounded-2xl border border-[#B6E0DA] dark:border-teal-800 bg-[#E6F5EE] dark:bg-slate-900 p-3.5 text-[#243447] dark:text-slate-100 shadow-sm ${
        islPosition === 'side' ? 'w-full' : `${islWidthClass} max-w-[90%]`
      }`}
    >
      <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#C6E8DA] dark:border-slate-700">
        <div className="flex items-center gap-1.5 text-xs font-bold text-[#1D3538] dark:text-teal-300">
          <Hand className="h-4 w-4 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
          <span>ISL Interpreter (Sample Guide)</span>
        </div>
        <span className="text-[10px] font-bold text-[#3C8D91] dark:text-teal-400">
          {formatTime(currentSec)}
        </span>
      </div>

      <div
        data-image-container="true"
        className="mt-2.5 overflow-hidden rounded-xl border border-[#C6E8DA] dark:border-slate-700 bg-white dark:bg-slate-800"
      >
        <img
          src={ASSET_PATHS.islGuide}
          alt="Indian Sign Language educator reference demonstration"
          referrerPolicy="no-referrer"
          className="h-36 w-full object-cover object-top"
        />
      </div>

      <div className="mt-2.5 space-y-1.5">
        <div className="text-[11px] font-bold text-[#3C8D91] dark:text-teal-400">SYNCHRONIZED GLOSS</div>
        <div className="rounded-lg bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular">
          {activeCue.islGloss}
        </div>
        <p className="text-xs leading-relaxed text-[#354B63] dark:text-slate-300">
          <strong>Hand Cue:</strong> {activeCue.islHandCue}
        </p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <section className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#243447] dark:text-slate-100">
            Accessible Video Learning & Captions
          </h1>
          <p className="text-sm text-[#4A5E75] dark:text-slate-300">
            Synchronized captions, highlighted keywords, downloadable transcripts, and a movable ISL reference panel.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {INITIAL_VIDEO_LESSONS.map((v) => {
            const saved = videoProgress[v.id];
            const resumeSec = saved && saved.currentSec > 0 ? saved.currentSec : 0;
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => {
                  saveVideoProgress(video.id, currentSec, video.durationSec);
                  setSelectedVideoId(v.id);
                  setCurrentSec(resumeSec >= v.durationSec ? 0 : resumeSec);
                  lastSavedSecRef.current = resumeSec;
                  setIsPlaying(false);
                }}
                className={`rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                  v.id === video.id
                    ? 'bg-[#0B63CE] text-white'
                    : 'border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800'
                }`}
              >
                {v.title}
              </button>
            );
          })}
        </div>
      </section>

      {/* Player + Side/Overlay ISL Panel */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div
          ref={playerWrapperRef}
          className={
            islVisible && islPosition === 'side' ? 'lg:col-span-8 space-y-4' : 'lg:col-span-12 space-y-4'
          }
        >
          {/* Main Visual Stage */}
          <div className="relative overflow-hidden rounded-2xl border border-[#DCE5EF] bg-[#162231]">
            <img
              src={video.thumbnailSrc}
              alt={video.title}
              referrerPolicy="no-referrer"
              className="w-full h-[300px] sm:h-[380px] object-cover opacity-90"
            />

            {/* Synchronized Visual Callout Banner */}
            <div className="absolute left-4 top-4 max-w-md rounded-xl bg-[#162231]/90 px-4 py-2.5 text-white border border-white/15">
              <div className="text-xs font-bold text-[#7CE0D3]">{activeVisualStep.heading}</div>
              <div className="mt-0.5 text-sm font-semibold">{activeVisualStep.caption}</div>
            </div>

            {/* Overlay ISL Box when repositioned inside player */}
            {islVisible && islPosition !== 'side' && (
              <div
                className={`hidden md:block absolute top-4 z-20 ${
                  islPosition === 'overlay-right' ? 'right-4' : 'left-4 top-24'
                }`}
              >
                {islBox}
              </div>
            )}

            {/* Synchronized Adjustable Caption Overlay */}
            {settings.captionsEnabled && (
              <div className="px-4 pb-4 pt-2 bg-gradient-to-t from-[#0D1520] via-[#0D1520]/85 to-transparent">
                <div
                  aria-live="polite"
                  className={`mx-auto max-w-3xl rounded-xl px-4 py-2.5 text-center font-semibold leading-relaxed ${captionSizeClass} ${captionStyleClass}`}
                >
                  {highlightKeywords(activeCue.text, video.keywords)}
                </div>
              </div>
            )}
          </div>

          {/* Video Timeline & Playback Controls */}
          <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4 space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular w-12">
                {formatTime(currentSec)}
              </span>
              <input
                type="range"
                aria-label="Video lesson progress"
                min={0}
                max={video.durationSec}
                step={1}
                value={currentSec}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setCurrentSec(val);
                  lastSavedSecRef.current = val;
                  saveVideoProgress(video.id, val, video.durationSec);
                }}
                className="flex-1 accent-[#0B63CE] cursor-pointer"
              />
              <span className="text-xs font-bold text-[#526275] dark:text-slate-400 font-tabular w-12 text-right">
                {formatTime(video.durationSec)}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (isPlaying) {
                      lastSavedSecRef.current = currentSec;
                      saveVideoProgress(video.id, currentSec, video.durationSec);
                    } else if (currentSec >= video.durationSec) {
                      setCurrentSec(0);
                    }
                    setIsPlaying((p) => !p);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#0B63CE] px-4 py-2 text-xs font-bold text-white hover:bg-[#094FA6]"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  <span>{isPlaying ? 'Pause' : 'Play Lesson'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const next = Math.max(0, currentSec - 5);
                    setCurrentSec(next);
                    lastSavedSecRef.current = next;
                    saveVideoProgress(video.id, next, video.durationSec);
                  }}
                  className="inline-flex items-center gap-1 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700"
                >
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>-5s</span>
                </button>

                <select
                  aria-label="Video playback speed"
                  value={playbackSpeed}
                  onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                  className="rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-2.5 py-2 text-xs font-bold text-[#243447] dark:text-slate-100 font-tabular"
                >
                  <option value={0.75}>0.75x</option>
                  <option value={1}>1.0x</option>
                  <option value={1.25}>1.25x</option>
                  <option value={1.5}>1.5x</option>
                </select>

                <button
                  type="button"
                  onClick={() => updateSettings({ captionsEnabled: !settings.captionsEnabled })}
                  className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold ${
                    settings.captionsEnabled
                      ? 'border-[#0B63CE] bg-[#EAF3FF] dark:bg-sky-950 text-[#0B63CE] dark:text-sky-300'
                      : 'border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 text-[#243447] dark:text-slate-100'
                  }`}
                >
                  <Captions className="h-4 w-4" aria-hidden="true" />
                  <span>Captions: {settings.captionsEnabled ? 'On' : 'Off'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIslVisible((v) => !v)}
                  className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold ${
                    islVisible
                      ? 'border-[#3C8D91] bg-[#E6F5EE] dark:bg-emerald-950 text-[#1D3538] dark:text-emerald-200'
                      : 'border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 text-[#243447] dark:text-slate-100'
                  }`}
                >
                  <Hand className="h-4 w-4" aria-hidden="true" />
                  <span>ISL Panel: {islVisible ? 'On' : 'Off'}</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={savingNote}
                  onClick={async () => {
                    setSavingNote(true);
                    setNoteError(null);
                    try {
                      await addNote({
                        title: `${video.title} (${formatTime(currentSec)})`,
                        subject: video.subject,
                        content: activeCue.text,
                      });
                      setNoteSaved(true);
                      window.setTimeout(() => setNoteSaved(false), 2500);
                    } catch (err) {
                      setNoteError(err instanceof Error ? err.message : 'Unable to save video note.');
                    } finally {
                      setSavingNote(false);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 disabled:opacity-60"
                >
                  <BookmarkPlus className="h-3.5 w-3.5 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
                  <span>{savingNote ? 'Saving...' : noteSaved ? 'Saved!' : 'Save Note'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => navigate('doubt')}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#3C8D91] px-3 py-2 text-xs font-bold text-white hover:bg-[#2E7175]"
                >
                  <MessageSquareText className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Ask AI</span>
                </button>

                <button
                  type="button"
                  onClick={handleFullscreen}
                  aria-label="Toggle fullscreen player"
                  className="rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Caption & ISL Panel Customization Bar */}
            <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-[#EBF0F5] dark:border-slate-800 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-[#526275] dark:text-slate-400">Subtitle Size:</span>
                {(['sm', 'md', 'lg'] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => updateSettings({ captionSize: sz })}
                    className={`rounded-lg px-2 py-1 font-bold uppercase ${
                      settings.captionSize === sz
                        ? 'bg-[#0B63CE] text-white'
                        : 'bg-[#FAF9F6] dark:bg-slate-800 text-[#243447] dark:text-slate-200'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-[#526275] dark:text-slate-400">Subtitle Theme:</span>
                {(
                  [
                    { id: 'dark', label: 'Dark' },
                    { id: 'cream', label: 'Cream' },
                    { id: 'high-contrast', label: 'Yellow/Black' },
                  ] as const
                ).map((bg) => (
                  <button
                    key={bg.id}
                    type="button"
                    onClick={() => updateSettings({ captionBackground: bg.id })}
                    className={`rounded-lg px-2.5 py-1 font-bold ${
                      settings.captionBackground === bg.id
                        ? 'bg-[#0B63CE] text-white'
                        : 'bg-[#FAF9F6] dark:bg-slate-800 text-[#243447] dark:text-slate-200'
                    }`}
                  >
                    {bg.label}
                  </button>
                ))}
              </div>

              {islVisible && (
                <>
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-[#526275] dark:text-slate-400">ISL Position:</span>
                    <select
                      aria-label="ISL interpreter panel position"
                      value={islPosition}
                      onChange={(e) => setIslPosition(e.target.value as typeof islPosition)}
                      className="rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-2 py-1 font-bold text-[#243447] dark:text-slate-100"
                    >
                      <option value="side">Side Dock</option>
                      <option value="overlay-right">Overlay Right</option>
                      <option value="overlay-left">Overlay Left</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-[#526275] dark:text-slate-400">ISL Size:</span>
                    <select
                      aria-label="ISL interpreter panel size"
                      value={islSize}
                      onChange={(e) => setIslSize(e.target.value as typeof islSize)}
                      className="rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-2 py-1 font-bold text-[#243447] dark:text-slate-100"
                    >
                      <option value="compact">Compact</option>
                      <option value="standard">Standard</option>
                      <option value="large">Large</option>
                    </select>
                  </div>
                </>
              )}
            </div>

            {noteError && (
              <div
                role="alert"
                className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-3.5 py-2 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
              >
                {noteError}
              </div>
            )}
          </div>
        </div>

        {/* Side Dock ISL Panel */}
        {islVisible && islPosition === 'side' && (
          <div className="lg:col-span-4 space-y-4">
            {islBox}
            <div className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
              <h2 className="text-sm font-bold text-[#243447] dark:text-slate-100">Important Technical Terms</h2>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {video.keywords.map((kw) => (
                  <button
                    key={kw}
                    type="button"
                    onClick={() => {
                      const found = video.cues.find((c) => c.keywords.includes(kw));
                      if (found) {
                        setCurrentSec(found.startSec);
                        lastSavedSecRef.current = found.startSec;
                        saveVideoProgress(video.id, found.startSec, video.durationSec);
                      }
                    }}
                    className="rounded-lg border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-2.5 py-1 text-xs font-bold text-[#0B63CE] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700"
                  >
                    {kw}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Transcript & Speech-to-Text Upload */}
      <section className="rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-[#243447] dark:text-slate-100">Synchronized Transcript</h2>
            <p className="text-xs text-[#526275] dark:text-slate-400">
              Click any timestamped line to jump directly in the lesson, or upload an audio clip (MP3, WAV, WebM, OGG, M4A, AAC; max 8 MB) for temporary AI captioning without permanent storage.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3.5 py-2 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700">
              <Upload className="h-3.5 w-3.5 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
              <span>{transcribing ? 'Transcribing...' : 'Transcribe Audio File'}</span>
              <input
                type="file"
                accept="audio/*"
                onChange={handleAudioTranscribeUpload}
                className="sr-only"
              />
            </label>
            <button
              type="button"
              onClick={handleDownloadTranscript}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#243447] dark:bg-[#0B63CE] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#192534] dark:hover:bg-[#094FA6]"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Download Transcript (.txt)</span>
            </button>
          </div>
        </div>

        {transcribeError && (
          <div
            role="alert"
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#F5C2C7] bg-[#FDF2F2] dark:bg-red-950/60 dark:border-red-800 px-4 py-2.5 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
          >
            <span>{transcribeError}</span>
            <div className="flex items-center gap-2 shrink-0">
              {transcribeRequiresAuth && (
                <button
                  type="button"
                  onClick={() => openAuthModal('login')}
                  className="rounded-lg bg-[#0B63CE] px-3 py-1 text-xs font-bold text-white hover:bg-[#094FA6]"
                >
                  Sign In
                </button>
              )}
              {lastAudioFile && (
                <button
                  type="button"
                  disabled={transcribing}
                  onClick={() => void runTranscribeFile(lastAudioFile)}
                  className="rounded-lg border border-[#F5C2C7] dark:border-red-700 bg-white dark:bg-slate-900 px-3 py-1 text-xs font-bold text-[#9B1C1C] dark:text-red-200 hover:bg-[#FDE8E8]"
                >
                  Retry
                </button>
              )}
            </div>
          </div>
        )}

        {customTranscript && (
          <div className="rounded-xl border border-[#B6E0DA] dark:border-emerald-800 bg-[#E6F5EE] dark:bg-emerald-950/50 p-4">
            <div className="text-xs font-bold text-[#1D3538] dark:text-emerald-300">
              Generated Audio Transcript (Live Gemini AI)
            </div>
            <p className="mt-1 text-sm leading-relaxed text-[#243447] dark:text-slate-100">{customTranscript}</p>
          </div>
        )}

        <div className="space-y-2">
          {video.cues.map((cue) => {
            const active = cue.id === activeCue.id;
            return (
              <button
                key={cue.id}
                type="button"
                onClick={() => {
                  setCurrentSec(cue.startSec);
                  lastSavedSecRef.current = cue.startSec;
                  saveVideoProgress(video.id, cue.startSec, video.durationSec);
                }}
                className={`w-full flex items-start gap-3 rounded-xl border p-3 text-left transition-colors ${
                  active
                    ? 'border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800'
                    : 'border-[#EBF0F5] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800/50 hover:bg-[#F3F7FC] dark:hover:bg-slate-800'
                }`}
              >
                <span className="font-tabular text-xs font-bold text-[#0B63CE] dark:text-sky-400 pt-0.5 shrink-0">
                  {formatTime(cue.startSec)}
                </span>
                <div className="flex-1 text-sm text-[#243447] dark:text-slate-100 leading-relaxed">
                  {highlightKeywords(cue.text, video.keywords)}
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
