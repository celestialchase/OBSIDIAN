import React, { useState } from 'react';
import { Accessibility, Bell, Calendar, LogIn, LogOut, Menu, Search, User } from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { CBSE_GRADES } from '../../data/curriculum';

export const TopHeader: React.FC = () => {
  const {
    user,
    openAuthModal,
    signOutAccount,
    selectedGrade,
    setSelectedGrade,
    searchQuery,
    setSearchQuery,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    navigate,
    setMobileDrawerOpen,
    lessons,
    openLesson,
  } = useApp();
  const { settings, updateSettings, openDrawer } = useAccessibility();

  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const matchingLessons =
    searchQuery.trim().length > 1
      ? lessons.filter(
          (l) =>
            l.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            l.subject.toLowerCase().includes(searchQuery.toLowerCase())
        )
      : [];

  if (settings.focusMode) {
    return (
      <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-[#DCE5EF] dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-4 py-3 backdrop-blur">
        <div className="text-sm font-bold text-[#243447] dark:text-slate-100">
          Focus Mode Active · Distractions Hidden
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openDrawer}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-[#0B63CE] dark:text-sky-300 whitespace-nowrap shrink-0"
          >
            <Accessibility className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Accessibility Options</span>
          </button>
          <button
            type="button"
            onClick={() => updateSettings({ readingRuler: !settings.readingRuler })}
            className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              settings.readingRuler
                ? 'border-[#0B63CE] bg-[#EAF3FF] text-[#0B63CE]'
                : 'border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 text-[#243447] dark:text-slate-100'
            }`}
          >
            Reading Ruler: {settings.readingRuler ? 'On' : 'Off'}
          </button>
          <button
            type="button"
            onClick={() => updateSettings({ focusMode: false })}
            className="rounded-lg bg-[#243447] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#192534] transition-colors whitespace-nowrap shrink-0"
          >
            Exit Focus Mode
          </button>
        </div>
      </header>
    );
  }

  return (
    <header className="sticky top-0 z-30 border-b border-[#E3EAF2] dark:border-slate-800 bg-[#FAF9F6]/95 dark:bg-slate-900/95 px-4 py-3 backdrop-blur lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-[220px]">
          <button
            type="button"
            onClick={() => setMobileDrawerOpen(true)}
            aria-label="Open navigation drawer"
            className="inline-flex lg:hidden items-center justify-center rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF]"
          >
            <Menu className="h-5 w-5" />
          </button>

          <div className="relative flex-1 max-w-md">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#64748B] dark:text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              aria-label="Search for lessons, topics or resources"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for lessons, topics or signs..."
              className="w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 py-2 pl-10 pr-4 text-sm text-[#243447] dark:text-slate-100 placeholder:text-[#64748B] dark:placeholder:text-slate-400 focus:border-[#0B63CE] focus:outline-none"
            />
            {matchingLessons.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-900 p-2 shadow-lg z-40">
                <div className="px-2 py-1 text-xs font-semibold text-[#526275] dark:text-slate-400">
                  Matching Lessons
                </div>
                {matchingLessons.slice(0, 4).map((lesson) => (
                  <button
                    key={lesson.id}
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      openLesson(lesson.id);
                    }}
                    className="w-full flex items-center justify-between rounded-lg px-2.5 py-2 text-left text-sm hover:bg-[#EAF3FF] dark:hover:bg-slate-800"
                  >
                    <span className="font-semibold text-[#243447] dark:text-slate-100 truncate">
                      {lesson.title}
                    </span>
                    <span className="ml-2 text-xs text-[#3C8D91] dark:text-teal-400 shrink-0">
                      {lesson.subject}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={openDrawer}
            aria-label="Open Accessibility Options panel"
            className="inline-flex items-center gap-2 rounded-xl border border-[#0B63CE] bg-[#EAF3FF] dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#0B49B8] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700 whitespace-nowrap shrink-0"
          >
            <Accessibility className="h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">Accessibility Options</span>
          </button>

          <div className="hidden md:flex items-center gap-2 rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-sm font-semibold text-[#243447] dark:text-slate-100">
            <Calendar className="h-4 w-4 text-[#0B63CE] dark:text-sky-400" aria-hidden="true" />
            <label htmlFor="cbse-grade-select" className="sr-only">
              Select CBSE Class
            </label>
            <select
              id="cbse-grade-select"
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="bg-transparent text-sm font-semibold text-[#243447] dark:text-slate-100 focus:outline-none cursor-pointer"
            >
              {CBSE_GRADES.map((g) => (
                <option key={g} value={g} className="dark:bg-slate-800">
                  {g} | CBSE
                </option>
              ))}
            </select>
          </div>

          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setNotifOpen((prev) => !prev);
                setProfileOpen(false);
              }}
              aria-label={`Visual Notifications (${unreadCount} unread)`}
              className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors"
            >
              <Bell className="h-4 w-4" aria-hidden="true" />
              {unreadCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#D9383A] px-1 text-[11px] font-bold text-white font-tabular">
                  {unreadCount}
                </span>
              )}
            </button>

            {notifOpen && (
              <div className="absolute right-0 mt-2 w-80 max-w-[90vw] rounded-2xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-900 p-3 shadow-lg z-40">
                <div className="flex items-center justify-between pb-2 border-b border-[#EBF0F5] dark:border-slate-700">
                  <span className="text-sm font-bold text-[#243447] dark:text-slate-100">
                    Visual Alerts
                  </span>
                  <button
                    type="button"
                    onClick={markAllNotificationsRead}
                    className="text-xs font-semibold text-[#0B63CE] dark:text-sky-400 hover:underline"
                  >
                    Mark all read
                  </button>
                </div>
                <div className="mt-2 space-y-2 max-h-72 overflow-y-auto">
                  {notifications.map((n) => (
                    <button
                      key={n.id}
                      type="button"
                      onClick={() => markNotificationRead(n.id)}
                      className={`w-full text-left rounded-xl p-2.5 text-xs border transition-colors ${
                        n.read
                          ? 'border-[#EDF2F7] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800'
                          : 'border-[#B9D6F8] dark:border-sky-800 bg-[#EAF3FF] dark:bg-sky-950/40 hover:bg-[#DCEBFA] dark:hover:bg-sky-950/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 font-bold text-[#243447] dark:text-slate-100">
                        <span>{n.title}</span>
                        <span className="text-[11px] font-medium text-[#526275] dark:text-slate-400 shrink-0">
                          {n.read ? n.timeLabel : `${n.timeLabel} · Unread`}
                        </span>
                      </div>
                      <p className="mt-1 text-[#4A5E75] dark:text-slate-300 leading-relaxed">
                        {n.detail}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setProfileOpen((prev) => !prev);
                setNotifOpen(false);
              }}
              className="flex items-center gap-2 rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-sm font-semibold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#DCEBFA] dark:bg-slate-700 text-[#0B63CE] dark:text-sky-300">
                <User className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="hidden md:inline max-w-[130px] truncate">{user.name}</span>
            </button>

            {profileOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-2xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-900 p-3 shadow-lg z-40">
                <div className="pb-2 border-b border-[#EBF0F5] dark:border-slate-700">
                  <div className="text-sm font-bold text-[#243447] dark:text-slate-100">
                    {user.name}
                  </div>
                  <div className="text-xs text-[#526275] dark:text-slate-400">
                    {user.role === 'teacher' ? 'Teacher Account' : 'Student Account'} ·{' '}
                    {user.isDemo ? 'Demo Mode' : 'Signed In'}
                  </div>
                </div>
                <div className="mt-2 space-y-1">
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      navigate('profile');
                    }}
                    className="w-full rounded-lg px-3 py-2 text-left text-sm font-medium text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-800"
                  >
                    Profile & Settings
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      openAuthModal('login');
                    }}
                    className="w-full flex items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-medium text-[#0B63CE] dark:text-sky-400 hover:bg-[#EAF3FF] dark:hover:bg-slate-800"
                  >
                    <LogIn className="h-4 w-4" aria-hidden="true" />
                    <span>Switch Account / Sign In</span>
                  </button>
                  {!user.isDemo && (
                    <button
                      type="button"
                      onClick={() => {
                        setProfileOpen(false);
                        void signOutAccount();
                      }}
                      className="w-full flex items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-medium text-[#C53030] dark:text-red-400 hover:bg-[#FDF2F2] dark:hover:bg-slate-800"
                    >
                      <LogOut className="h-4 w-4" aria-hidden="true" />
                      <span>Sign Out</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      navigate('landing');
                    }}
                    className="w-full rounded-lg px-3 py-2 text-left text-sm font-medium text-[#526275] dark:text-slate-400 hover:bg-[#FAF9F6] dark:hover:bg-slate-800"
                  >
                    View Landing Page
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
