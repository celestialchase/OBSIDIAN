import React from 'react';
import {
  Accessibility,
  BarChart3,
  BookOpen,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  Eye,
  Hand,
  Home,
  MessageSquareText,
  PlaySquare,
  Settings,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';
import { useApp } from '../../contexts/AppContext';
import { NavRoute } from '../../types';

interface NavItem {
  id: NavRoute;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'learning', label: 'My Learning', icon: BookOpen },
  { id: 'videos', label: 'Video Lessons', icon: PlaySquare },
  { id: 'isl', label: 'ISL Library', icon: Hand },
  { id: 'visual', label: 'Visual Learning', icon: Eye },
  { id: 'doubt', label: 'AI Doubt Solver', icon: MessageSquareText },
  { id: 'assessments', label: 'Assessments', icon: CheckSquare },
  { id: 'progress', label: 'My Progress', icon: BarChart3 },
  { id: 'accessibility', label: 'Accessibility Settings', icon: Accessibility },
  { id: 'profile', label: 'Profile & Settings', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const {
    route,
    navigate,
    sidebarCollapsed,
    setSidebarCollapsed,
    mobileDrawerOpen,
    setMobileDrawerOpen,
    selectedGrade,
  } = useApp();
  const { settings, toggleDyslexiaMode, openDrawer } = useAccessibility();

  if (settings.focusMode) {
    return null;
  }

  const sidebarContent = (isMobile: boolean) => {
    const compact = !isMobile && sidebarCollapsed;

    return (
      <div className="flex h-full flex-col justify-between bg-[#EAF3FF] dark:bg-slate-900 border-r border-[#D0E2F7] dark:border-slate-800 text-[#243447] dark:text-slate-100">
        <div>
          <div className="flex items-center justify-between gap-2 px-4 pt-5 pb-4 border-b border-[#D6E6F9] dark:border-slate-800">
            {!compact ? (
              <button
                type="button"
                onClick={() => navigate('landing')}
                className="text-left focus:outline-none group min-w-0"
              >
                <div className="text-lg font-extrabold tracking-tight text-[#243447] dark:text-white group-hover:text-[#0B63CE] dark:group-hover:text-sky-400">
                  IndraSetu AI
                </div>
                <div className="text-xs font-medium text-[#4A5E75] dark:text-slate-300 leading-snug">
                  Student Portal ({selectedGrade} · CBSE)
                </div>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => navigate('landing')}
                aria-label="IndraSetu AI Home"
                className="mx-auto flex h-9 w-9 items-center justify-center rounded-lg bg-[#0B63CE] text-sm font-bold text-white"
              >
                IS
              </button>
            )}

            {isMobile ? (
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                aria-label="Close navigation menu"
                className="rounded-lg p-2 text-[#243447] dark:text-slate-100 hover:bg-[#DCEBFA] dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                aria-label={compact ? 'Expand sidebar' : 'Collapse sidebar'}
                className="rounded-lg p-1.5 text-[#4A5E75] dark:text-slate-400 hover:bg-[#DCEBFA] dark:hover:bg-slate-800 hover:text-[#243447] dark:hover:text-white transition-colors"
              >
                {compact ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
              </button>
            )}
          </div>

          <nav aria-label="Main Navigation" className="px-3 py-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = route === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigate(item.id)}
                  aria-current={active ? 'page' : undefined}
                  title={compact ? item.label : undefined}
                  className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold ${
                    active
                      ? 'bg-[#0B63CE] text-white shadow-sm'
                      : 'text-[#243447] dark:text-slate-100 hover:bg-[#DCEBFA] dark:hover:bg-slate-800'
                  } ${compact ? 'justify-center px-2' : ''}`}
                >
                  <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {!compact && <span className="text-left leading-snug">{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-3 space-y-2.5 border-t border-[#D6E6F9] dark:border-slate-800">
          {!compact && (
            <button
              type="button"
              onClick={openDrawer}
              className="w-full flex items-center justify-center gap-2 rounded-xl border border-[#0B63CE] bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-[#0B49B8] dark:text-sky-300 hover:bg-[#DCEBFA] dark:hover:bg-slate-700"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Quick Accessibility Panel</span>
            </button>
          )}

          <div
            className={`rounded-xl border ${
              settings.dyslexiaMode
                ? 'bg-[#CFECE8] dark:bg-teal-950/80 border-[#3C8D91]'
                : 'bg-[#DDF3EF] dark:bg-slate-800 border-[#B6E0DA] dark:border-slate-700'
            } ${compact ? 'p-2 flex flex-col items-center' : 'p-3.5'}`}
          >
            <div className={`flex items-center ${compact ? 'flex-col gap-2' : 'justify-between gap-2'}`}>
              {!compact && (
                <div>
                  <div className="text-sm font-bold text-[#1D3538] dark:text-teal-200">
                    Dyslexia Mode
                  </div>
                  <div className="text-xs text-[#2E5558] dark:text-slate-300">
                    Reading support for easier learning
                  </div>
                </div>
              )}
              <button
                type="button"
                role="switch"
                aria-checked={settings.dyslexiaMode}
                aria-label="Toggle Dyslexia Mode"
                onClick={toggleDyslexiaMode}
                className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full transition-colors ${
                  settings.dyslexiaMode ? 'bg-[#3C8D91]' : 'bg-[#94A8B8] dark:bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${
                    settings.dyslexiaMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            {compact && (
              <span className="mt-1 text-[10px] font-bold text-[#1D3538] dark:text-teal-200">
                {settings.dyslexiaMode ? 'ON' : 'OFF'}
              </span>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <aside
        className={`hidden lg:block shrink-0 transition-all duration-200 ${
          sidebarCollapsed ? 'w-[78px]' : 'w-[264px]'
        }`}
      >
        <div className="sticky top-0 h-screen overflow-y-auto">{sidebarContent(false)}</div>
      </aside>

      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#243447]/45"
            onClick={() => setMobileDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-[280px] max-w-[85vw] h-full overflow-y-auto shadow-xl">
            {sidebarContent(true)}
          </aside>
        </div>
      )}
    </>
  );
};
