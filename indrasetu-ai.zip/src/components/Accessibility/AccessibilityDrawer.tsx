import React, { useEffect } from 'react';
import {
  Accessibility,
  Check,
  Contrast,
  ImageOff,
  Link2,
  Moon,
  MousePointerClick,
  MoveVertical,
  RotateCcw,
  Volume2,
  X,
} from 'lucide-react';
import { useAccessibility } from '../../contexts/AccessibilityContext';

export const AccessibilityDrawer: React.FC = () => {
  const {
    settings,
    drawerOpen,
    closeDrawer,
    lastSavedAt,
    prefsLoading,
    prefsSaving,
    prefsError,
    updateSettings,
    toggleScreenReader,
    toggleBiggerText,
    toggleSmallText,
    toggleLineHeight,
    toggleHighlightLinks,
    toggleTextSpacing,
    toggleDyslexiaMode,
    toggleHideImages,
    toggleCustomCursor,
    toggleDarkMode,
    toggleInvertColors,
    resetToDefaults,
    saveChanges,
  } = useAccessibility();

  useEffect(() => {
    if (!drawerOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeDrawer();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [drawerOpen, closeDrawer]);

  if (!drawerOpen) return null;

  const textSizeStepCount =
    settings.fontSizePercent >= 145
      ? 4
      : settings.fontSizePercent >= 130
      ? 3
      : settings.fontSizePercent >= 120
      ? 2
      : settings.biggerText
      ? 1
      : 0;

  const tiles = [
    {
      id: 'screen-reader',
      label: 'Screen Reader',
      active: settings.screenReader,
      onClick: toggleScreenReader,
      renderIcon: () => <Volume2 className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'bigger-text',
      label: 'Bigger Text',
      active: settings.biggerText,
      onClick: toggleBiggerText,
      renderIcon: () => (
        <span className="text-xl font-extrabold tracking-tight leading-none" aria-hidden="true">
          TT
        </span>
      ),
      levelBars: textSizeStepCount,
    },
    {
      id: 'small-text',
      label: 'Small Text',
      active: settings.smallText,
      onClick: toggleSmallText,
      renderIcon: () => (
        <span className="text-sm font-bold tracking-tight leading-none" aria-hidden="true">
          TT
        </span>
      ),
    },
    {
      id: 'line-height',
      label: 'Line Height',
      active: settings.lineHeightEnabled,
      onClick: toggleLineHeight,
      renderIcon: () => <MoveVertical className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'highlight-links',
      label: 'Highlight Links',
      active: settings.highlightLinks,
      onClick: toggleHighlightLinks,
      renderIcon: () => <Link2 className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'text-spacing',
      label: 'Text Spacing',
      active: settings.textSpacingEnabled,
      onClick: toggleTextSpacing,
      renderIcon: () => (
        <span className="text-sm font-extrabold tracking-wide leading-none" aria-hidden="true">
          A↔A
        </span>
      ),
    },
    {
      id: 'dyslexia-friendly',
      label: 'Dyslexia Friendly',
      active: settings.dyslexiaMode,
      onClick: toggleDyslexiaMode,
      renderIcon: () => (
        <span className="text-xl font-extrabold tracking-tight leading-none" aria-hidden="true">
          Df
        </span>
      ),
    },
    {
      id: 'hide-images',
      label: 'Hide Images',
      active: settings.hideImages,
      onClick: toggleHideImages,
      renderIcon: () => <ImageOff className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'custom-cursor',
      label: 'Custom Cursor',
      active: settings.customCursor,
      onClick: toggleCustomCursor,
      renderIcon: () => <MousePointerClick className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'dark-mode',
      label: 'Light-Dark Mode',
      active: settings.darkMode,
      onClick: toggleDarkMode,
      renderIcon: () => <Moon className="h-6 w-6" aria-hidden="true" />,
    },
    {
      id: 'invert-colors',
      label: 'Invert Colours',
      active: settings.invertColors,
      onClick: toggleInvertColors,
      renderIcon: () => <Contrast className="h-6 w-6" aria-hidden="true" />,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#1B2B41]/35 backdrop-blur-[1px]"
        onClick={closeDrawer}
        aria-hidden="true"
      />

      {/* Right-Side Slide-Out Panel */}
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="a11y-drawer-title"
        data-testid="accessibility-drawer"
        className="relative z-10 flex h-full w-full max-w-[430px] flex-col bg-white dark:bg-slate-900 text-[#243447] dark:text-slate-100 shadow-2xl border-l border-[#D4DFEC] dark:border-slate-700"
      >
        {/* Royal Blue Header (CBSE Reference) */}
        <div className="flex items-center justify-between gap-3 bg-[#0B49B8] px-5 py-4 text-white">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-[#0B49B8]">
              <Accessibility className="h-5 w-5" aria-hidden="true" />
            </span>
            <h2 id="a11y-drawer-title" className="text-lg font-extrabold tracking-tight">
              Accessibility Options
            </h2>
          </div>
          <button
            type="button"
            onClick={closeDrawer}
            aria-label="Close Accessibility Options"
            className="rounded-lg p-1.5 text-white/90 hover:bg-white/15 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Tiles & Sliders */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
          <p className="text-sm leading-snug text-[#4A5E75] dark:text-slate-300">
            Customize your learning experience for better reading, focus and inclusion.
          </p>

          {prefsLoading && (
            <div className="rounded-xl border border-[#CFE0F5] dark:border-slate-700 bg-[#EAF3FF] dark:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-[#0B63CE] dark:text-sky-300">
              Restoring saved preferences...
            </div>
          )}

          {prefsError && (
            <div
              role="alert"
              className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 px-3.5 py-2 text-xs font-semibold text-[#9B1C1C] dark:text-red-200"
            >
              {prefsError}
            </div>
          )}

          {settings.screenReader && (
            <div className="rounded-xl border border-[#F59E0B] bg-[#FEF9DC] dark:bg-amber-950/50 px-3.5 py-2.5 text-xs font-semibold text-[#243447] dark:text-amber-100">
              Screen Reader active: semantic ARIA announcements and keyboard focus highlights are enabled.
            </div>
          )}

          {/* 3-Column Tile Grid (11 Selectable Options) */}
          <div className="grid grid-cols-3 gap-2.5">
            {tiles.map((tile) => (
              <button
                key={tile.id}
                type="button"
                aria-pressed={tile.active}
                onClick={tile.onClick}
                className={`relative flex min-h-[96px] flex-col items-center justify-center gap-2 rounded-2xl p-2.5 text-center transition-[border-color,box-shadow] duration-100 ${
                  tile.active
                    ? 'border-2 border-[#0B63CE] bg-[#F2F7FF] dark:bg-slate-800 text-[#0B49B8] dark:text-sky-300 shadow-sm'
                    : 'border border-[#E1E8F0] dark:border-slate-700 bg-[#FAFBFD] dark:bg-slate-800/70 text-[#243447] dark:text-slate-100 hover:border-[#93B8EA]'
                }`}
              >
                {tile.active && (
                  <span
                    aria-hidden="true"
                    className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#0B63CE] text-white"
                  >
                    <Check className="h-3 w-3 stroke-[3]" />
                  </span>
                )}

                <span className="flex h-7 items-center justify-center">{tile.renderIcon()}</span>
                <span className="text-[11px] font-bold leading-tight">{tile.label}</span>

                {typeof tile.levelBars === 'number' && tile.active && (
                  <span className="flex items-center gap-1 pt-0.5" aria-hidden="true">
                    {[1, 2, 3, 4].map((bar) => (
                      <span
                        key={bar}
                        className={`h-1 w-3 rounded-full ${
                          bar <= Math.max(1, tile.levelBars!)
                            ? 'bg-[#0B63CE]'
                            : 'bg-[#CBD5E1] dark:bg-slate-600'
                        }`}
                      />
                    ))}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Text & Display Settings Sliders */}
          <div className="border-t border-[#E6ECF2] dark:border-slate-700 pt-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-[#243447] dark:text-slate-100">
                Text & Display Settings
              </h3>
              {lastSavedAt && (
                <span className="text-[11px] font-bold text-[#15803D] dark:text-emerald-400">
                  {lastSavedAt === 'Reset to default' ? 'Reset' : `Saved ${lastSavedAt}`}
                </span>
              )}
            </div>

            {/* Text Size Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <label htmlFor="drawer-text-size">Text Size</label>
                <span className="font-tabular text-[#0B63CE] dark:text-sky-400">
                  {settings.fontSizePercent}%
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-[#526275] dark:text-slate-400" aria-hidden="true">
                  A
                </span>
                <input
                  id="drawer-text-size"
                  type="range"
                  min={85}
                  max={160}
                  step={5}
                  value={settings.fontSizePercent}
                  onChange={(e) => updateSettings({ fontSizePercent: Number(e.target.value) })}
                  className="flex-1 accent-[#0B63CE] cursor-pointer"
                />
                <span className="text-lg font-bold text-[#243447] dark:text-slate-200" aria-hidden="true">
                  A
                </span>
              </div>
            </div>

            {/* Line Height Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <label htmlFor="drawer-line-height">Line Height</label>
                <span className="font-tabular text-[#0B63CE] dark:text-sky-400">
                  {settings.lineSpacing.toFixed(1)}×
                </span>
              </div>
              <div className="flex items-center gap-3">
                <MoveVertical className="h-3.5 w-3.5 text-[#526275] dark:text-slate-400" aria-hidden="true" />
                <input
                  id="drawer-line-height"
                  type="range"
                  min={1.3}
                  max={2.2}
                  step={0.1}
                  value={settings.lineSpacing}
                  onChange={(e) => updateSettings({ lineSpacing: Number(e.target.value) })}
                  className="flex-1 accent-[#0B63CE] cursor-pointer"
                />
                <MoveVertical className="h-5 w-5 text-[#243447] dark:text-slate-200" aria-hidden="true" />
              </div>
            </div>

            {/* Text Spacing Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <label htmlFor="drawer-text-spacing">Text Spacing</label>
                <span className="font-tabular text-[#0B63CE] dark:text-sky-400">
                  {settings.letterSpacing.toFixed(2)}em
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[11px] font-bold text-[#526275] dark:text-slate-400" aria-hidden="true">
                  A↔A
                </span>
                <input
                  id="drawer-text-spacing"
                  type="range"
                  min={0}
                  max={0.14}
                  step={0.01}
                  value={settings.letterSpacing}
                  onChange={(e) => {
                    const nextVal = Number(e.target.value);
                    updateSettings({
                      letterSpacing: nextVal,
                      wordSpacing: Number((nextVal * 2).toFixed(2)),
                    });
                  }}
                  className="flex-1 accent-[#0B63CE] cursor-pointer"
                />
                <span className="text-xs font-extrabold tracking-wider text-[#243447] dark:text-slate-200" aria-hidden="true">
                  A↔A
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Action Buttons */}
        <div className="flex items-center gap-3 border-t border-[#E6ECF2] dark:border-slate-700 bg-white dark:bg-slate-900 px-5 py-4">
          <button
            type="button"
            onClick={resetToDefaults}
            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#EAF1FC] dark:bg-slate-800 px-3 py-3 text-xs font-bold text-[#0B49B8] dark:text-sky-300 hover:bg-[#DCE7FA] dark:hover:bg-slate-700 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>Reset All Settings</span>
          </button>
          <button
            type="button"
            disabled={prefsSaving}
            onClick={async () => {
              const ok = await saveChanges();
              if (ok) closeDrawer();
            }}
            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#0B49B8] px-3 py-3 text-xs font-bold text-white hover:bg-[#083B96] transition-colors whitespace-nowrap disabled:opacity-60"
          >
            <Check className="h-4 w-4" aria-hidden="true" />
            <span>{prefsSaving ? 'Saving...' : 'Apply Changes'}</span>
          </button>
        </div>
      </aside>
    </div>
  );
};
