import React, { useEffect, useRef, useState } from 'react';
import { Pause, Play, Square, Volume2 } from 'lucide-react';
import { splitIntoSentences } from '../../utils/accessibility';

interface TextToSpeechBarProps {
  text: string;
  rate: number;
  onRateChange: (rate: number) => void;
  onActiveSentenceChange: (sentenceIndex: number | null, activeWordIndex?: number | null) => void;
}

export const TextToSpeechBar: React.FC<TextToSpeechBarProps> = ({
  text,
  rate,
  onRateChange,
  onActiveSentenceChange,
}) => {
  const [status, setStatus] = useState<'idle' | 'playing' | 'paused'>('idle');
  const [supported] = useState<boolean>(
    () => typeof window !== 'undefined' && 'speechSynthesis' in window
  );
  const sentencesRef = useRef<string[]>([]);
  const timerRef = useRef<number | null>(null);
  const currentIdxRef = useRef<number>(0);

  useEffect(() => {
    sentencesRef.current = splitIntoSentences(text);
  }, [text]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      if (supported) window.speechSynthesis.cancel();
    };
  }, [supported]);

  const stopSpeaking = () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
    if (supported) window.speechSynthesis.cancel();
    currentIdxRef.current = 0;
    setStatus('idle');
    onActiveSentenceChange(null, null);
  };

  const speakFromIndex = (idx: number) => {
    const sentences = sentencesRef.current;
    if (idx >= sentences.length) {
      stopSpeaking();
      return;
    }

    currentIdxRef.current = idx;
    onActiveSentenceChange(idx, 0);

    if (supported) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(sentences[idx]);
      utterance.rate = rate;
      utterance.lang = 'en-IN';
      utterance.onboundary = (event) => {
        if (event.name === 'word') {
          const before = sentences[idx].slice(0, event.charIndex).trim();
          const wordIdx = before ? before.split(/\s+/).length : 0;
          onActiveSentenceChange(idx, wordIdx);
        }
      };
      utterance.onend = () => {
        speakFromIndex(idx + 1);
      };
      utterance.onerror = () => {
        // Fallback timed visual progression if speech engine is unavailable in headless browser
        const approxMs = Math.max(1800, Math.round((sentences[idx].length * 55) / rate));
        timerRef.current = window.setTimeout(() => {
          speakFromIndex(idx + 1);
        }, approxMs);
      };
      window.speechSynthesis.speak(utterance);
    } else {
      const approxMs = Math.max(1800, Math.round((sentences[idx].length * 55) / rate));
      timerRef.current = window.setTimeout(() => {
        speakFromIndex(idx + 1);
      }, approxMs);
    }
  };

  const handlePlayOrResume = () => {
    if (status === 'paused' && supported && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setStatus('playing');
      return;
    }
    setStatus('playing');
    speakFromIndex(status === 'paused' ? currentIdxRef.current : 0);
  };

  const handlePause = () => {
    if (supported && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
    if (timerRef.current) window.clearTimeout(timerRef.current);
    setStatus('paused');
  };

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5">
      <div className="flex items-center gap-2 text-sm font-semibold text-[#243447] dark:text-slate-100 mr-2">
        <Volume2 className="h-4 w-4 text-[#3C8D91] dark:text-teal-400" aria-hidden="true" />
        <span>Read Aloud</span>
      </div>

      {status !== 'playing' ? (
        <button
          type="button"
          onClick={handlePlayOrResume}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#0B63CE] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#094FA6] transition-colors whitespace-nowrap shrink-0"
        >
          <Play className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{status === 'paused' ? 'Resume' : 'Play Passage'}</span>
        </button>
      ) : (
        <button
          type="button"
          onClick={handlePause}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#243447] dark:bg-slate-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#1A2635] dark:hover:bg-slate-600 transition-colors whitespace-nowrap shrink-0"
        >
          <Pause className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Pause</span>
        </button>
      )}

      {status !== 'idle' && (
        <button
          type="button"
          onClick={stopSpeaking}
          className="inline-flex items-center gap-1.5 rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
        >
          <Square className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Stop</span>
        </button>
      )}

      <div className="flex items-center gap-1.5 ml-auto">
        <label htmlFor="tts-speed" className="text-xs font-medium text-[#526275] dark:text-slate-300">
          Speed:
        </label>
        <select
          id="tts-speed"
          value={rate}
          onChange={(e) => onRateChange(Number(e.target.value))}
          className="rounded-lg border border-[#DCE5EF] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-2 py-1 text-xs font-semibold text-[#243447] dark:text-slate-100 font-tabular"
        >
          <option value={0.75}>0.75x (Calm)</option>
          <option value={1}>1.0x (Normal)</option>
          <option value={1.25}>1.25x (Brisk)</option>
          <option value={1.5}>1.5x (Fast)</option>
        </select>
      </div>
    </div>
  );
};
