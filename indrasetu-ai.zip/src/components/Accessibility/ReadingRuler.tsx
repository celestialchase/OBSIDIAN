import React, { useEffect, useRef, useState } from 'react';

interface ReadingRulerProps {
  enabled: boolean;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export const ReadingRulerContainer: React.FC<ReadingRulerProps> = ({
  enabled,
  children,
  className = '',
  style,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [rulerY, setRulerY] = useState<number>(38);
  const [isHovering, setIsHovering] = useState<boolean>(false);

  useEffect(() => {
    if (!enabled) return;
    setRulerY(38);
  }, [enabled]);

  const updatePosition = (clientY: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relativeY = Math.max(12, Math.min(rect.height - 44, clientY - rect.top - 18));
    setRulerY(relativeY);
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={(e) => {
        if (!enabled) return;
        setIsHovering(true);
        updatePosition(e.clientY);
      }}
      onMouseLeave={() => setIsHovering(false)}
      onTouchMove={(e) => {
        if (!enabled || !e.touches[0]) return;
        setIsHovering(true);
        updatePosition(e.touches[0].clientY);
      }}
      className={`relative overflow-hidden ${className}`}
      style={style}
    >
      {enabled && (
        <div
          aria-hidden="true"
          data-testid="reading-ruler-bar"
          className="pointer-events-none absolute inset-x-0 z-10 transition-transform duration-75"
          style={{
            transform: `translateY(${rulerY}px)`,
            height: '2.25em',
            backgroundColor: isHovering
              ? 'rgba(253, 224, 71, 0.34)'
              : 'rgba(253, 224, 71, 0.28)',
            borderTop: '2px solid rgba(180, 130, 12, 0.35)',
            borderBottom: '2px solid rgba(180, 130, 12, 0.35)',
          }}
        />
      )}
      <div className="relative z-0">{children}</div>
    </div>
  );
};
