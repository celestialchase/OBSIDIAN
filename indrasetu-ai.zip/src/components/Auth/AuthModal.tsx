import React, { useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { GraduationCap, KeyRound, ShieldCheck, UserCheck, X } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { CBSE_GRADES } from '../../data/curriculum';
import { auth, googleProvider } from '../../lib/firebase';
import { ensureUserProfileDoc } from '../../services/firestoreService';
import {
  validateLoginForm,
  validatePasswordRecoveryForm,
  validateRegistrationForm,
} from '../../utils/validation';

function formatFirebaseAuthError(err: unknown): string {
  const code =
    err && typeof err === 'object' && 'code' in err ? String((err as { code: unknown }).code) : '';
  switch (code) {
    case 'auth/operation-not-allowed':
      return 'Email/Password sign-in is not yet enabled in Firebase Console (Authentication → Sign-in method → Email/Password). You can use Continue with Google or Demo Mode immediately.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Incorrect email or password. Please check your credentials or reset your password.';
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Please sign in instead.';
    case 'auth/weak-password':
      return 'Please choose a stronger password (at least 6 characters).';
    case 'auth/popup-closed-by-user':
      return 'Google sign-in popup was closed before completing sign-in.';
    case 'auth/popup-blocked':
      return 'Popup was blocked by the browser. Please allow popups for this site and try again.';
    case 'auth/too-many-requests':
      return 'Too many sign-in attempts. Please wait a moment before trying again.';
    default:
      return err instanceof Error ? err.message : 'Unable to complete authentication. Please try again.';
  }
}

export const AuthModal: React.FC = () => {
  const {
    authModalOpen,
    closeAuthModal,
    authModalMode,
    setUser,
    setPendingSignupMeta,
    navigate,
  } = useApp();
  const [tab, setTab] = useState<'login' | 'register' | 'teacher' | 'recover'>(authModalMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [grade, setGrade] = useState('Class 8');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setTab(authModalMode);
    setErrors({});
    setFeedback(null);
    setAuthError(null);
    setSubmitting(false);
  }, [authModalMode, authModalOpen]);

  if (!authModalOpen) return null;

  const handleGoogleSignIn = async () => {
    setErrors({});
    setFeedback(null);
    setAuthError(null);
    setSubmitting(true);

    const chosenRole = tab === 'teacher' ? 'teacher' : 'student';
    setPendingSignupMeta({
      role: chosenRole,
      grade,
    });

    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const profile = await ensureUserProfileDoc({
        uid: cred.user.uid,
        name: cred.user.displayName || cred.user.email?.split('@')[0] || 'IndraSetu Learner',
        email: cred.user.email || '',
        role: chosenRole,
        grade,
      });
      setUser({ ...profile, emailVerified: cred.user.emailVerified });
      closeAuthModal();
      navigate('dashboard');
    } catch (err) {
      setPendingSignupMeta(null);
      setAuthError(formatFirebaseAuthError(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setAuthError(null);

    if (tab === 'login' || tab === 'teacher') {
      const result = validateLoginForm(email, password);
      if (!result.valid) {
        setErrors(result.errors);
        return;
      }
      setErrors({});
      setSubmitting(true);
      const chosenRole = tab === 'teacher' ? 'teacher' : 'student';
      setPendingSignupMeta({ role: chosenRole, grade });

      try {
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        const profile = await ensureUserProfileDoc({
          uid: cred.user.uid,
          name:
            cred.user.displayName ||
            (chosenRole === 'teacher'
              ? `Ms. ${email.split('@')[0]}`
              : email.split('@')[0].replace(/[._]/g, ' ')),
          email: cred.user.email || email.trim(),
          role: chosenRole,
          grade,
        });
        setUser({ ...profile, emailVerified: cred.user.emailVerified });
        closeAuthModal();
        navigate('dashboard');
      } catch (err) {
        setPendingSignupMeta(null);
        setAuthError(formatFirebaseAuthError(err));
      } finally {
        setSubmitting(false);
      }
      return;
    }

    if (tab === 'register') {
      const result = validateRegistrationForm(name, email, password, grade);
      if (!result.valid) {
        setErrors(result.errors);
        return;
      }
      setErrors({});
      setSubmitting(true);
      setPendingSignupMeta({ name: name.trim(), role: 'student', grade });

      try {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: name.trim() });
        void sendEmailVerification(cred.user).catch(() => {
          // non-blocking verification email dispatch
        });
        const profile = await ensureUserProfileDoc({
          uid: cred.user.uid,
          name: name.trim(),
          email: cred.user.email || email.trim(),
          role: 'student',
          grade,
        });
        setUser({ ...profile, emailVerified: cred.user.emailVerified });
        closeAuthModal();
        navigate('dashboard');
      } catch (err) {
        setPendingSignupMeta(null);
        setAuthError(formatFirebaseAuthError(err));
      } finally {
        setSubmitting(false);
      }
      return;
    }

    const recResult = validatePasswordRecoveryForm(email);
    if (!recResult.valid) {
      setErrors(recResult.errors);
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setFeedback(
        `If ${email.trim()} is registered, a Firebase password reset email has been sent. You can also sign in with Google or continue in Demo Mode.`
      );
    } catch (err) {
      setAuthError(formatFirebaseAuthError(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleEnterDemo = (role: 'student' | 'teacher') => {
    setUser({
      id: role === 'teacher' ? 'demo-teacher-1' : 'demo-student-1',
      name: role === 'teacher' ? 'Ms. Ananya Sharma' : 'Aarav Verma',
      email: role === 'teacher' ? 'ananya.teacher@indrasetu.edu' : 'aarav.student@indrasetu.edu',
      role,
      grade: 'Class 8',
      board: 'CBSE',
      isDemo: true,
    });
    closeAuthModal();
    navigate('dashboard');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#243447]/55 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-lg rounded-2xl border border-[#DCE5EF] dark:border-slate-700 bg-white dark:bg-slate-900 p-6 shadow-xl text-[#243447] dark:text-slate-100 max-h-[92vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="auth-modal-title" className="text-xl font-bold text-[#243447] dark:text-slate-100">
              IndraSetu AI Account Portal
            </h2>
            <p className="mt-1 text-sm text-[#526275] dark:text-slate-400">
              Sign in as a student or teacher, or launch Demo Mode right away.
            </p>
          </div>
          <button
            type="button"
            onClick={closeAuthModal}
            aria-label="Close authentication modal"
            className="rounded-lg p-1.5 text-[#526275] dark:text-slate-400 hover:bg-[#EAF3FF] dark:hover:bg-slate-800 hover:text-[#243447] dark:hover:text-slate-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-4 grid grid-cols-4 gap-1 rounded-xl bg-[#EAF3FF] dark:bg-slate-800 p-1">
          {[
            { id: 'login', label: 'Student' },
            { id: 'register', label: 'Register' },
            { id: 'teacher', label: 'Teacher' },
            { id: 'recover', label: 'Recover' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setTab(item.id as typeof tab);
                setErrors({});
                setFeedback(null);
                setAuthError(null);
              }}
              className={`rounded-lg py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === item.id
                  ? 'bg-white dark:bg-slate-700 text-[#0B63CE] dark:text-sky-300 shadow-sm'
                  : 'text-[#4A5E75] dark:text-slate-300 hover:text-[#243447] dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {tab !== 'recover' && (
          <div className="mt-4">
            <button
              type="button"
              disabled={submitting}
              onClick={handleGoogleSignIn}
              className="w-full inline-flex items-center justify-center gap-2.5 rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-4 py-2.5 text-sm font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors disabled:opacity-60"
            >
              <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>
            <div className="my-3 flex items-center gap-3">
              <div className="h-px flex-1 bg-[#EBF0F5] dark:bg-slate-800" />
              <span className="text-[11px] font-semibold text-[#526275] dark:text-slate-400">
                OR USE EMAIL & PASSWORD
              </span>
              <div className="h-px flex-1 bg-[#EBF0F5] dark:bg-slate-800" />
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="mt-3 space-y-4">
          {tab === 'register' && (
            <div>
              <label htmlFor="auth-name" className="block text-sm font-semibold text-[#243447] dark:text-slate-200">
                Full Name
              </label>
              <input
                id="auth-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter student name"
                className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
              />
              {errors.name && <p className="mt-1 text-xs font-medium text-[#C53030] dark:text-red-400">{errors.name}</p>}
            </div>
          )}

          <div>
            <label htmlFor="auth-email" className="block text-sm font-semibold text-[#243447] dark:text-slate-200">
              Email Address
            </label>
            <input
              id="auth-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={tab === 'teacher' ? 'teacher@school.edu' : 'student@school.edu'}
              className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
            />
            {errors.email && <p className="mt-1 text-xs font-medium text-[#C53030] dark:text-red-400">{errors.email}</p>}
          </div>

          {tab !== 'recover' && (
            <div>
              <label htmlFor="auth-password" className="block text-sm font-semibold text-[#243447] dark:text-slate-200">
                Password
              </label>
              <input
                id="auth-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
              />
              {errors.password && (
                <p className="mt-1 text-xs font-medium text-[#C53030] dark:text-red-400">{errors.password}</p>
              )}
            </div>
          )}

          {(tab === 'register' || tab === 'login') && (
            <div>
              <label htmlFor="auth-grade" className="block text-sm font-semibold text-[#243447] dark:text-slate-200">
                CBSE Class
              </label>
              <select
                id="auth-grade"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm text-[#243447] dark:text-slate-100"
              >
                {CBSE_GRADES.map((g) => (
                  <option key={g} value={g}>
                    {g} (CBSE)
                  </option>
                ))}
              </select>
            </div>
          )}

          {authError && (
            <div className="rounded-xl border border-[#F5C2C7] dark:border-red-800 bg-[#FDF2F2] dark:bg-red-950/60 p-3 text-xs font-medium text-[#9B1C1C] dark:text-red-200">
              {authError}
            </div>
          )}

          {feedback && (
            <div className="rounded-xl border border-[#B6E0DA] dark:border-emerald-700 bg-[#E6F5EE] dark:bg-emerald-950/50 p-3 text-xs font-medium text-[#1D3538] dark:text-emerald-200">
              {feedback}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#0B63CE] px-4 py-3 text-sm font-bold text-white hover:bg-[#094FA6] transition-colors disabled:opacity-60"
          >
            {tab === 'recover' ? (
              <>
                <KeyRound className="h-4 w-4" aria-hidden="true" />
                <span>{submitting ? 'Sending...' : 'Send Recovery Link'}</span>
              </>
            ) : tab === 'register' ? (
              <>
                <UserCheck className="h-4 w-4" aria-hidden="true" />
                <span>{submitting ? 'Creating Account...' : 'Create Student Account'}</span>
              </>
            ) : (
              <>
                <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                <span>
                  {submitting
                    ? 'Signing In...'
                    : tab === 'teacher'
                    ? 'Sign In as Teacher'
                    : 'Sign In as Student'}
                </span>
              </>
            )}
          </button>
        </form>

        <div className="mt-5 border-t border-[#EBF0F5] dark:border-slate-800 pt-4">
          <div className="text-xs font-semibold text-[#526275] dark:text-slate-400 mb-2">
            Instant Prototype Demo Access (No Account Required)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => handleEnterDemo('student')}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#3C8D91] dark:border-teal-700 bg-[#E6F5EE] dark:bg-emerald-950/60 px-3 py-2.5 text-xs font-bold text-[#1D3538] dark:text-emerald-200 hover:bg-[#D5EFE2] dark:hover:bg-emerald-900/60 transition-colors"
            >
              <GraduationCap className="h-4 w-4" aria-hidden="true" />
              <span>Demo Student (Class 8)</span>
            </button>
            <button
              type="button"
              onClick={() => handleEnterDemo('teacher')}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#D4DFEC] dark:border-slate-700 bg-[#FAF9F6] dark:bg-slate-800 px-3 py-2.5 text-xs font-bold text-[#243447] dark:text-slate-100 hover:bg-[#EAF3FF] dark:hover:bg-slate-700 transition-colors"
            >
              <UserCheck className="h-4 w-4" aria-hidden="true" />
              <span>Demo Teacher Portal</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
