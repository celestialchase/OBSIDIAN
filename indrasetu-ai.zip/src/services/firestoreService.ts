import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType, reportFirestoreError } from '../lib/firestoreErrors';
import {
  validateNoteInput,
  validateProfilePatch,
  validateQuizAttemptInput,
} from '../utils/firestoreValidation';
import { validateExternalVideoUrl } from '../utils/mediaValidation';
import {
  AccessibilitySettings,
  BackgroundThemeId,
  ContentWidthOption,
  DoubtMessage,
  FontFamilyOption,
  ISLCategory,
  ISLEntry,
  QuizAttempt,
  SavedNote,
  SubjectName,
  UserProfile,
  UserRole,
  VideoProgressRecord,
} from '../types';
import { clampNumber, DEFAULT_ACCESSIBILITY_SETTINGS } from '../utils/accessibility';

const VALID_GRADES = ['Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10'] as const;
const VALID_SUBJECTS: SubjectName[] = [
  'English',
  'Mathematics',
  'Science',
  'Social Science',
  'Hindi',
  'Computer',
];
const VALID_ISL_CATEGORIES: ISLCategory[] = [
  'Common vocabulary',
  'Classroom communication',
  'Science terminology',
  'Mathematics terminology',
  'Educational expressions',
  'Frequently used phrases',
];
const VALID_FONTS: FontFamilyOption[] = ['atkinson', 'arial', 'jakarta'];
const VALID_WIDTHS: ContentWidthOption[] = ['narrow', 'standard', 'wide'];
const VALID_THEMES: BackgroundThemeId[] = ['cream', 'yellow', 'peach', 'green', 'blue', 'white'];

function sanitizeId(raw: string, prefix: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '');
  if (!cleaned) return `${prefix}-${Date.now()}`;
  return cleaned.slice(0, 128);
}

function sanitizeGrade(grade: string): (typeof VALID_GRADES)[number] {
  return (VALID_GRADES as readonly string[]).includes(grade)
    ? (grade as (typeof VALID_GRADES)[number])
    : 'Class 8';
}

function sanitizeSubject(subject?: string): SubjectName {
  return subject && VALID_SUBJECTS.includes(subject as SubjectName)
    ? (subject as SubjectName)
    : 'Science';
}

function sanitizeCategory(category?: string): ISLCategory {
  return category && VALID_ISL_CATEGORIES.includes(category as ISLCategory)
    ? (category as ISLCategory)
    : 'Common vocabulary';
}

function timestampToMillis(val: unknown): number {
  if (val instanceof Timestamp) return val.toMillis();
  if (val && typeof val === 'object' && 'seconds' in val) {
    const secs = Number((val as { seconds: unknown }).seconds);
    return Number.isFinite(secs) ? secs * 1000 : 0;
  }
  return 0;
}

export async function getUserProfileDoc(uid: string): Promise<UserProfile | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    const data = snap.data();
    return {
      id: String(data.uid || uid),
      name: String(data.name || 'Student'),
      email: String(data.email || ''),
      role: data.role === 'teacher' ? 'teacher' : 'student',
      grade: sanitizeGrade(String(data.grade || 'Class 8')),
      board: 'CBSE',
      isDemo: false,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function ensureUserProfileDoc(input: {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  grade: string;
}): Promise<UserProfile> {
  const path = `users/${input.uid}`;
  try {
    const ref = doc(db, 'users', input.uid);
    const existing = await getDoc(ref);
    if (existing.exists()) {
      const data = existing.data();
      return {
        id: input.uid,
        name: String(data.name || input.name || 'Student'),
        email: String(data.email || input.email || ''),
        role: data.role === 'teacher' ? 'teacher' : 'student',
        grade: sanitizeGrade(String(data.grade || input.grade)),
        board: 'CBSE',
        isDemo: false,
      };
    }

    const cleanName = (input.name.trim() || 'IndraSetu Learner').slice(0, 120);
    const cleanEmail = (input.email.trim() || `${input.uid}@indrasetu.edu`).slice(0, 200);
    const cleanGrade = sanitizeGrade(input.grade);
    const cleanRole: UserRole = 'student';

    await setDoc(ref, {
      uid: input.uid,
      name: cleanName,
      email: cleanEmail,
      role: cleanRole,
      grade: cleanGrade,
      board: 'CBSE',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    return {
      id: input.uid,
      name: cleanName,
      email: cleanEmail,
      role: cleanRole,
      grade: cleanGrade,
      board: 'CBSE',
      isDemo: false,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateUserProfileDoc(
  uid: string,
  patch: { name: string; grade: string }
): Promise<void> {
  const check = validateProfilePatch(patch);
  if (!check.valid) {
    throw new Error(check.error || 'Invalid profile update.');
  }
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      name: check.cleanName,
      grade: sanitizeGrade(patch.grade),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateUserGradeDoc(uid: string, grade: string): Promise<void> {
  const safeGrade = sanitizeGrade(grade);
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      grade: safeGrade,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function sanitizeAccessibilityPayload(
  uid: string,
  settings: AccessibilitySettings
): Record<string, unknown> {
  const s = { ...DEFAULT_ACCESSIBILITY_SETTINGS, ...settings };
  return {
    uid,
    dyslexiaMode: Boolean(s.dyslexiaMode),
    focusMode: Boolean(s.focusMode),
    readingRuler: Boolean(s.readingRuler),
    textToSpeech: Boolean(s.textToSpeech),
    highContrast: Boolean(s.highContrast),
    screenReader: Boolean(s.screenReader),
    biggerText: Boolean(s.biggerText),
    smallText: Boolean(s.smallText),
    lineHeightEnabled: Boolean(s.lineHeightEnabled),
    highlightLinks: Boolean(s.highlightLinks),
    textSpacingEnabled: Boolean(s.textSpacingEnabled),
    hideImages: Boolean(s.hideImages),
    customCursor: Boolean(s.customCursor),
    darkMode: Boolean(s.darkMode),
    invertColors: Boolean(s.invertColors),
    fontFamily: VALID_FONTS.includes(s.fontFamily) ? s.fontFamily : 'jakarta',
    fontSizePercent: clampNumber(Number(s.fontSizePercent), 85, 160),
    lineSpacing: clampNumber(Number(s.lineSpacing), 1.3, 2.2),
    letterSpacing: clampNumber(Number(s.letterSpacing), 0, 0.14),
    wordSpacing: clampNumber(Number(s.wordSpacing ?? 0), 0, 0.25),
    paragraphSpacing: clampNumber(Number(s.paragraphSpacing), 0.8, 2.4),
    contentWidth: VALID_WIDTHS.includes(s.contentWidth) ? s.contentWidth : 'standard',
    backgroundTheme: VALID_THEMES.includes(s.backgroundTheme) ? s.backgroundTheme : 'cream',
    ttsRate: clampNumber(Number(s.ttsRate), 0.7, 1.5),
    captionsEnabled: Boolean(s.captionsEnabled),
    captionSize: s.captionSize === 'sm' || s.captionSize === 'lg' ? s.captionSize : 'md',
    captionBackground:
      s.captionBackground === 'cream' || s.captionBackground === 'high-contrast'
        ? s.captionBackground
        : 'dark',
    islPanelDefaultVisible: Boolean(s.islPanelDefaultVisible),
  };
}

function normalizeAccessibilityPrefsData(d: Record<string, unknown>): AccessibilitySettings {
  return {
    ...DEFAULT_ACCESSIBILITY_SETTINGS,
    dyslexiaMode: Boolean(d.dyslexiaMode),
    focusMode: Boolean(d.focusMode),
    readingRuler: Boolean(d.readingRuler),
    textToSpeech: Boolean(d.textToSpeech),
    highContrast: Boolean(d.highContrast),
    screenReader: Boolean(d.screenReader),
    biggerText: Boolean(d.biggerText),
    smallText: Boolean(d.smallText),
    lineHeightEnabled: Boolean(d.lineHeightEnabled),
    highlightLinks: Boolean(d.highlightLinks),
    textSpacingEnabled: Boolean(d.textSpacingEnabled),
    hideImages: Boolean(d.hideImages),
    customCursor: Boolean(d.customCursor),
    darkMode: Boolean(d.darkMode),
    invertColors: Boolean(d.invertColors),
    fontFamily: VALID_FONTS.includes(d.fontFamily as FontFamilyOption)
      ? (d.fontFamily as FontFamilyOption)
      : 'jakarta',
    fontSizePercent: clampNumber(Number(d.fontSizePercent ?? 100), 85, 160),
    lineSpacing: clampNumber(Number(d.lineSpacing ?? 1.6), 1.3, 2.2),
    letterSpacing: clampNumber(Number(d.letterSpacing ?? 0.01), 0, 0.14),
    wordSpacing: clampNumber(Number(d.wordSpacing ?? 0), 0, 0.25),
    paragraphSpacing: clampNumber(Number(d.paragraphSpacing ?? 1.2), 0.8, 2.4),
    contentWidth: VALID_WIDTHS.includes(d.contentWidth as ContentWidthOption)
      ? (d.contentWidth as ContentWidthOption)
      : 'standard',
    backgroundTheme: VALID_THEMES.includes(d.backgroundTheme as BackgroundThemeId)
      ? (d.backgroundTheme as BackgroundThemeId)
      : 'cream',
    ttsRate: clampNumber(Number(d.ttsRate ?? 1.0), 0.7, 1.5),
    captionsEnabled: Boolean(d.captionsEnabled ?? true),
    captionSize: d.captionSize === 'sm' || d.captionSize === 'lg' ? d.captionSize : 'md',
    captionBackground:
      d.captionBackground === 'cream' || d.captionBackground === 'high-contrast'
        ? d.captionBackground
        : 'dark',
    islPanelDefaultVisible: Boolean(d.islPanelDefaultVisible ?? true),
  };
}

export async function getAccessibilityPrefsDoc(uid: string): Promise<AccessibilitySettings | null> {
  const path = `users/${uid}/preferences/accessibility`;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'preferences', 'accessibility'));
    if (!snap.exists()) return null;
    return normalizeAccessibilityPrefsData(snap.data());
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export function subscribeAccessibilityPrefsDoc(
  uid: string,
  onData: (settings: AccessibilitySettings | null) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/preferences/accessibility`;
  return onSnapshot(
    doc(db, 'users', uid, 'preferences', 'accessibility'),
    (snap) => {
      if (!snap.exists()) {
        onData(null);
        return;
      }
      onData(normalizeAccessibilityPrefsData(snap.data()));
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.GET, path);
      onError?.(friendly);
    }
  );
}

export async function saveAccessibilityPrefsDoc(
  uid: string,
  settings: AccessibilitySettings
): Promise<void> {
  const path = `users/${uid}/preferences/accessibility`;
  try {
    const payload = sanitizeAccessibilityPayload(uid, settings);
    await setDoc(doc(db, 'users', uid, 'preferences', 'accessibility'), {
      ...payload,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeNotes(
  uid: string,
  onData: (notes: SavedNote[]) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/notes`;
  const q = query(collection(db, 'users', uid, 'notes'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs
        .map((d) => {
          const data = d.data();
          return {
            note: {
              id: String(data.id || d.id),
              title: String(data.title || 'Saved Note'),
              subject: sanitizeSubject(String(data.subject || 'Science')),
              content: String(data.content || ''),
              createdAt: String(data.createdAtLabel || 'Saved'),
            } as SavedNote,
            ts: timestampToMillis(data.createdAt),
          };
        })
        .sort((a, b) => b.ts - a.ts)
        .map((item) => item.note);
      onData(items);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function createNoteDoc(
  uid: string,
  note: Omit<SavedNote, 'id' | 'createdAt'>
): Promise<SavedNote> {
  const check = validateNoteInput({
    title: note.title,
    content: note.content,
    subject: note.subject,
  });
  if (!check.valid) {
    throw new Error(check.error || 'Invalid note input.');
  }

  const id = sanitizeId(`note-${Date.now()}`, 'note');
  const path = `users/${uid}/notes/${id}`;
  const createdAtLabel = new Date().toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  const payload = {
    id,
    uid,
    title: note.title.trim().slice(0, 200),
    subject: sanitizeSubject(note.subject),
    content: note.content.trim().slice(0, 4000),
    createdAtLabel: createdAtLabel.slice(0, 60),
    createdAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'users', uid, 'notes', id), payload);
    return {
      id,
      title: payload.title,
      subject: payload.subject,
      content: payload.content,
      createdAt: payload.createdAtLabel,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteNoteDoc(uid: string, noteId: string): Promise<void> {
  const safeNoteId = sanitizeId(noteId, 'note');
  const path = `users/${uid}/notes/${safeNoteId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'notes', safeNoteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeLessonProgress(
  uid: string,
  onData: (completedIds: Set<string>) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/lessonProgress`;
  const q = query(collection(db, 'users', uid, 'lessonProgress'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const completed = new Set<string>();
      for (const d of snapshot.docs) {
        const data = d.data();
        if (data.status === 'completed') {
          completed.add(String(data.lessonId || d.id));
        }
      }
      onData(completed);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function markLessonCompletedDoc(
  uid: string,
  input: { lessonId: string; courseId: string; subject: SubjectName }
): Promise<void> {
  const safeLessonId = sanitizeId(input.lessonId, 'lesson');
  const safeCourseId = sanitizeId(input.courseId, 'course');
  const path = `users/${uid}/lessonProgress/${safeLessonId}`;
  try {
    const ref = doc(db, 'users', uid, 'lessonProgress', safeLessonId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const currentStatus = snap.data().status;
      if (currentStatus === 'completed') return;
      await updateDoc(ref, {
        status: 'completed',
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        lessonId: safeLessonId,
        uid,
        courseId: safeCourseId,
        subject: sanitizeSubject(input.subject),
        status: 'completed',
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeQuizAttempts(
  uid: string,
  onData: (attempts: QuizAttempt[]) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/quizAttempts`;
  const q = query(collection(db, 'users', uid, 'quizAttempts'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs
        .map((d) => {
          const data = d.data();
          return {
            attempt: {
              id: String(data.id || d.id),
              subject: sanitizeSubject(String(data.subject || 'Science')),
              topic: String(data.topic || 'Assessment'),
              score: Number(data.score ?? 0),
              total: Math.max(1, Number(data.total ?? 1)),
              percent: clampNumber(Number(data.percent ?? 0), 0, 100),
              completedAt: String(data.completedAtLabel || 'Completed'),
            } as QuizAttempt,
            ts: timestampToMillis(data.createdAt),
          };
        })
        .sort((a, b) => b.ts - a.ts)
        .map((item) => item.attempt);
      onData(items);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function createQuizAttemptDoc(
  uid: string,
  attempt: Omit<QuizAttempt, 'id' | 'completedAt'>
): Promise<void> {
  const check = validateQuizAttemptInput({
    topic: attempt.topic,
    score: attempt.score,
    total: attempt.total,
  });
  if (!check.valid) {
    throw new Error(check.error || 'Invalid assessment attempt.');
  }

  const id = sanitizeId(`att-${Date.now()}`, 'att');
  const path = `users/${uid}/quizAttempts/${id}`;
  const completedAtLabel = new Date().toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  const total = clampNumber(Number(attempt.total), 1, 100);
  const score = clampNumber(Number(attempt.score), 0, total);
  const percent = clampNumber(Number(attempt.percent), 0, 100);

  try {
    await setDoc(doc(db, 'users', uid, 'quizAttempts', id), {
      id,
      uid,
      subject: sanitizeSubject(attempt.subject),
      topic: attempt.topic.trim().slice(0, 200),
      score,
      total,
      percent,
      completedAtLabel: completedAtLabel.slice(0, 60),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeDoubtMessages(
  uid: string,
  onData: (messages: DoubtMessage[]) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/doubtThreads`;
  const q = query(collection(db, 'users', uid, 'doubtThreads'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs
        .map((d) => {
          const data = d.data();
          const msg: DoubtMessage = {
            id: String(data.id || d.id),
            role: data.role === 'user' ? 'user' : 'assistant',
            content: String(data.content || ''),
            timestamp: String(data.timestamp || ''),
          };
          if (data.mode === 'simple' || data.mode === 'detailed' || data.mode === 'visual') {
            msg.mode = data.mode;
          }
          if (data.subject) msg.subject = sanitizeSubject(String(data.subject));
          if (Array.isArray(data.keyPoints)) msg.keyPoints = data.keyPoints.map(String);
          if (Array.isArray(data.visualSteps)) msg.visualSteps = data.visualSteps.map(String);
          if (typeof data.imagePreview === 'string') msg.imagePreview = data.imagePreview;
          if (typeof data.saved === 'boolean') msg.saved = data.saved;
          if (data.source === 'gemini' || data.source === 'offline-guide') {
            msg.source = data.source;
          }
          return { msg, ts: timestampToMillis(data.createdAt) };
        })
        .sort((a, b) => a.ts - b.ts)
        .map((item) => item.msg);
      onData(items);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function createDoubtMessageDoc(
  uid: string,
  msg: DoubtMessage
): Promise<void> {
  const id = sanitizeId(msg.id, msg.role === 'user' ? 'user' : 'ai');
  const path = `users/${uid}/doubtThreads/${id}`;
  const payload: Record<string, unknown> = {
    id,
    uid,
    role: msg.role === 'user' ? 'user' : 'assistant',
    content: (msg.content.trim() || '...').slice(0, 8000),
    timestamp: (msg.timestamp || 'Now').slice(0, 60),
    createdAt: serverTimestamp(),
  };

  if (msg.mode === 'simple' || msg.mode === 'detailed' || msg.mode === 'visual') {
    payload.mode = msg.mode;
  }
  if (msg.subject) {
    payload.subject = sanitizeSubject(msg.subject);
  }
  if (Array.isArray(msg.keyPoints) && msg.keyPoints.length > 0) {
    payload.keyPoints = msg.keyPoints.slice(0, 10).map((s) => String(s).slice(0, 500));
  }
  if (Array.isArray(msg.visualSteps) && msg.visualSteps.length > 0) {
    payload.visualSteps = msg.visualSteps.slice(0, 10).map((s) => String(s).slice(0, 500));
  }
  if (
    typeof msg.imagePreview === 'string' &&
    msg.imagePreview.length > 0 &&
    msg.imagePreview.length <= 2000 &&
    msg.imagePreview.startsWith('https://')
  ) {
    payload.imagePreview = msg.imagePreview;
  }
  if (typeof msg.saved === 'boolean') {
    payload.saved = msg.saved;
  }
  if (msg.source === 'gemini' || msg.source === 'offline-guide') {
    payload.source = msg.source;
  }

  try {
    await setDoc(doc(db, 'users', uid, 'doubtThreads', id), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function markDoubtMessageSavedDoc(uid: string, messageId: string): Promise<void> {
  const safeId = sanitizeId(messageId, 'ai');
  const path = `users/${uid}/doubtThreads/${safeId}`;
  try {
    await updateDoc(doc(db, 'users', uid, 'doubtThreads', safeId), { saved: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeISLEntries(
  onData: (entries: ISLEntry[]) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = 'islEntries';
  return onSnapshot(
    collection(db, 'islEntries'),
    (snapshot) => {
      const items = snapshot.docs
        .map((d) => {
          const data = d.data();
          const entry: ISLEntry = {
            id: String(data.id || d.id),
            createdByUid: data.createdByUid ? String(data.createdByUid) : undefined,
            term: String(data.term || ''),
            category: sanitizeCategory(String(data.category || '')),
            meaning: String(data.meaning || ''),
            handshapeGuide: String(data.handshapeGuide || ''),
            usageExample: String(data.usageExample || ''),
            isVerifiedClip: Boolean(data.isVerifiedClip),
            verificationLabel: String(data.verificationLabel || 'Educator Reference'),
          };
          if (typeof data.customVideoUrl === 'string') {
            entry.customVideoUrl = data.customVideoUrl;
          }
          return { entry, ts: timestampToMillis(data.createdAt) };
        })
        .sort((a, b) => b.ts - a.ts)
        .map((item) => item.entry);
      onData(items);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export function subscribeNotificationStates(
  uid: string,
  onData: (readMap: Record<string, boolean>) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/notifications`;
  const q = query(collection(db, 'users', uid, 'notifications'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const readMap: Record<string, boolean> = {};
      for (const d of snapshot.docs) {
        const data = d.data();
        const id = String(data.id || d.id);
        readMap[id] = Boolean(data.read);
      }
      onData(readMap);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function setNotificationReadDoc(
  uid: string,
  notifId: string,
  read = true
): Promise<void> {
  const safeId = sanitizeId(notifId, 'notif');
  const path = `users/${uid}/notifications/${safeId}`;
  try {
    const ref = doc(db, 'users', uid, 'notifications', safeId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        read: Boolean(read),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        id: safeId,
        uid,
        read: Boolean(read),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeVideoProgress(
  uid: string,
  onData: (progressMap: Record<string, VideoProgressRecord>) => void,
  onError?: (message: string) => void
): Unsubscribe {
  const path = `users/${uid}/videoProgress`;
  const q = query(collection(db, 'users', uid, 'videoProgress'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const map: Record<string, VideoProgressRecord> = {};
      for (const d of snapshot.docs) {
        const data = d.data();
        const videoId = String(data.videoId || d.id);
        const durationSec = clampNumber(Number(data.durationSec ?? 1), 1, 7200);
        const currentSec = clampNumber(Number(data.currentSec ?? 0), 0, durationSec);
        map[videoId] = {
          videoId,
          currentSec,
          durationSec,
          completed: Boolean(data.completed),
        };
      }
      onData(map);
    },
    (error) => {
      const friendly = reportFirestoreError(error, OperationType.LIST, path);
      onError?.(friendly);
    }
  );
}

export async function saveVideoProgressDoc(
  uid: string,
  input: VideoProgressRecord
): Promise<void> {
  const safeVideoId = sanitizeId(input.videoId, 'vid');
  const durationSec = clampNumber(Math.round(Number(input.durationSec) || 1), 1, 7200);
  const currentSec = clampNumber(Math.round(Number(input.currentSec) || 0), 0, durationSec);
  const completed = Boolean(input.completed || currentSec >= durationSec - 1);
  const path = `users/${uid}/videoProgress/${safeVideoId}`;
  try {
    const ref = doc(db, 'users', uid, 'videoProgress', safeVideoId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        currentSec,
        durationSec,
        completed,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        videoId: safeVideoId,
        uid,
        currentSec,
        durationSec,
        completed,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function createISLEntryDoc(
  uid: string,
  entry: ISLEntry,
  isEducator = false
): Promise<void> {
  const urlCheck = validateExternalVideoUrl(entry.customVideoUrl || '');
  if (!urlCheck.ok) {
    throw new Error(urlCheck.error);
  }

  const id = sanitizeId(entry.id, 'isl');
  const path = `islEntries/${id}`;
  const isVerifiedClip = isEducator ? Boolean(entry.isVerifiedClip) : false;
  const verificationLabel = isEducator
    ? (entry.verificationLabel.trim() || 'Educator Reference').slice(0, 140)
    : urlCheck.normalizedUrl
    ? 'Student Submission (Pending Verification)'
    : 'Educator Text & Handshape Reference';

  const payload: Record<string, unknown> = {
    id,
    createdByUid: uid,
    term: (entry.term.trim() || 'ISL Term').slice(0, 140),
    category: sanitizeCategory(entry.category),
    meaning: (entry.meaning.trim() || 'Definition').slice(0, 1000),
    handshapeGuide: (entry.handshapeGuide.trim() || 'Educator reference guide').slice(0, 1000),
    usageExample: (entry.usageExample.trim() || `Classroom usage: "${entry.term}"`).slice(0, 500),
    isVerifiedClip,
    verificationLabel,
    createdAt: serverTimestamp(),
  };

  if (urlCheck.normalizedUrl) {
    payload.customVideoUrl = urlCheck.normalizedUrl;
  }

  try {
    await setDoc(doc(db, 'islEntries', id), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
