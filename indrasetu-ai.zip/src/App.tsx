/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AccessibilityDrawer } from './components/Accessibility/AccessibilityDrawer';
import { AuthModal } from './components/Auth/AuthModal';
import { TopHeader } from './components/Header/TopHeader';
import { Sidebar } from './components/Sidebar/Sidebar';
import { AccessibilityProvider } from './contexts/AccessibilityContext';
import { AppProvider, useApp } from './contexts/AppContext';
import { AccessibilitySettingsPage } from './pages/AccessibilitySettings/AccessibilitySettingsPage';
import { AssessmentsPage } from './pages/Assessments/AssessmentsPage';
import { DashboardPage } from './pages/Dashboard/DashboardPage';
import { DoubtSolverPage } from './pages/DoubtSolver/DoubtSolverPage';
import { ISLLibraryPage } from './pages/ISLLibrary/ISLLibraryPage';
import { LandingPage } from './pages/Landing/LandingPage';
import { MyLearningPage } from './pages/MyLearning/MyLearningPage';
import { ProfileSettingsPage } from './pages/ProfileSettings/ProfileSettingsPage';
import { ProgressPage } from './pages/Progress/ProgressPage';
import { VideoLessonsPage } from './pages/VideoLessons/VideoLessonsPage';
import { VisualLearningPage } from './pages/VisualLearning/VisualLearningPage';

const AppShell: React.FC = () => {
  const { route } = useApp();

  if (route === 'landing') {
    return (
      <>
        <LandingPage />
        <AccessibilityDrawer />
        <AuthModal />
      </>
    );
  }

  const renderPage = () => {
    switch (route) {
      case 'dashboard':
        return <DashboardPage />;
      case 'learning':
        return <MyLearningPage />;
      case 'videos':
        return <VideoLessonsPage />;
      case 'isl':
        return <ISLLibraryPage />;
      case 'visual':
        return <VisualLearningPage />;
      case 'doubt':
        return <DoubtSolverPage />;
      case 'assessments':
        return <AssessmentsPage />;
      case 'progress':
        return <ProgressPage />;
      case 'accessibility':
        return <AccessibilitySettingsPage />;
      case 'profile':
        return <ProfileSettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#FAF9F6] dark:bg-slate-950 text-[#243447] dark:text-slate-100 font-reading">
      <Sidebar />
      <div className="flex flex-1 flex-col min-w-0">
        <TopHeader />
        <main id="main-content" className="flex-1 px-4 py-6 sm:px-6 lg:px-8 max-w-7xl w-full mx-auto">
          {renderPage()}
        </main>
      </div>
      <AccessibilityDrawer />
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AccessibilityProvider>
      <AppProvider>
        <AppShell />
      </AppProvider>
    </AccessibilityProvider>
  );
}
